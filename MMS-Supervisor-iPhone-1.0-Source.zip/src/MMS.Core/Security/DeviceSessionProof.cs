using System.Security.Cryptography;
using System.Text.Json;

namespace MMS.Core.Security;

[System.Text.Json.Serialization.JsonSerializable(typeof(SignedDeviceSession))]
[System.Text.Json.Serialization.JsonSerializable(typeof(string[][]), TypeInfoPropertyName = "RevocationSets")]
internal partial class DeviceProofJsonContext : System.Text.Json.Serialization.JsonSerializerContext { }

public sealed record SignedDeviceSession(byte[] IdentityChain, byte[] Signature);

/// <summary>V2 mutual authentication. A fresh CLIENT nonce is required; TLS certificate hashing alone is not a replay defence.</summary>
public static class DeviceSessionProof
{
    public const int MaximumBytes = 16 * 1024;

    public static byte[] Sign(byte[] chain, RSA deviceKey, ReadOnlySpan<byte> clientNonce, ReadOnlySpan<byte> serverNonce, ReadOnlySpan<byte> tlsHash)
    {
        var payload = Payload(chain, clientNonce, serverNonce, tlsHash);
        var encoded = JsonSerializer.SerializeToUtf8Bytes(new SignedDeviceSession(chain,
            deviceKey.SignData(payload, HashAlgorithmName.SHA256, RSASignaturePadding.Pss)), DeviceProofJsonContext.Default.SignedDeviceSession);
        if (encoded.Length > MaximumBytes) throw new InvalidDataException("Device proof is too large.");
        return encoded;
    }

    public static ValidatedIdentity Validate(ReadOnlySpan<byte> encoded, RSA root, ValidatedPolicy policy, DateTimeOffset now,
        Guid expectedAgent, string expectedSerial, ReadOnlySpan<byte> clientNonce, ReadOnlySpan<byte> serverNonce, ReadOnlySpan<byte> tlsHash)
    {
        if (policy.Credentials.ExpiresUtc <= now) throw new InvalidDataException("Current revocation policy is required.");
        if (encoded.Length is < 1 or > MaximumBytes) throw new InvalidDataException("Invalid device-proof size.");
        var proof = JsonSerializer.Deserialize(encoded, DeviceProofJsonContext.Default.SignedDeviceSession) ?? throw new InvalidDataException("Missing device proof.");
        if (proof.IdentityChain is null || proof.Signature is null || proof.Signature.Length > 1024)
            throw new InvalidDataException("Incomplete device proof.");
        var identity = VerifiedIdentityCache.Validate(proof.IdentityChain, root, now, policy.RevokedAuthorities, policy.RevokedIdentities);
        if (identity.Subject.Role != TrustChainValidator.DeviceRole || identity.Subject.AccountId != expectedAgent ||
            !string.Equals(identity.Subject.UserName, expectedSerial.Trim(), StringComparison.Ordinal))
            throw new InvalidDataException("The connected device is not the selected enrolled identity.");
        using var device = RSA.Create();
        device.ImportSubjectPublicKeyInfo(identity.Subject.SubjectPublicKey, out _);
        if (!device.VerifyData(Payload(proof.IdentityChain, clientNonce, serverNonce, tlsHash), proof.Signature.AsSpan(),
                HashAlgorithmName.SHA256, RSASignaturePadding.Pss)) throw new InvalidDataException("Device proof does not match this TLS channel and challenge.");
        return identity;
    }

    private static byte[] Payload(ReadOnlySpan<byte> chain, ReadOnlySpan<byte> clientNonce, ReadOnlySpan<byte> serverNonce, ReadOnlySpan<byte> tlsHash)
    {
        if (chain.Length is < 1 or > TrustChainValidator.MaximumChainBytes || clientNonce.Length != 32 || serverNonce.Length != 32 || tlsHash.Length != 32)
            throw new InvalidDataException("Invalid device session challenge.");
        return [.. "MMS.DeviceSession.v2\0"u8, .. clientNonce, .. serverNonce, .. tlsHash, .. SHA256.HashData(chain)];
    }
}
