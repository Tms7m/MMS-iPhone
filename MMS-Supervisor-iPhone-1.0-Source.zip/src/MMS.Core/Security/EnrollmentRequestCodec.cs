using System.Security.Cryptography;
using System.Text.Json;

namespace MMS.Core.Security;

public sealed record EnrollmentRequestV2(int Version, Guid RequestId, Guid AgentId, string SerialNumber,
    string Hostname, DateTimeOffset CreatedUtc, byte[] PublicKey);
public sealed record SignedEnrollmentRequest(byte[] Payload, byte[] Signature);

[System.Text.Json.Serialization.JsonSerializable(typeof(EnrollmentRequestV2))]
[System.Text.Json.Serialization.JsonSerializable(typeof(SignedEnrollmentRequest))]
internal partial class EnrollmentJsonContext : System.Text.Json.Serialization.JsonSerializerContext { }

public static class EnrollmentRequestCodec
{
    public const int MaximumBytes = 16 * 1024;
    public static byte[] Create(Guid agentId, string serial, string hostname, RSA deviceKey, DateTimeOffset now)
    {
        var request = new EnrollmentRequestV2(2, Guid.NewGuid(), agentId, serial.Trim(), hostname.Trim(), now, deviceKey.ExportSubjectPublicKeyInfo());
        var payload = JsonSerializer.SerializeToUtf8Bytes(request, EnrollmentJsonContext.Default.EnrollmentRequestV2);
        var encoded = JsonSerializer.SerializeToUtf8Bytes(new SignedEnrollmentRequest(payload,
            deviceKey.SignData([.. "MMS.EnrollmentRequest.v2\0"u8, .. payload], HashAlgorithmName.SHA256, RSASignaturePadding.Pss)), EnrollmentJsonContext.Default.SignedEnrollmentRequest);
        _ = Validate(encoded, now);
        return encoded;
    }

    public static EnrollmentRequestV2 Validate(ReadOnlySpan<byte> encoded, DateTimeOffset now)
    {
        if (encoded.Length is < 1 or > MaximumBytes) throw new InvalidDataException("Invalid enrollment-request size.");
        var envelope = JsonSerializer.Deserialize(encoded, EnrollmentJsonContext.Default.SignedEnrollmentRequest) ?? throw new InvalidDataException("Missing enrollment request.");
        if (envelope.Payload is null || envelope.Signature is null || envelope.Signature.Length > 1024)
            throw new InvalidDataException("Invalid enrollment proof.");
        var request = JsonSerializer.Deserialize(envelope.Payload, EnrollmentJsonContext.Default.EnrollmentRequestV2) ?? throw new InvalidDataException("Missing enrollment identity.");
        if (request.Version != 2 || request.RequestId == Guid.Empty || request.AgentId == Guid.Empty ||
            string.IsNullOrWhiteSpace(request.SerialNumber) || request.SerialNumber.Length > 128 ||
            string.IsNullOrWhiteSpace(request.Hostname) || request.Hostname.Length > 255 || request.PublicKey is null ||
            request.CreatedUtc > now.AddMinutes(5) || request.CreatedUtc < now.AddDays(-30))
            throw new InvalidDataException("Malformed or stale enrollment request. Regenerate it on the intended device.");
        TrustChainValidator.ValidatePublicKey(request.PublicKey);
        using var key = RSA.Create();
        key.ImportSubjectPublicKeyInfo(request.PublicKey, out _);
        if (!key.VerifyData([.. "MMS.EnrollmentRequest.v2\0"u8, .. envelope.Payload], envelope.Signature.AsSpan(), HashAlgorithmName.SHA256, RSASignaturePadding.Pss))
            throw new InvalidDataException("The request does not prove possession of the device key.");
        return request;
    }
}
