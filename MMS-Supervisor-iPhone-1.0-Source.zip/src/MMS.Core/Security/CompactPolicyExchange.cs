using System.Security.Cryptography;
using MMS.Core.LiveView;

namespace MMS.Core.Security;

// Capability advertisement is only negotiation, never a trust decision.
// Both identities and fresh TLS-bound proofs are still checked after this exchange.
public static class CompactPolicyExchange
{
    public const string CertificateOrganizationalUnit = "MMS-PolicyDigest-v1";
    private static readonly byte[] NeedFull = "MMSP-FULL-v1"u8.ToArray();
    public static byte[] Digest(byte[] policy) => [.. "MMP1"u8, .. SHA256.HashData(policy)];
    private static bool IsDigest(byte[] message) => message.Length == 36 && message.AsSpan(0, 4).SequenceEqual("MMP1"u8);

    public static async Task<bool> ClientAsync(Stream stream, bool compact, byte[] policy,
        Func<byte[], CancellationToken, Task> apply, CancellationToken token)
    {
        await LiveViewProtocol.WriteBlobAsync(stream, compact ? Digest(policy) : policy, token);
        var response = await LiveViewProtocol.ReadBlobAsync(stream, token, OrganizationPolicy.MaximumBundleBytes);
        if (compact && response.AsSpan().SequenceEqual(NeedFull))
        {
            await LiveViewProtocol.WriteBlobAsync(stream, policy, token);
            response = await LiveViewProtocol.ReadBlobAsync(stream, token, OrganizationPolicy.MaximumBundleBytes);
        }
        if (compact && IsDigest(response))
        {
            if (!CryptographicOperations.FixedTimeEquals(response, Digest(policy))) throw new InvalidDataException("Policy digest mismatch.");
            return true;
        }
        await apply(response, token);
        return false;
    }

    public static async Task<bool> ServerAsync(Stream stream, Func<byte[]> readCurrent,
        Func<byte[], CancellationToken, Task> apply, CancellationToken token)
    {
        var request = await LiveViewProtocol.ReadBlobAsync(stream, token, OrganizationPolicy.MaximumBundleBytes);
        var compact = IsDigest(request);
        var current = readCurrent();
        if (compact && CryptographicOperations.FixedTimeEquals(request, Digest(current)))
        {
            await LiveViewProtocol.WriteBlobAsync(stream, request, token);
            return true;
        }
        if (compact)
        {
            await LiveViewProtocol.WriteBlobAsync(stream, NeedFull, token);
            request = await LiveViewProtocol.ReadBlobAsync(stream, token, OrganizationPolicy.MaximumBundleBytes);
        }
        await apply(request, token);
        current = readCurrent();
        await LiveViewProtocol.WriteBlobAsync(stream,
            compact && current.AsSpan().SequenceEqual(request) ? Digest(current) : current, token);
        return false;
    }
}
