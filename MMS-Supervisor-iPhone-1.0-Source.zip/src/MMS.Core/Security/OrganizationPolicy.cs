using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MMS.Core.Security;

public sealed record AuthorityPolicyState(string Organization, long Epoch, DateTimeOffset IssuedUtc,
    string CurrentIssuerHash, string[] RevokedAuthorityHashes);
public sealed record CredentialPolicyState(long Epoch, long Revision, DateTimeOffset IssuedUtc,
    DateTimeOffset ExpiresUtc, string[] RevokedIdentityHashes, bool NoExpiry = false);
public sealed record SignedSecurityDocument(byte[] Payload, byte[] Signature);
public sealed record CredentialPolicyDocument(byte[] AuthorityCertificate, byte[] Payload, byte[] Signature);
public sealed record SecurityPolicyBundle(byte[] AuthorityPolicy, byte[] CredentialPolicy);
public sealed record ValidatedPolicy(AuthorityPolicyState Authority, CredentialPolicyState Credentials)
{
    public HashSet<string> RevokedAuthorities => new(Authority.RevokedAuthorityHashes, StringComparer.OrdinalIgnoreCase);
    public HashSet<string> RevokedIdentities => new(Credentials.RevokedIdentityHashes, StringComparer.OrdinalIgnoreCase);
}

[JsonSerializable(typeof(SecurityPolicyBundle))]
[JsonSerializable(typeof(AuthorityPolicyState))]
[JsonSerializable(typeof(CredentialPolicyState))]
[JsonSerializable(typeof(SignedSecurityDocument))]
[JsonSerializable(typeof(CredentialPolicyDocument))]
internal partial class PolicyJsonContext : JsonSerializerContext { }

public static class OrganizationPolicy
{
    public const int MaximumBundleBytes = 1024 * 1024;
    private static readonly PolicyJsonContext Json = new(new JsonSerializerOptions { MaxDepth = 12 });

    public static byte[] SignAuthority(AuthorityPolicyState state, RSA root)
    {
        var payload = JsonSerializer.SerializeToUtf8Bytes(state, Json.AuthorityPolicyState);
        return JsonSerializer.SerializeToUtf8Bytes(new SignedSecurityDocument(payload,
            root.SignData([.. "MMS.AuthorityPolicy.v2\0"u8, .. payload], HashAlgorithmName.SHA256, RSASignaturePadding.Pss)), Json.SignedSecurityDocument);
    }

    public static byte[] SignCredentials(CredentialPolicyState state, byte[] issuerCertificate, RSA issuer)
    {
        var payload = JsonSerializer.SerializeToUtf8Bytes(state, Json.CredentialPolicyState);
        return JsonSerializer.SerializeToUtf8Bytes(new CredentialPolicyDocument(issuerCertificate, payload,
            issuer.SignData([.. "MMS.CredentialPolicy.v2\0"u8, .. SHA256.HashData(issuerCertificate), .. payload],
                HashAlgorithmName.SHA256, RSASignaturePadding.Pss)), Json.CredentialPolicyDocument);
    }

    public static byte[] Encode(SecurityPolicyBundle bundle)
    {
        var result = JsonSerializer.SerializeToUtf8Bytes(bundle, Json.SecurityPolicyBundle);
        if (result.Length > MaximumBundleBytes) throw new InvalidDataException("Policy bundle exceeds its size limit.");
        return result;
    }

    public static SecurityPolicyBundle Decode(ReadOnlySpan<byte> encoded)
    {
        if (encoded.Length is < 1 or > MaximumBundleBytes) throw new InvalidDataException("Invalid policy bundle size.");
        return JsonSerializer.Deserialize(encoded, Json.SecurityPolicyBundle) ?? throw new InvalidDataException("Missing policies.");
    }

    public static AuthorityPolicyState ValidateAuthority(ReadOnlySpan<byte> encoded, RSA root, DateTimeOffset now)
    {
        if (encoded.Length is < 1 or > 128 * 1024) throw new InvalidDataException("Invalid authority policy size.");
        var document = JsonSerializer.Deserialize(encoded, Json.SignedSecurityDocument) ?? throw new InvalidDataException("Missing authority policy.");
        if (document.Payload is null || document.Signature is null || !root.VerifyData(
                [.. "MMS.AuthorityPolicy.v2\0"u8, .. document.Payload], document.Signature.AsSpan(), HashAlgorithmName.SHA256, RSASignaturePadding.Pss))
            throw new InvalidDataException("Invalid root signature.");
        var state = JsonSerializer.Deserialize(document.Payload, Json.AuthorityPolicyState) ?? throw new InvalidDataException("Missing authority state.");
        if (state.Organization != TrustChainValidator.Hash(root.ExportSubjectPublicKeyInfo()) || state.Epoch < 1 ||
            state.IssuedUtc > now.AddMinutes(5) || !ValidHash(state.CurrentIssuerHash) || !ValidHashes(state.RevokedAuthorityHashes, 1000) ||
            state.RevokedAuthorityHashes.Contains(state.CurrentIssuerHash, StringComparer.OrdinalIgnoreCase))
            throw new InvalidDataException("Invalid authority policy fields.");
        return state;
    }

    public static ValidatedPolicy Validate(SecurityPolicyBundle bundle, RSA root, DateTimeOffset now)
    {
        if (bundle.AuthorityPolicy is null || bundle.CredentialPolicy is null || bundle.CredentialPolicy.Length is < 1 or > 512 * 1024)
            throw new InvalidDataException("Missing or oversized security policy.");
        var authority = ValidateAuthority(bundle.AuthorityPolicy, root, now);
        var document = JsonSerializer.Deserialize(bundle.CredentialPolicy, Json.CredentialPolicyDocument) ?? throw new InvalidDataException("Missing revocation policy.");
        if (document.AuthorityCertificate is null || document.Payload is null || document.Signature is null ||
            TrustChainValidator.Hash(document.AuthorityCertificate) != authority.CurrentIssuerHash)
            throw new InvalidDataException("The revocation signer is not the root-authorized current issuer.");
        var credentials = JsonSerializer.Deserialize(document.Payload, Json.CredentialPolicyState) ?? throw new InvalidDataException("Missing revocations.");
        if (credentials.IssuedUtc > now.AddMinutes(5)) throw new InvalidDataException("Policy issue time is in the future.");
        var issuer = TrustChainValidator.ValidateAuthority(document.AuthorityCertificate, root,
            credentials.NoExpiry ? credentials.IssuedUtc : now);
        using var key = RSA.Create();
        key.ImportSubjectPublicKeyInfo(issuer.SubjectPublicKey, out _);
        if (!key.VerifyData([.. "MMS.CredentialPolicy.v2\0"u8, .. SHA256.HashData(document.AuthorityCertificate), .. document.Payload],
                document.Signature.AsSpan(), HashAlgorithmName.SHA256, RSASignaturePadding.Pss))
            throw new InvalidDataException("Invalid revocation policy signature.");
        if (credentials.Epoch != authority.Epoch || credentials.Revision < 1 || credentials.IssuedUtc > now.AddMinutes(5) ||
            credentials.IssuedUtc < issuer.NotBeforeUtc ||
            (credentials.NoExpiry ? credentials.ExpiresUtc != DateTimeOffset.MaxValue :
                credentials.ExpiresUtc <= now || credentials.ExpiresUtc > issuer.NotAfterUtc ||
                credentials.ExpiresUtc <= credentials.IssuedUtc || credentials.ExpiresUtc - credentials.IssuedUtc > TimeSpan.FromDays(90)) ||
            !ValidHashes(credentials.RevokedIdentityHashes, 10000)) throw new InvalidDataException("Expired or malformed revocation policy.");
        return new(authority, credentials);
    }

    // Provisioning only: retain a verified, unexpired successor already installed.
    // Live synchronization continues to use strict RequireSuccessor.
    public static SecurityPolicyBundle SelectForProvisioning(SecurityPolicyBundle incoming,
        SecurityPolicyBundle? existing, RSA root, DateTimeOffset now)
    {
        var next = Validate(incoming, root, now);
        if (existing is null) return incoming;
        if (Encode(existing).AsSpan().SequenceEqual(Encode(incoming))) return incoming;
        var previous = ValidateHistorical(existing, root, now);
        if (previous.Authority.Epoch > next.Authority.Epoch ||
            (previous.Authority.Epoch == next.Authority.Epoch &&
             previous.Credentials.Revision > next.Credentials.Revision))
        {
            previous = Validate(existing, root, now);
            RequireSuccessor(next, previous);
            return existing;
        }
        RequireSuccessor(previous, next);
        return incoming;
    }

    public static void RequireSuccessor(ValidatedPolicy existing, ValidatedPolicy incoming)
    {
        if (existing.Authority.Organization != incoming.Authority.Organization || incoming.Authority.Epoch < existing.Authority.Epoch ||
            (incoming.Authority.Epoch == existing.Authority.Epoch &&
                (incoming.Credentials.Revision <= existing.Credentials.Revision ||
                    incoming.Authority.CurrentIssuerHash != existing.Authority.CurrentIssuerHash || incoming.Authority.IssuedUtc != existing.Authority.IssuedUtc ||
                     !incoming.Authority.RevokedAuthorityHashes.SequenceEqual(existing.Authority.RevokedAuthorityHashes))))
            throw new InvalidDataException("The policy must advance its authorized epoch/revision without rewriting an epoch.");
        if (!incoming.RevokedAuthorities.IsSupersetOf(existing.RevokedAuthorities) || !incoming.RevokedIdentities.IsSupersetOf(existing.RevokedIdentities))
            throw new InvalidDataException("A policy update cannot remove previous revocations.");
    }

    // For recovery/monotonic comparisons only. Never use this result to authorize a live session.
    public static ValidatedPolicy ValidateHistorical(SecurityPolicyBundle bundle, RSA root, DateTimeOffset now)
    {
        if (bundle.CredentialPolicy is null || bundle.CredentialPolicy.Length is < 1 or > 512 * 1024)
            throw new InvalidDataException("Invalid historical policy size.");
        var document = JsonSerializer.Deserialize(bundle.CredentialPolicy, Json.CredentialPolicyDocument) ?? throw new InvalidDataException("Missing policy.");
        if (document.Payload is null) throw new InvalidDataException("Missing policy payload.");
        var untrusted = JsonSerializer.Deserialize(document.Payload, Json.CredentialPolicyState) ?? throw new InvalidDataException("Missing policy state.");
        if (untrusted.IssuedUtc > now.AddMinutes(5)) throw new InvalidDataException("Historical policy is from the future.");
        return Validate(bundle, root, untrusted.IssuedUtc);
    }

    private static bool ValidHash(string? value) => value is { Length: 64 } && value.All(Uri.IsHexDigit);
    private static bool ValidHashes(string[]? values, int maximum) => values is not null && values.Length <= maximum &&
        values.All(ValidHash) && values.Distinct(StringComparer.OrdinalIgnoreCase).Count() == values.Length;
}
