using System.Buffers.Binary;
using System.Security.Cryptography;

namespace MMS.Core.Security;

public sealed record ValidatedIdentity(SupervisorAuthorization Authority, SupervisorAuthorization Subject,
    string AuthorityHash, string SubjectHash);

/// <summary>V2 trust: a pinned root issues an authority; only that authority issues account/device identities.
/// Enrollment issuing keys are deliberately never distributed to students.</summary>
public static class TrustChainValidator
{
    public const byte AuthorityRole = 250;
    public const byte DeviceRole = 255;
    public const int MaximumChainBytes = 8192;

    public static byte[] Encode(byte[] authority, byte[] subject)
    {
        if (authority.Length is < 1 or > 4096 || subject.Length is < 1 or > 4096 ||
            authority.Length + subject.Length + 12 > MaximumChainBytes) throw new InvalidDataException("Identity chain is too large.");
        var encoded = new byte[12 + authority.Length + subject.Length];
        "MMSC"u8.CopyTo(encoded);
        BinaryPrimitives.WriteInt32BigEndian(encoded.AsSpan(4), authority.Length);
        authority.CopyTo(encoded, 8);
        BinaryPrimitives.WriteInt32BigEndian(encoded.AsSpan(8 + authority.Length), subject.Length);
        subject.CopyTo(encoded, 12 + authority.Length);
        return encoded;
    }

    public static (byte[] Authority, byte[] Subject) Decode(ReadOnlySpan<byte> encoded)
    {
        if (encoded.Length is < 14 or > MaximumChainBytes || !encoded[..4].SequenceEqual("MMSC"u8))
            throw new InvalidDataException("A two-level MMS identity chain is required.");
        var first = BinaryPrimitives.ReadInt32BigEndian(encoded[4..]);
        if (first is < 1 or > 4096 || encoded.Length < first + 12) throw new InvalidDataException("Invalid authority length.");
        var second = BinaryPrimitives.ReadInt32BigEndian(encoded[(8 + first)..]);
        if (second is < 1 or > 4096 || first + second + 12 != encoded.Length) throw new InvalidDataException("Invalid subject length.");
        return (encoded.Slice(8, first).ToArray(), encoded.Slice(12 + first, second).ToArray());
    }

    public static SupervisorAuthorization ValidateAuthority(ReadOnlySpan<byte> certificate, RSA root, DateTimeOffset now)
    {
        if (!SupervisorAuthorizationCodec.TryValidate(certificate, root, now, out var authority) || authority is null ||
            authority.Role != AuthorityRole || authority.Capabilities != SessionCapability.None || authority.ApplicationPermissions != 0)
            throw new InvalidDataException("The issuing authority is not authorized by the organization root.");
        ValidatePublicKey(authority.SubjectPublicKey);
        return authority;
    }

    public static ValidatedIdentity Validate(ReadOnlySpan<byte> encoded, RSA root, DateTimeOffset now,
        IReadOnlySet<string> revokedAuthorities, IReadOnlySet<string> revokedSubjects)
    {
        var (authorityBytes, subjectBytes) = Decode(encoded);
        var authorityHash = Hash(authorityBytes);
        var subjectHash = Hash(subjectBytes);
        if (revokedAuthorities.Contains(authorityHash) || revokedSubjects.Contains(subjectHash) || revokedSubjects.Contains(Hash(encoded)))
            throw new InvalidDataException("This identity or its issuing authority has been revoked.");
        // Existing authority/policy validation stays strict. A delegated issuer is accepted
        // only here, where the leaf is additionally restricted to a student device.
        SupervisorAuthorization authority;
        var deviceOnly = false;
        if (SupervisorAuthorizationCodec.TryValidate(authorityBytes, root, now, out var candidate) &&
            candidate?.Role == EnrollmentDelegation.IssuerRole)
        {
            // Withdrawing an account's permission stops NEW enrollment, not its existing students.
            // Explicit revocation of the device-only issuer still invalidates its student identities.
            authority = EnrollmentDelegation.Validate(authorityBytes, root, now, revokedAuthorities, revokedSubjects,
                requireActiveOwner: false);
            deviceOnly = true;
        }
        else authority = ValidateAuthority(authorityBytes, root, now);
        using var key = RSA.Create();
        key.ImportSubjectPublicKeyInfo(authority.SubjectPublicKey, out _);
        if (!SupervisorAuthorizationCodec.TryValidate(subjectBytes, key, now, out var subject) || subject is null ||
            subject.Role is not (0 or 1 or 2 or DeviceRole) || (deviceOnly && subject.Role != DeviceRole) ||
            subject.NotBeforeUtc < authority.NotBeforeUtc || subject.NotAfterUtc > authority.NotAfterUtc)
            throw new InvalidDataException("The subject is outside its issuer's authority or validity period.");
        if (subject.Role == DeviceRole && (subject.Capabilities != SessionCapability.None || subject.ApplicationPermissions != 0))
            throw new InvalidDataException("A device identity cannot hold supervisor permissions.");
        if (subject.Role == 1 && (subject.Capabilities != SessionCapability.ViewLive || subject.ApplicationPermissions != 1))
            throw new InvalidDataException("Viewer identities must remain view-only.");
        ValidatePublicKey(subject.SubjectPublicKey);
        return new(authority, subject, authorityHash, subjectHash);
    }

    public static string Hash(ReadOnlySpan<byte> bytes) => Convert.ToHexString(SHA256.HashData(bytes));

    public static void ValidatePublicKey(ReadOnlySpan<byte> encoded)
    {
        using var key = RSA.Create();
        key.ImportSubjectPublicKeyInfo(encoded, out var consumed);
        if (consumed != encoded.Length || key.KeySize is < 3072 or > 8192) throw new InvalidDataException("A complete RSA public key of 3072–8192 bits is required.");
    }
}
