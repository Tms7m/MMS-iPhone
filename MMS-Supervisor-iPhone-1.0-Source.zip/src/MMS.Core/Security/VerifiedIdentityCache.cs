using System.Security.Cryptography;

namespace MMS.Core.Security;

// Cache public chain validation, NOT proof-of-possession or an allow/deny decision.
// Every key includes the pinned root and complete current revocation sets.
public static class VerifiedIdentityCache
{
    private static readonly IdentityVerificationStore Store = new(Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MMS", "VerifiedIdentities"));
    public static ValidatedIdentity Validate(byte[] chain, RSA root, DateTimeOffset now,
        IReadOnlySet<string> revokedAuthorities, IReadOnlySet<string> revokedIdentities) =>
        Store.Validate(chain, root, now, revokedAuthorities, revokedIdentities);
}

// Retains signed public identities on disk, never private keys or trusted serialized
// authorization objects. A cold process checks the signature once before reuse.
public sealed class IdentityVerificationStore(string? directory = null)
{
    private readonly object Gate = new();
    private readonly Dictionary<string, ValidatedIdentity> Entries = new();
    private int _fullValidations;
    public int FullValidations => Volatile.Read(ref _fullValidations);
    public ValidatedIdentity Validate(byte[] chain, RSA root, DateTimeOffset now,
        IReadOnlySet<string> revokedAuthorities, IReadOnlySet<string> revokedIdentities)
    {
        if (chain.Length is < 14 or > TrustChainValidator.MaximumChainBytes) throw new InvalidDataException("Invalid chain size.");
        var identityKey = TrustChainValidator.Hash(root.ExportSubjectPublicKeyInfo()) + "-" + TrustChainValidator.Hash(chain);
        var revocations = System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(new[] {
            revokedAuthorities.Order(StringComparer.Ordinal).ToArray(), revokedIdentities.Order(StringComparer.Ordinal).ToArray() });
        var key = identityKey + ":" + TrustChainValidator.Hash(revocations);
        lock (Gate)
        {
            if (Entries.TryGetValue(key, out var cached) &&
                now >= cached.Authority.NotBeforeUtc && now < cached.Authority.NotAfterUtc &&
                now >= cached.Subject.NotBeforeUtc && now < cached.Subject.NotAfterUtc)
                return Copy(cached);
            // Serialize cold validation to avoid repeating RSA work during a burst.
            var candidate = ReadSaved(identityKey, chain);
            Interlocked.Increment(ref _fullValidations);
            var verified = TrustChainValidator.Validate(candidate, root, now, revokedAuthorities, revokedIdentities);
            if (Entries.Count >= 4096) Entries.Remove(Entries.Keys.First()); // no time expiry; bounded working set
            Entries[key] = Copy(verified);
            Save(identityKey, candidate);
            return verified;
        }
    }
    private byte[] ReadSaved(string key, byte[] expected)
    {
        if (directory is null) return expected;
        try
        {
            var path = Path.Combine(directory, key + ".mmschain");
            var info = new FileInfo(path);
            if (info.Exists && info.Length == expected.Length && !info.Attributes.HasFlag(FileAttributes.ReparsePoint))
            {
                var saved = File.ReadAllBytes(path);
                if (saved.AsSpan().SequenceEqual(expected)) return saved;
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
        return expected; // Changed/missing cache never grants trust.
    }
    private void Save(string key, byte[] chain)
    {
        if (directory is null) return;
        try
        {
            Directory.CreateDirectory(directory);
            if (File.GetAttributes(directory).HasFlag(FileAttributes.ReparsePoint)) return;
            var path = Path.Combine(directory, key + ".mmschain");
            if (File.Exists(path) || Directory.EnumerateFiles(directory, "*.mmschain").Take(4096).Count() >= 4096) return;
            using var output = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None);
            output.Write(chain);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
    }
    private static SupervisorAuthorization Copy(SupervisorAuthorization value) => value with
    { SubjectPublicKey = value.SubjectPublicKey.ToArray(), IssuerSignature = value.IssuerSignature.ToArray() };
    private static ValidatedIdentity Copy(ValidatedIdentity value) => value with { Authority = Copy(value.Authority), Subject = Copy(value.Subject) };
}
