using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;

namespace MMS.Core.Security;

[Flags]
public enum SessionCapability : long
{
    None = 0,
    ViewLive = 1 << 0,
    CaptureScreenshot = 1 << 1,
    RecordScreen = 1 << 2,
    ListenMicrophone = 1 << 3,
    RemoteControl = 1 << 4,
    All = ViewLive | CaptureScreenshot | RecordScreen | ListenMicrophone | RemoteControl
}

public sealed record SupervisorAuthorization(
    Guid AccountId,
    string UserName,
    byte Role,
    SessionCapability Capabilities,
    DateTimeOffset NotBeforeUtc,
    DateTimeOffset NotAfterUtc,
    byte[] SubjectPublicKey,
    byte[] IssuerSignature)
{
    public long ApplicationPermissions { get; init; }
}

public static class SupervisorAuthorizationCodec
{
    private const byte Version = 2;
    private const int MaximumCertificateBytes = 16 * 1024;

    public static byte[] Issue(Guid accountId, string userName, byte role, SessionCapability capabilities,
        DateTimeOffset notBeforeUtc, DateTimeOffset notAfterUtc, ReadOnlySpan<byte> subjectPublicKey, RSA issuer,
        long applicationPermissions = 0)
    {
        var unsigned = EncodeUnsigned(accountId, userName, role, capabilities, notBeforeUtc, notAfterUtc, subjectPublicKey, applicationPermissions);
        var signature = issuer.SignData(unsigned, HashAlgorithmName.SHA256, RSASignaturePadding.Pss);
        return EncodeParts(unsigned, signature);
    }

    public static bool TryValidate(ReadOnlySpan<byte> encoded, RSA issuerPublicKey, DateTimeOffset nowUtc,
        out SupervisorAuthorization? authorization)
    {
        authorization = null;
        if (!TrySplit(encoded, out var unsigned, out var issuerSignature) ||
            !issuerPublicKey.VerifyData(unsigned, issuerSignature, HashAlgorithmName.SHA256, RSASignaturePadding.Pss) ||
            !TryDecodeUnsigned(unsigned, out var parsed)) return false;
        if (nowUtc < parsed.NotBeforeUtc || nowUtc > parsed.NotAfterUtc) return false;
        authorization = parsed with { IssuerSignature = issuerSignature };
        return true;
    }

    public static byte[] EncodeProof(ReadOnlySpan<byte> certificate, ReadOnlySpan<byte> sessionSignature)
    {
        if (certificate.IsEmpty || certificate.Length > MaximumCertificateBytes || sessionSignature.IsEmpty || sessionSignature.Length > 4096)
            throw new InvalidDataException("The supervisor proof is invalid.");
        var result = new byte[8 + certificate.Length + sessionSignature.Length];
        BinaryPrimitives.WriteInt32BigEndian(result, certificate.Length);
        certificate.CopyTo(result.AsSpan(4));
        BinaryPrimitives.WriteInt32BigEndian(result.AsSpan(4 + certificate.Length), sessionSignature.Length);
        sessionSignature.CopyTo(result.AsSpan(8 + certificate.Length));
        return result;
    }

    public static bool TryDecodeProof(ReadOnlySpan<byte> encoded, out byte[] certificate, out byte[] signature)
    {
        certificate = []; signature = [];
        if (encoded.Length < 10) return false;
        var certificateLength = BinaryPrimitives.ReadInt32BigEndian(encoded);
        if (certificateLength is < 1 or > MaximumCertificateBytes || encoded.Length < 8 + certificateLength) return false;
        var signatureLength = BinaryPrimitives.ReadInt32BigEndian(encoded.Slice(4 + certificateLength));
        if (signatureLength is < 1 or > 4096 || encoded.Length != 8 + certificateLength + signatureLength) return false;
        certificate = encoded.Slice(4, certificateLength).ToArray();
        signature = encoded.Slice(8 + certificateLength, signatureLength).ToArray();
        return true;
    }

    public static byte[] CreateSessionPayload(ReadOnlySpan<byte> challenge, ReadOnlySpan<byte> tlsCertificateHash, ReadOnlySpan<byte> certificate) =>
        [.. challenge, .. tlsCertificateHash, .. SHA256.HashData(certificate)];

    private static byte[] EncodeUnsigned(Guid accountId, string userName, byte role, SessionCapability capabilities,
        DateTimeOffset notBeforeUtc, DateTimeOffset notAfterUtc, ReadOnlySpan<byte> publicKey, long applicationPermissions)
    {
        var name = Encoding.UTF8.GetBytes(userName.Trim().Normalize());
        if (accountId == Guid.Empty || name.Length is < 1 or > 256 || publicKey.Length is < 64 or > 4096 || notAfterUtc <= notBeforeUtc ||
            (capabilities & ~SessionCapability.All) != 0 || applicationPermissions < 0)
            throw new ArgumentException("The authorization certificate fields are invalid.");
        var result = new byte[1 + 16 + 1 + 8 + 8 + 8 + 2 + name.Length + 4 + publicKey.Length + 8];
        var offset = 0;
        result[offset++] = Version;
        accountId.TryWriteBytes(result.AsSpan(offset, 16)); offset += 16;
        result[offset++] = role;
        BinaryPrimitives.WriteInt64BigEndian(result.AsSpan(offset), (long)capabilities); offset += 8;
        BinaryPrimitives.WriteInt64BigEndian(result.AsSpan(offset), notBeforeUtc.ToUnixTimeSeconds()); offset += 8;
        BinaryPrimitives.WriteInt64BigEndian(result.AsSpan(offset), notAfterUtc.ToUnixTimeSeconds()); offset += 8;
        BinaryPrimitives.WriteUInt16BigEndian(result.AsSpan(offset), (ushort)name.Length); offset += 2;
        name.CopyTo(result, offset); offset += name.Length;
        BinaryPrimitives.WriteInt32BigEndian(result.AsSpan(offset), publicKey.Length); offset += 4;
        publicKey.CopyTo(result.AsSpan(offset));
        BinaryPrimitives.WriteInt64BigEndian(result.AsSpan(offset + publicKey.Length), applicationPermissions);
        return result;
    }

    private static bool TryDecodeUnsigned(ReadOnlySpan<byte> data, out SupervisorAuthorization authorization)
    {
        authorization = null!;
        try
        {
            var offset = 0;
            if (data.Length < 56) return false;
            var version = data[offset++];
            if (version is not (1 or Version)) return false;
            var id = new Guid(data.Slice(offset, 16)); offset += 16;
            var role = data[offset++];
            var permissions = (SessionCapability)BinaryPrimitives.ReadInt64BigEndian(data.Slice(offset)); offset += 8;
            var from = DateTimeOffset.FromUnixTimeSeconds(BinaryPrimitives.ReadInt64BigEndian(data.Slice(offset))); offset += 8;
            var to = DateTimeOffset.FromUnixTimeSeconds(BinaryPrimitives.ReadInt64BigEndian(data.Slice(offset))); offset += 8;
            var nameLength = BinaryPrimitives.ReadUInt16BigEndian(data.Slice(offset)); offset += 2;
            if (nameLength is < 1 or > 256 || offset + nameLength + 4 > data.Length) return false;
            var name = Encoding.UTF8.GetString(data.Slice(offset, nameLength)); offset += nameLength;
            var keyLength = BinaryPrimitives.ReadInt32BigEndian(data.Slice(offset)); offset += 4;
            if (keyLength is < 64 or > 4096 || offset + keyLength + (version == Version ? 8 : 0) != data.Length) return false;
            var applicationPermissions = version == Version
                ? BinaryPrimitives.ReadInt64BigEndian(data.Slice(offset + keyLength)) : (long)permissions;
            if (version == Version && (permissions & ~SessionCapability.All) != 0) return false;
            authorization = new SupervisorAuthorization(id, name, role, permissions & SessionCapability.All, from, to, data.Slice(offset, keyLength).ToArray(), [])
            { ApplicationPermissions = applicationPermissions };
            return id != Guid.Empty && to > from && applicationPermissions >= 0;
        }
        catch (Exception exception) when (exception is ArgumentException or ArgumentOutOfRangeException) { return false; }
    }

    private static byte[] EncodeParts(ReadOnlySpan<byte> unsigned, ReadOnlySpan<byte> signature)
    {
        var result = new byte[8 + unsigned.Length + signature.Length];
        BinaryPrimitives.WriteInt32BigEndian(result, unsigned.Length);
        unsigned.CopyTo(result.AsSpan(4));
        BinaryPrimitives.WriteInt32BigEndian(result.AsSpan(4 + unsigned.Length), signature.Length);
        signature.CopyTo(result.AsSpan(8 + unsigned.Length));
        return result;
    }

    private static bool TrySplit(ReadOnlySpan<byte> encoded, out byte[] unsigned, out byte[] signature)
    {
        unsigned = []; signature = [];
        if (encoded.Length < 10 || encoded.Length > MaximumCertificateBytes) return false;
        var unsignedLength = BinaryPrimitives.ReadInt32BigEndian(encoded);
        if (unsignedLength is < 1 or > MaximumCertificateBytes || encoded.Length < 8 + unsignedLength) return false;
        var signatureLength = BinaryPrimitives.ReadInt32BigEndian(encoded.Slice(4 + unsignedLength));
        if (signatureLength is < 1 or > 4096 || encoded.Length != 8 + unsignedLength + signatureLength) return false;
        unsigned = encoded.Slice(4, unsignedLength).ToArray();
        signature = encoded.Slice(8 + unsignedLength, signatureLength).ToArray();
        return true;
    }
}
