using System.Security.Cryptography;

namespace MMS.Core.Security;

/// <summary>A root-signed, device-only issuer. It cannot issue supervisors, policies or other issuers.</summary>
public static class EnrollmentDelegation
{
    public const byte IssuerRole = 251;
    private const string Prefix = "enroll:";

    public static byte[] Issue(RSA root, RSA enrollmentKey, byte[] ownerChain,
        ValidatedPolicy policy, DateTimeOffset now)
    {
        var owner = TrustChainValidator.Validate(ownerChain, root, now, policy.RevokedAuthorities, policy.RevokedIdentities);
        if (owner.Subject.Role is not (0 or 2)) throw new InvalidDataException("Only an administrator or Developer may receive a registration grant.");
        TrustChainValidator.ValidatePublicKey(enrollmentKey.ExportSubjectPublicKeyInfo());
        return SupervisorAuthorizationCodec.Issue(owner.Subject.AccountId,
            Prefix + TrustChainValidator.Hash(ownerChain) + ":" + owner.AuthorityHash,
            IssuerRole, SessionCapability.None, now, owner.Subject.NotAfterUtc,
            enrollmentKey.ExportSubjectPublicKeyInfo(), root);
    }

    public static SupervisorAuthorization Validate(byte[] certificate, RSA root, DateTimeOffset now,
        IReadOnlySet<string> revokedAuthorities, IReadOnlySet<string> revokedIdentities,
        bool requireActiveOwner = true)
    {
        if (!SupervisorAuthorizationCodec.TryValidate(certificate, root, now, out var grant) || grant is null ||
            grant.Role != IssuerRole || grant.Capabilities != SessionCapability.None || grant.ApplicationPermissions != 0)
            throw new InvalidDataException("Invalid enrollment delegation.");
        var binding = grant.UserName.Split(':');
        if (binding.Length != 3 || binding[0] != "enroll" ||
            !IsHash(binding[1]) || !IsHash(binding[2]) ||
            revokedAuthorities.Contains(TrustChainValidator.Hash(certificate)) ||
            revokedIdentities.Contains(TrustChainValidator.Hash(certificate)) ||
            (requireActiveOwner && (revokedIdentities.Contains(binding[1]) || revokedAuthorities.Contains(binding[2]))))
            throw new InvalidDataException("Enrollment delegation or its account has been revoked.");
        TrustChainValidator.ValidatePublicKey(grant.SubjectPublicKey);
        return grant;
    }

    public static SupervisorAuthorization ValidateOwner(byte[] certificate, byte[] ownerChain, RSA root,
        ValidatedPolicy policy, DateTimeOffset now)
    {
        var grant = Validate(certificate, root, now, policy.RevokedAuthorities, policy.RevokedIdentities);
        var owner = TrustChainValidator.Validate(ownerChain, root, now, policy.RevokedAuthorities, policy.RevokedIdentities);
        if (owner.Subject.Role is not (0 or 2) || grant.AccountId != owner.Subject.AccountId ||
            grant.UserName != Prefix + TrustChainValidator.Hash(ownerChain) + ":" + owner.AuthorityHash ||
            grant.NotAfterUtc > owner.Subject.NotAfterUtc)
            throw new InvalidDataException("Enrollment delegation belongs to another account.");
        return grant;
    }

    public static byte[] IssueDevice(byte[] certificate, RSA signer, byte[] requestBytes, RSA root,
        ValidatedPolicy policy, DateTimeOffset now)
    {
        var grant = Validate(certificate, root, now, policy.RevokedAuthorities, policy.RevokedIdentities);
        if (!signer.ExportSubjectPublicKeyInfo().AsSpan().SequenceEqual(grant.SubjectPublicKey))
            throw new InvalidDataException("The local registration key does not match its grant.");
        var request = EnrollmentRequestCodec.Validate(requestBytes, now);
        var identity = SupervisorAuthorizationCodec.Issue(request.AgentId, request.SerialNumber.Trim(),
            TrustChainValidator.DeviceRole, SessionCapability.None, now,
            grant.NotAfterUtc < now.AddYears(1) ? grant.NotAfterUtc : now.AddYears(1), request.PublicKey, signer);
        return TrustChainValidator.Encode(certificate, identity);
    }

    private static bool IsHash(string value) =>
        value.Length == 64 && value.All(c => c is >= '0' and <= '9' or >= 'A' and <= 'F');
}
