using System.Text;
using System.Text.Json;
using MMS.Core.Security;

namespace MMS.Core.LiveView;

public sealed record PowerShellRequest(int Version, Guid Id, string Script, int TimeoutSeconds, string Context = "SYSTEM");
public sealed record PowerShellResult(Guid Id, string Status, int? ExitCode, string Output, string Error, bool Truncated, string? ExecutionIdentity = null);

[System.Text.Json.Serialization.JsonSerializable(typeof(PowerShellRequest))]
[System.Text.Json.Serialization.JsonSerializable(typeof(PowerShellResult))]
internal partial class PowerShellJsonContext : System.Text.Json.Serialization.JsonSerializerContext { }

public static class PowerShellProtocol
{
    public const int Port = 45843;
    public const long ApplicationPermission = 1L << 14;
    public const int MaximumScriptBytes = 16 * 1024;
    public const int MaximumOutputChars = 64 * 1024;
    public const int MaximumWireBytes = 1024 * 1024;

    // These are signed organization claims, never client-supplied role labels.
    // Keep legacy viewing capabilities unchanged so existing students remain compatible.
    public static bool IsAllowed(byte role, long permissions) =>
        role == 2 || (role == 0 && (permissions & ApplicationPermission) != 0);

    public static bool IsAllowed(SupervisorAuthorization authorization) =>
        IsAllowed(authorization.Role, authorization.ApplicationPermissions);

    public static void Validate(PowerShellRequest request)
    {
        if (request.Version is not (1 or 2) || request.Context is not ("SYSTEM" or "USER") ||
            (request.Version == 1 && request.Context != "SYSTEM") || request.Id == Guid.Empty || string.IsNullOrWhiteSpace(request.Script) ||
            request.Script.Contains('\0') || Encoding.UTF8.GetByteCount(request.Script) > MaximumScriptBytes ||
            request.TimeoutSeconds is < 5 or > 600)
            throw new InvalidDataException("Invalid PowerShell request (maximum 16 KB, timeout 5–600 seconds).");
    }

    private static System.Text.Json.Serialization.Metadata.JsonTypeInfo<T> MessageType<T>() =>
        PowerShellJsonContext.Default.GetTypeInfo(typeof(T)) as System.Text.Json.Serialization.Metadata.JsonTypeInfo<T>
        ?? throw new NotSupportedException("Unsupported PowerShell protocol message.");

    public static async Task WriteAsync<T>(Stream stream, T value, CancellationToken token) =>
        await LiveViewProtocol.WriteBlobAsync(stream, JsonSerializer.SerializeToUtf8Bytes(value, MessageType<T>()), token);

    public static async Task<T> ReadAsync<T>(Stream stream, CancellationToken token) =>
        JsonSerializer.Deserialize(await LiveViewProtocol.ReadBlobAsync(stream, token, MaximumWireBytes), MessageType<T>())
        ?? throw new InvalidDataException("Invalid PowerShell response.");
}
