namespace MMS.Core.LiveView;

public static class AudioMonitorProtocol
{
    public const int Port = 45833;
    public const int SampleRate = 48000;
    public const int BitsPerSample = 16;
    public const int Channels = 1;
    public const int MaximumAudioChunkBytes = 128 * 1024;
}
