using System.Buffers.Binary;

namespace MMS.Core.LiveView;

public static class LiveViewProtocol
{
    public const int Port = 45832;
    public const int RemoteControlLeasePort = 45836;
    public const int ChallengeBytes = 32;
    public const int MaximumMessageBytes = 12 * 1024 * 1024;
    public const byte AuthenticationAccepted = 1;
    public const byte FeatureBusy = 2;
    public const byte AuthorizationDenied = 3;

    public static async Task WriteBlobAsync(Stream stream, ReadOnlyMemory<byte> payload, CancellationToken cancellationToken)
    {
        if (payload.Length > MaximumMessageBytes)
        {
            throw new ArgumentOutOfRangeException(nameof(payload));
        }

        var header = new byte[sizeof(int)];
        BinaryPrimitives.WriteInt32BigEndian(header, payload.Length);
        await stream.WriteAsync(header, cancellationToken).ConfigureAwait(false);
        await stream.WriteAsync(payload, cancellationToken).ConfigureAwait(false);
        await stream.FlushAsync(cancellationToken).ConfigureAwait(false);
    }

    public static async Task<byte[]> ReadBlobAsync(Stream stream, CancellationToken cancellationToken, int maximumBytes = MaximumMessageBytes)
    {
        var header = new byte[sizeof(int)];
        await ReadExactlyAsync(stream, header, cancellationToken);
        var length = BinaryPrimitives.ReadInt32BigEndian(header);
        if (length < 0 || length > Math.Min(maximumBytes, MaximumMessageBytes))
        {
            throw new InvalidDataException("Invalid live-view message length.");
        }

        var payload = new byte[length];
        await ReadExactlyAsync(stream, payload, cancellationToken);
        return payload;
    }

    public static async Task ReadExactlyAsync(Stream stream, Memory<byte> buffer, CancellationToken cancellationToken)
    {
        var totalRead = 0;
        while (totalRead < buffer.Length)
        {
            var read = await stream.ReadAsync(buffer[totalRead..], cancellationToken);
            if (read == 0)
            {
                throw new EndOfStreamException("The live-view connection closed unexpectedly.");
            }

            totalRead += read;
        }
    }
}
