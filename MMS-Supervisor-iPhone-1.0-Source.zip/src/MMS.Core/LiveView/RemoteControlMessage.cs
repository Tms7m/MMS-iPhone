using System.Buffers.Binary;

namespace MMS.Core.LiveView;

public enum RemoteControlMessageType : byte
{
    Enable = 1,
    Disable = 2,
    MouseMove = 3,
    MouseButtonDown = 4,
    MouseButtonUp = 5,
    MouseWheel = 6,
    KeyDown = 7,
    KeyUp = 8,
    SelectDisplay = 9
}

public enum RemoteMouseButton : byte
{
    Left = 1,
    Right = 2,
    Middle = 3
}

public readonly record struct RemoteControlMessage(
    RemoteControlMessageType Type,
    ushort X = 0,
    ushort Y = 0,
    RemoteMouseButton MouseButton = 0,
    int Value = 0);

public static class RemoteControlCodec
{
    private const int CoordinateMessageLength = 5;
    private const int ValueMessageLength = 5;

    public static byte[] Encode(RemoteControlMessage message)
    {
        return message.Type switch
        {
            RemoteControlMessageType.Enable or RemoteControlMessageType.Disable => [(byte)message.Type],
            RemoteControlMessageType.MouseMove => EncodeCoordinates(message),
            RemoteControlMessageType.MouseButtonDown or RemoteControlMessageType.MouseButtonUp =>
                [(byte)message.Type, (byte)message.MouseButton],
            RemoteControlMessageType.MouseWheel or RemoteControlMessageType.KeyDown or RemoteControlMessageType.KeyUp or
                RemoteControlMessageType.SelectDisplay =>
                EncodeValue(message),
            _ => throw new ArgumentOutOfRangeException(nameof(message))
        };
    }

    public static bool TryDecode(ReadOnlySpan<byte> payload, out RemoteControlMessage message)
    {
        message = default;
        if (payload.IsEmpty || !Enum.IsDefined((RemoteControlMessageType)payload[0]))
        {
            return false;
        }

        var type = (RemoteControlMessageType)payload[0];
        switch (type)
        {
            case RemoteControlMessageType.Enable:
            case RemoteControlMessageType.Disable:
                if (payload.Length != 1) return false;
                message = new RemoteControlMessage(type);
                return true;

            case RemoteControlMessageType.MouseMove:
                if (payload.Length != CoordinateMessageLength) return false;
                message = new RemoteControlMessage(
                    type,
                    BinaryPrimitives.ReadUInt16BigEndian(payload[1..3]),
                    BinaryPrimitives.ReadUInt16BigEndian(payload[3..5]));
                return true;

            case RemoteControlMessageType.MouseButtonDown:
            case RemoteControlMessageType.MouseButtonUp:
                if (payload.Length != 2 || !Enum.IsDefined((RemoteMouseButton)payload[1])) return false;
                message = new RemoteControlMessage(type, MouseButton: (RemoteMouseButton)payload[1]);
                return true;

            case RemoteControlMessageType.MouseWheel:
            case RemoteControlMessageType.KeyDown:
            case RemoteControlMessageType.KeyUp:
            case RemoteControlMessageType.SelectDisplay:
                if (payload.Length != ValueMessageLength) return false;
                message = new RemoteControlMessage(type, Value: BinaryPrimitives.ReadInt32BigEndian(payload[1..5]));
                return true;

            default:
                return false;
        }
    }

    private static byte[] EncodeCoordinates(RemoteControlMessage message)
    {
        var payload = new byte[CoordinateMessageLength];
        payload[0] = (byte)message.Type;
        BinaryPrimitives.WriteUInt16BigEndian(payload.AsSpan(1, 2), message.X);
        BinaryPrimitives.WriteUInt16BigEndian(payload.AsSpan(3, 2), message.Y);
        return payload;
    }

    private static byte[] EncodeValue(RemoteControlMessage message)
    {
        var payload = new byte[ValueMessageLength];
        payload[0] = (byte)message.Type;
        BinaryPrimitives.WriteInt32BigEndian(payload.AsSpan(1, 4), message.Value);
        return payload;
    }
}
