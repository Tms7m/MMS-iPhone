using System.Buffers.Binary;

namespace MMS.Core.LiveView;

public readonly record struct ThumbnailRequest(ushort DisplayIndex = 0, ushort MaximumWidth = 320);

public readonly record struct ThumbnailResponse(ushort DisplayCount, ushort DisplayIndex, byte[] JpegFrame);

public static class ThumbnailProtocol
{
    public const int Port = 45837;
    private const byte Version = 1;
    private const int RequestLength = 5;
    private const int ResponseHeaderLength = 5;

    public static byte[] EncodeRequest(ThumbnailRequest request)
    {
        if (request.MaximumWidth is < 160 or > 1920) throw new ArgumentOutOfRangeException(nameof(request));
        var payload = new byte[RequestLength];
        payload[0] = Version;
        BinaryPrimitives.WriteUInt16BigEndian(payload.AsSpan(1, 2), request.DisplayIndex);
        BinaryPrimitives.WriteUInt16BigEndian(payload.AsSpan(3, 2), request.MaximumWidth);
        return payload;
    }

    public static bool TryDecodeRequest(ReadOnlySpan<byte> payload, out ThumbnailRequest request)
    {
        request = default;
        if (payload.Length != RequestLength || payload[0] != Version) return false;
        var width = BinaryPrimitives.ReadUInt16BigEndian(payload[3..5]);
        if (width is < 160 or > 1920) return false;
        request = new ThumbnailRequest(BinaryPrimitives.ReadUInt16BigEndian(payload[1..3]), width);
        return true;
    }

    public static byte[] EncodeResponse(ThumbnailResponse response)
    {
        ArgumentNullException.ThrowIfNull(response.JpegFrame);
        if (response.DisplayCount == 0 || response.JpegFrame.Length == 0) throw new ArgumentOutOfRangeException(nameof(response));
        var payload = new byte[ResponseHeaderLength + response.JpegFrame.Length];
        payload[0] = Version;
        BinaryPrimitives.WriteUInt16BigEndian(payload.AsSpan(1, 2), response.DisplayCount);
        BinaryPrimitives.WriteUInt16BigEndian(payload.AsSpan(3, 2), response.DisplayIndex);
        response.JpegFrame.CopyTo(payload, ResponseHeaderLength);
        return payload;
    }

    public static bool TryDecodeResponse(ReadOnlySpan<byte> payload, out ThumbnailResponse response)
    {
        response = default;
        if (payload.Length <= ResponseHeaderLength || payload[0] != Version) return false;
        var displayCount = BinaryPrimitives.ReadUInt16BigEndian(payload[1..3]);
        var displayIndex = BinaryPrimitives.ReadUInt16BigEndian(payload[3..5]);
        if (displayCount == 0 || displayIndex >= displayCount) return false;
        response = new ThumbnailResponse(displayCount, displayIndex, payload[ResponseHeaderLength..].ToArray());
        return true;
    }
}
