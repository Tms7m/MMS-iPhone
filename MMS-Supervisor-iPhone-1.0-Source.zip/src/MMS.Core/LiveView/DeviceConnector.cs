using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;

namespace MMS.Core.LiveView;

public static class DeviceConnector
{
    private static readonly ConcurrentDictionary<Guid, string> Preferred = new();
    public static async Task<TcpClient> ConnectAsync(Guid device, IEnumerable<string> addresses, int port, CancellationToken token)
    {
        var candidates = addresses.Where(address => IPAddress.TryParse(address, out _) || Uri.CheckHostName(address) == UriHostNameType.Dns)
            .Distinct(StringComparer.OrdinalIgnoreCase).Take(16).ToList();
        if (Preferred.TryGetValue(device, out var preferred) && candidates.Remove(preferred))
            candidates.Insert(0, preferred);
        if (candidates.Count == 0) throw new IOException("No usable student address.");
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(token);
        deadline.CancelAfter(TimeSpan.FromSeconds(4));
        Exception? lastFailure = null;
        var attempts = candidates.Select((address, index) => Attempt(address, index)).ToList();
        TcpClient? winner = null;
        try
        {
            while (attempts.Count > 0)
            {
                var done = await Task.WhenAny(attempts).ConfigureAwait(false);
                attempts.Remove(done);
                winner = await done.ConfigureAwait(false);
                if (winner is null) continue;
                if (Preferred.Count < 5000 || Preferred.ContainsKey(device))
                    Preferred[device] = ((IPEndPoint)winner.Client.RemoteEndPoint!).Address.ToString();
                token.ThrowIfCancellationRequested();
                return winner;
            }
            token.ThrowIfCancellationRequested();
            Preferred.TryRemove(device, out _);
            throw new IOException($"Student TCP {port} is unreachable.", lastFailure);
        }
        catch { winner?.Dispose(); throw; }
        finally
        {
            deadline.Cancel();
            foreach (var pending in attempts) (await pending.ConfigureAwait(false))?.Dispose();
        }
        async Task<TcpClient?> Attempt(string address, int index)
        {
            var client = new TcpClient { NoDelay = true };
            try
            {
                if (index > 0) await Task.Delay(Math.Min(index * 150, 600), deadline.Token).ConfigureAwait(false);
                await client.ConnectAsync(address, port, deadline.Token).ConfigureAwait(false);
                return client;
            }
            catch (Exception ex) when (ex is SocketException or OperationCanceledException)
            {
                if (ex is SocketException) Interlocked.Exchange(ref lastFailure, ex);
                client.Dispose(); return null;
            }
        }
    }
}
