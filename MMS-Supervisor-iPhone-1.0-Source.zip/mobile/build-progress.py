"""Run a build with elapsed time and macOS runner compiler CPU samples."""
import os
import subprocess
import sys
import time


def sample_cpu():
    try:
        snapshot = subprocess.run(
            ["ps", "-axo", "pcpu=,time=,comm="],
            capture_output=True, text=True, check=True, timeout=5,
        )
    except (OSError, subprocess.SubprocessError):
        return "CPU sample unavailable"

    rows = []
    for line in snapshot.stdout.splitlines():
        fields = line.split(None, 2)
        if len(fields) != 3:
            continue
        cpu, cpu_time, path = fields
        name = os.path.basename(path)
        if name in {"dotnet", "llc", "ld", "ld64", "clang", "clang++", "ilstrip"} or name.startswith("mono-aot-cross"):
            rows.append(f"{name} {cpu}% (CPU time {cpu_time})")
    return ", ".join(rows) or "no matching compiler processes"


def run(label, command, interval=30):
    start = time.monotonic()
    print(f"[{label}] starting", flush=True)
    with subprocess.Popen(command) as process:
        while True:
            try:
                status = process.wait(timeout=interval)
                break
            except subprocess.TimeoutExpired:
                print(f"[{label}] elapsed={time.monotonic()-start:.0f}s | runner compiler CPU: {sample_cpu()}", flush=True)
    print(f"[{label}] elapsed={time.monotonic()-start:.0f}s | exit={status}", flush=True)
    return status if status >= 0 else 128 - status


if __name__ == "__main__":
    sys.exit(run(sys.argv[1], sys.argv[2:]))
