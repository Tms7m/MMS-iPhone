using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using MMS.Mobile;
using MMS.Core.Security;
using MMS.Core.LiveView;

using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(60));
var ct=timeout.Token;
using var root=RSA.Create(3072); using var issuer=RSA.Create(3072);
using var user=RSA.Create(3072); using var deviceKey=RSA.Create(3072);
var start=DateTimeOffset.UtcNow.AddMinutes(-5); var end=start.AddDays(1);
var authority=SupervisorAuthorizationCodec.Issue(Guid.NewGuid(),"Issuer",250,0,start,end,issuer.ExportSubjectPublicKeyInfo(),root);
var userId=Guid.NewGuid(); var deviceId=Guid.NewGuid(); var org=Guid.NewGuid(); const string serial="TEST-SERIAL";
var userChain=TrustChainValidator.Encode(authority,SupervisorAuthorizationCodec.Issue(userId,"test",2,SessionCapability.ViewLive,start,end,user.ExportSubjectPublicKeyInfo(),issuer,1));
var deviceChain=TrustChainValidator.Encode(authority,SupervisorAuthorizationCodec.Issue(deviceId,serial,255,0,start,end,deviceKey.ExportSubjectPublicKeyInfo(),issuer));
var policy=OrganizationPolicy.Encode(new(OrganizationPolicy.SignAuthority(new(TrustChainValidator.Hash(root.ExportSubjectPublicKeyInfo()),1,start,TrustChainValidator.Hash(authority),[]),root),
    OrganizationPolicy.SignCredentials(new(1,1,start,end.AddMinutes(-1),[]),authority,issuer)));
const string password="Testing with ephemeral keys", secret="Test synchronization secret";
var salt=RandomNumberGenerator.GetBytes(32);
var verifier=Rfc2898DeriveBytes.Pbkdf2(password,salt,310000,HashAlgorithmName.SHA256,32);
var login=Convert.ToHexString(SHA256.HashData("demo\ntest"u8)).ToLowerInvariant();
var encryptedKey=Seal(user.ExportPkcs8PrivateKey(),verifier,userId.ToByteArray());
var account=new {Id=userId,UserName="test",Role=2,IsSuspended=false,AuthorizationCertificate=userChain,AuthorizationKeySalt=salt,
    EncryptedAuthorizationPrivateKey=encryptedKey.Ciphertext,AuthorizationKeyNonce=encryptedKey.Nonce,AuthorizationKeyTag=encryptedKey.Tag};
var payload=new {SourceName="demo",Account=account,Enrollment=new {InternetOrganizationId=org,PocketBaseUrl="https://sync.hikaaya.com",
    PocketBaseReaderIdentity="reader",PocketBaseReaderPassword="reader-test",SyncSecret=secret,SecurityPolicies=policy,SecurityRootPublic=Encoding.ASCII.GetBytes(root.ExportSubjectPublicKeyInfoPem())}};
var envelope=Seal(FixtureJson.SerializeToUtf8Bytes(payload),HMACSHA256.HashData(verifier,Encoding.UTF8.GetBytes("MMS-ONLINE-ENVELOPE-1|"+login)),Encoding.UTF8.GetBytes(login));
// Exercise the direct (no OTP) download path with independently damaged setup data.
foreach (var (label,expected) in new[] { ("success",""), ("download","MMS-L01"), ("envelope","MMS-L06"), ("policy","MMS-L11"), ("private-key","MMS-L17") })
{
    var setup=FixtureJson.SerializeToNode(payload)!;
    if(label=="policy") setup["Enrollment"]!["SecurityPolicies"]="not-base64";
    if(label=="private-key") setup["Account"]!["AuthorizationKeyTag"]=Convert.ToBase64String(new byte[16]);
    var encrypted=Seal(FixtureJson.SerializeToUtf8Bytes(setup),
        HMACSHA256.HashData(verifier,Encoding.UTF8.GetBytes("MMS-ONLINE-ENVELOPE-1|"+login)),Encoding.UTF8.GetBytes(login));
    var encoded=FixtureJson.Serialize(new {Version=1,encrypted.Nonce,encrypted.Ciphertext,Tag=label=="envelope"?new byte[16]:encrypted.Tag});
    using var testHttp=new HttpClient(new Stub(req=>{
        object result=req.RequestUri!.AbsolutePath switch {
            "/api/mms/setup/challenge"=>new {salt},
            "/api/collections/mms_setup_accounts/auth-with-password"=>new {token="test-token"},
            "/api/mms/setup/download"=>new {payload=encoded},
            _=>throw new InvalidOperationException("Unexpected request")
        };
        var denied=label=="download" && req.RequestUri.AbsolutePath.EndsWith("/download");
        return Task.FromResult(new HttpResponseMessage(denied?HttpStatusCode.Forbidden:HttpStatusCode.OK)
            {Content=new StringContent(FixtureJson.Serialize(result))});
    })){BaseAddress=new Uri("https://sync.hikaaya.com/")};
    try
    {
        using var unexpected=await MobileSession.Login(testHttp,"demo","test",password,_=>throw new InvalidOperationException(),ct);
        if(label != "success") throw new InvalidOperationException("Corrupted setup accepted");
    }
    catch(LoginDiagnosticException ex) when(ex.Message.StartsWith(expected+" · ") &&
        !ex.Message.Contains(password) && !ex.Message.Contains("test-token") &&
        (label!="download" || ex.Message.EndsWith("HTTP 403"))) { }
}
if (JsonSerializer.IsReflectionEnabledByDefault) throw new InvalidOperationException("Expected reflection-free client test.");
var bridgePayload = new JsonObject { ["user"]="test", ["developer"]=true };
var encodedBridge = JsonSerializer.Serialize((JsonNode)bridgePayload, MobileJsonContext.Default.JsonNode);
if (JsonNode.Parse(encodedBridge)!["developer"]!.GetValue<bool>() != true) throw new InvalidDataException();
Console.WriteLine("PASS direct sign-in and signed bridge payload with reflection disabled");
Console.WriteLine("PASS four post-authentication failures identify the correct stage");
var groupId=Guid.NewGuid();
var saved=new { GroupId=groupId, AgentId=deviceId,UserName="طالب تجريبي",Hostname="localhost",SerialNumber=serial,IpAddresses=new[]{"127.0.0.1"} };
var snap=Seal(FixtureJson.SerializeToUtf8Bytes(new{Catalog=new{Groups=new[]{new {Id=groupId,Name="Group A"}},Devices=new[]{saved}}}), Rfc2898DeriveBytes.Pbkdf2(secret,salt,310000,HashAlgorithmName.SHA256,32),"MMS-SYNC-1"u8.ToArray());
var snapshot=FixtureJson.SerializeToUtf8Bytes(new{Version=1,Salt=salt,snap.Ciphertext,snap.Tag,snap.Nonce});
var events=new List<string>(); var pulses=new List<bool>();
using var http=new HttpClient(new Stub(async request=>{
    var path=request.RequestUri!.AbsolutePath;
    var body=request.Content==null?null:JsonNode.Parse(await request.Content.ReadAsStringAsync());
    if(path=="/api/mms/audit/session" || path=="/api/mms/audit/presence")
    {
        if(request.Headers.Authorization?.Scheme!="operator" || body!["subjectId"]!.ToString()!=userId.ToString("N")) throw new InvalidDataException();
        if(path.EndsWith("presence")) pulses.Add(body["closed"]!.GetValue<bool>()); else events.Add(body["action"]!.ToString());
    }
    object reply=path switch{
        "/api/mms/audit/session" or "/api/mms/audit/presence"=>new{accepted=true},
        "/api/mms/setup/challenge" when body!["loginId"]!.ToString()==login=>new{salt},
        "/api/collections/mms_setup_accounts/auth-with-password" when body!["password"]!.ToString()==Convert.ToBase64String(HMACSHA256.HashData(verifier,Encoding.UTF8.GetBytes("MMS-ONLINE-LOGIN-1|"+login)))=>new{token="operator"},
        "/api/mms/setup/download"=>new{otpRequired=true},
        "/api/mms/setup/email/start"=>new{challenge="test"},
        "/api/mms/setup/email/download" when body!["code"]!.ToString()=="123456"=>new{payload=FixtureJson.Serialize(new{Version=1,envelope.Ciphertext,envelope.Tag,envelope.Nonce})},
        "/api/collections/mms_sync_clients/auth-with-password"=>new{token="reader"},
        "/api/collections/mms_sync_snapshots/records"=>new{items=new[]{new{payload=snapshot,payloadHash=Convert.ToHexString(SHA256.HashData(snapshot))}}},
        "/api/collections/mms_group_moves/records"=>new{items=Array.Empty<object>()},
        "/api/collections/mms_registered_devices/records"=>new{totalPages=0,items=Array.Empty<object>()},
        "/api/collections/mms_session_presence/records"=>new{totalPages=1,items=new[]{new{userName="admin",computer="QA-PC",closed=false,seen=DateTimeOffset.UtcNow}}},
        "/api/collections/mms_session_audit/records"=>new{items=new[]{new{userName="admin",action="SIGN_IN"}}},
        _=>throw new InvalidOperationException(path)};
    return new HttpResponseMessage(path=="/api/mms/setup/download"?HttpStatusCode.Forbidden:HttpStatusCode.OK){Content=new StringContent(FixtureJson.Serialize(reply))};
})){BaseAddress=new Uri("https://sync.hikaaya.com")};
using var client=await MobileSession.Login(http,"demo","test",password,_=>Task.FromResult("123456"),ct);
var selected=(await client.Devices(ct)).Single();
var audit=await client.Audit(ct);
if(selected.GroupId!=groupId.ToString("D") || selected.Group!="Group A" || selected.AgentId!=deviceId || !audit["presence"]![0]!["online"]!.GetValue<bool>() || audit["events"]![0]!["action"]!.ToString()!="SIGN_IN")throw new InvalidDataException();
await client.ReportEvent("test-phone",false,Guid.NewGuid(),DateTimeOffset.UtcNow,ct);
await client.ReportPresence("test-phone",false,ct);
await client.ReportPresence("test-phone",true,ct);
await client.ReportEvent("test-phone",true,Guid.NewGuid(),DateTimeOffset.UtcNow,ct);
if(!pulses.SequenceEqual(new[]{false,true}) || !events.SequenceEqual(new[]{"SIGN_IN","SIGN_OUT"}))throw new InvalidDataException();
Console.WriteLine("PASS mobile session sign-in/out and heartbeat");
Console.WriteLine("PASS login with OTP, protected snapshot, supervisor presence and audit");
foreach(var (live,wrongIdentity) in new[]{(false,false),(true,false),(true,true)})
{
    using var listener=new TcpListener(IPAddress.Loopback,live?LiveViewProtocol.Port:ThumbnailProtocol.Port);listener.Start();
    using var temp=RSA.Create(2048);
    using var created=new CertificateRequest("CN=localhost",temp,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1).CreateSelfSigned(start,end);
    using var cert=new X509Certificate2(created.Export(X509ContentType.Pfx));
    var server=Task.Run(async ()=>{
        using var accepted=await listener.AcceptTcpClientAsync(ct); using var tls=new SslStream(accepted.GetStream());
        await tls.AuthenticateAsServerAsync(cert);
        var n=await LiveViewProtocol.ReadBlobAsync(tls,ct);
        await CompactPolicyExchange.ServerAsync(tls,()=>policy,(_,_)=>Task.CompletedTask,ct);
        var remote=RandomNumberGenerator.GetBytes(32);var hash=SHA256.HashData(cert.RawData);
        await LiveViewProtocol.WriteBlobAsync(tls,remote,ct);
        await LiveViewProtocol.WriteBlobAsync(tls,DeviceSessionProof.Sign(deviceChain,deviceKey,n,remote,hash),ct);
        var challenge=RandomNumberGenerator.GetBytes(32);await LiveViewProtocol.WriteBlobAsync(tls,challenge,ct);
        if(wrongIdentity)
        {
            int received;
            try { received=await tls.ReadAsync(new byte[1],ct); }
            catch(IOException e) when(e.InnerException is SocketException { SocketErrorCode: SocketError.ConnectionReset })
            { received=0; } // A rejected connection can close with TCP reset on Windows.
            if(received!=0) throw new InvalidDataException("Account proof disclosed to a mismatched device");
            return;
        }
        var response=await LiveViewProtocol.ReadBlobAsync(tls,ct);
        if(!SupervisorAuthorizationCodec.TryDecodeProof(response,out var chain,out var sig) || !chain.SequenceEqual(userChain) ||
            !user.VerifyData(SupervisorAuthorizationCodec.CreateSessionPayload(challenge,hash,chain),sig,HashAlgorithmName.SHA256,RSASignaturePadding.Pss))
            throw new InvalidDataException("Invalid supervisor proof");
        await tls.WriteAsync(new byte[]{1},ct);
        if(!live && !ThumbnailProtocol.TryDecodeRequest(await LiveViewProtocol.ReadBlobAsync(tls,ct),out _)) throw new InvalidDataException();
        await LiveViewProtocol.WriteBlobAsync(tls,live?"frame"u8.ToArray():ThumbnailProtocol.EncodeResponse(new(1,0,"frame"u8.ToArray())),ct);
    },ct);
    if(wrongIdentity)
    {
        var rejected=false;
        try { await foreach(var _ in client.Frames(selected with { Serial="OTHER" },true,ct)) break; }
        catch(InvalidDataException) { rejected=true; }
        if(!rejected) throw new InvalidDataException("Wrong enrolled serial accepted");
        await server; Console.WriteLine("PASS mismatched identity rejected before sending account proof"); continue;
    }
    await foreach(var frame in client.Frames(selected,live,ct)){if(!frame.SequenceEqual("frame"u8.ToArray()))throw new InvalidDataException();break;}
    await server;
    Console.WriteLine(live?"PASS authenticated Live View channel and frame delivery":"PASS authenticated thumbnail request and frame delivery");
}
// A real encrypted organization recovery envelope, exercised against an isolated server.
var recoveryKey=RandomNumberGenerator.GetBytes(32);
var rootBox=Seal(root.ExportPkcs8PrivateKey(),recoveryKey,Encoding.UTF8.GetBytes("MMS.AccountKey.v1|"+userId.ToString("N")+"|organization-recovery"));
var recoverySetup=FixtureJson.SerializeToNode(payload)!;
var recoveryAccount=recoverySetup["Account"]!;
recoveryAccount["RecoveryEnvelope"]=Convert.ToBase64String(FixtureJson.SerializeToUtf8Bytes(new {Version=1,Key=user.Encrypt(recoveryKey,RSAEncryptionPadding.OaepSHA256),rootBox.Ciphertext,rootBox.Nonce,rootBox.Tag}));
recoveryAccount["AuthorizationPublicKey"]=Convert.ToBase64String(user.ExportSubjectPublicKeyInfo());
recoveryAccount["PasswordHash"]=Convert.ToBase64String(verifier);
var before=Seal(Encoding.UTF8.GetBytes(recoverySetup.ToJsonString()),HMACSHA256.HashData(verifier,Encoding.UTF8.GetBytes("MMS-ONLINE-ENVELOPE-1|"+login)),Encoding.UTF8.GetBytes(login));
bool committed=false;
using var recoveryHttp=new HttpClient(new Stub(async req=>{
    if(req.RequestUri!.AbsolutePath.EndsWith("/verify"))
        return new HttpResponseMessage(HttpStatusCode.OK){Content=new StringContent(FixtureJson.Serialize(new {verifier,privateKey=user.ExportPkcs8PrivateKey(),payload=FixtureJson.Serialize(new {Version=1,before.Nonce,before.Tag,before.Ciphertext}),subjectId=userId.ToString("N"),email="test@example.invalid",epoch=0,ticket="one-time"}))};
    var commit=JsonNode.Parse(await req.Content!.ReadAsStringAsync())!;
    var newHash=Rfc2898DeriveBytes.Pbkdf2("new-test-password",Convert.FromBase64String(commit["salt"]!.ToString()),310000,HashAlgorithmName.SHA256,32);
    if(!req.RequestUri.AbsolutePath.EndsWith("/commit") || commit["ticket"]!.ToString()!="one-time" || Convert.ToBase64String(newHash)!=commit["verifier"]!.ToString()) throw new InvalidDataException("Reset commit mismatch");
    committed=true;
    return new HttpResponseMessage(HttpStatusCode.OK){Content=new StringContent("{}")};
})){BaseAddress=new Uri("https://sync.hikaaya.com/")};
await MobileSession.ResetPassword(recoveryHttp,"demo","test","challenge","123456","new-test-password",ct);
if(!committed) throw new InvalidOperationException();
Console.WriteLine("PASS email recovery rewraps the same account key before committing the new password");
static (byte[] Nonce,byte[] Ciphertext,byte[] Tag) Seal(byte[] plain,byte[] key,byte[] aad)
{
    using var aes=new AesGcm(key,16);var nonce=RandomNumberGenerator.GetBytes(12);var cipher=new byte[plain.Length];var tag=new byte[16];
    aes.Encrypt(nonce,plain,cipher,tag,aad);return(nonce,cipher,tag);
}
sealed class Stub(Func<HttpRequestMessage,Task<HttpResponseMessage>> handle):HttpMessageHandler
{
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken cancellationToken)=>handle(request);
}

// Mock server only. Its synthetic anonymous fixtures use a separate serializer.
static class FixtureJson
{
    private static readonly JsonSerializerOptions Options = new()
    {
        TypeInfoResolver = new System.Text.Json.Serialization.Metadata.DefaultJsonTypeInfoResolver()
    };
    public static string Serialize<T>(T value) => JsonSerializer.Serialize(value, Options);
    public static byte[] SerializeToUtf8Bytes<T>(T value) => JsonSerializer.SerializeToUtf8Bytes(value, Options);
    public static JsonNode? SerializeToNode<T>(T value) => JsonSerializer.SerializeToNode(value, Options);
}
