#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mode=${1:---ipa}
case "$mode" in
  --startup-only|--ipa) ;;
  *) echo "Usage: bash mobile/build-ipa.sh [--startup-only|--ipa]" >&2; exit 2 ;;
esac
xcodebuild -version
# Exercise UIKit scene creation and the WebKit login/bridge before packaging.
if [[ "$mode" == --startup-only || -n "${GITHUB_ACTIONS:-}" ]]; then
  sim=$(xcrun simctl list devices available -j | python3 -c '
import json,sys
devices=json.load(sys.stdin)["devices"].get("com.apple.CoreSimulator.SimRuntime.iOS-26-2",[])
print(next(d["udid"] for d in devices if d["name"].startswith("iPhone")))') 
  xcrun simctl bootstatus "$sim" -b
  python3 mobile/build-progress.py simulator-debug dotnet build mobile/iPhone/MMS.iPhone.csproj -c Debug -f net10.0-ios -r iossimulator-arm64 -p:UseInterpreter=true
  simapp=mobile/iPhone/bin/Debug/net10.0-ios/iossimulator-arm64/MMS.iPhone.app
  scene_delegate=$(/usr/libexec/PlistBuddy -c 'Print UIApplicationSceneManifest:UISceneConfigurations:UIWindowSceneSessionRoleApplication:0:UISceneDelegateClassName' "$simapp/Info.plist")
  [[ "$scene_delegate" == "MMSSceneDelegate" ]]
  test -d "$simapp/Main.storyboardc"
  xcrun simctl install "$sim" "$simapp"
  bundle=$(/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$simapp/Info.plist")
  data=$(xcrun simctl get_app_container "$sim" "$bundle" data)
  marker="$data/Documents/mms-login-ready"
  rm -f "$marker" "$data/Documents/mms-startup-trace"
  trace_dir=$(mktemp -d)
  xcrun simctl launch --console "$sim" "$bundle" > "$trace_dir/console" 2>&1 &
  console_pid=$!
  data=$(xcrun simctl get_app_container "$sim" "$bundle" data)
  marker="$data/Documents/mms-login-ready"
  for attempt in {1..60}; do [[ ! -s "$marker" ]] || break; kill -0 "$console_pid" 2>/dev/null || break; sleep 1; done
  if [[ ! -s "$marker" ]]; then
    if [[ -f "$data/Documents/mms-startup-trace" ]]; then cat "$data/Documents/mms-startup-trace"; else echo "No startup stages recorded"; fi
    cat "$trace_dir/console"
    xcrun simctl spawn "$sim" log show --last 2m --style compact --predicate 'process == "MMS.iPhone" OR (eventMessage CONTAINS[c] "com.hikaaya.mms.supervisor" AND (messageType == error OR messageType == fault))' | grep -Ei "error|exception|class|delegate|storyboard|window|abort|fault|MMS startup" | head -n 100 || true
    echo "::error::iOS startup test failed: the sign-in form did not become visible or its JavaScript bridge did not start."
    exit 1
  fi
  echo "PASS: visible login form and native bridge in the iPhone simulator"
  xcrun simctl terminate "$sim" "$bundle"
  wait "$console_pid" || true
  xcrun simctl shutdown "$sim"
  if [[ "$mode" == --startup-only ]]; then exit 0; fi
fi
python3 mobile/build-progress.py device-release dotnet build mobile/iPhone/MMS.iPhone.csproj -c Release -f net10.0-ios -r ios-arm64 \
  -p:MtouchUseLlvm=false -p:EnableCodeSigning=false -p:CodesignRequireProvisioningProfile=false
app=$(find mobile/iPhone/bin/Release/net10.0-ios/ios-arm64 -maxdepth 1 -name '*.app' -type d -print -quit)
test -d "$app"
executable=$(/usr/libexec/PlistBuddy -c 'Print CFBundleExecutable' "$app/Info.plist")
test -x "$app/$executable"
xcrun lipo "$app/$executable" -verify_arch arm64
xcrun vtool -show-build "$app/$executable" | grep -Eq 'platform IOS$'
test -d "$app/Main.storyboardc"
test -s "$app/Web/index.html"
test -s "$app/Web/app.js"
mkdir -p artifacts
staging=$(mktemp -d)
mkdir "$staging/Payload"
ditto "$app" "$staging/Payload/$(basename "$app")"
out="$PWD/artifacts/MMS-Supervisor-unsigned.ipa"
ditto -c -k --keepParent "$staging/Payload" "$out"
unzip -tq "$out"
shasum -a 256 "$out"
