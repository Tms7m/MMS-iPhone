#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
xcodebuild -version
dotnet build mobile/iPhone/MMS.iPhone.csproj -c Release -f net10.0-ios -r ios-arm64 \
  -p:EnableCodeSigning=false -p:CodesignRequireProvisioningProfile=false
app=$(find mobile/iPhone/bin/Release/net10.0-ios/ios-arm64 -maxdepth 1 -name '*.app' -type d -print -quit)
test -d "$app"
executable=$(/usr/libexec/PlistBuddy -c 'Print CFBundleExecutable' "$app/Info.plist")
test -x "$app/$executable"
xcrun lipo "$app/$executable" -verify_arch arm64
xcrun vtool -show-build "$app/$executable" | grep -Eq 'platform IOS$'
test -s "$app/Web/index.html"
test -s "$app/Web/app.js"
mkdir -p artifacts
staging=$(mktemp -d)
mkdir "$staging/Payload"
ditto "$app" "$staging/Payload/$(basename "$app")"
out="$PWD/artifacts/MMS-Supervisor-unsigned.ipa"
ditto -c -k --keepParent "$staging/Payload" "$out"
unzip -tq "$out"
shasum -a 256 "$out"
