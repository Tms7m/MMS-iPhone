#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
xcodebuild -version
# Exercise UIKit scene creation and the WebKit login/bridge before packaging.
if [[ -n "${GITHUB_ACTIONS:-}" ]]; then
  sim=$(xcrun simctl list devices available -j | python3 -c '
import json,sys
devices=json.load(sys.stdin)["devices"].get("com.apple.CoreSimulator.SimRuntime.iOS-26-2",[])
print(next(d["udid"] for d in devices if d["name"].startswith("iPhone")))') 
  xcrun simctl bootstatus "$sim" -b
  dotnet build mobile/iPhone/MMS.iPhone.csproj -c Release -f net10.0-ios -r iossimulator-arm64
  simapp=mobile/iPhone/bin/Release/net10.0-ios/iossimulator-arm64/MMS.iPhone.app
  xcrun simctl install "$sim" "$simapp"
  bundle=$(/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$simapp/Info.plist")
  data=$(xcrun simctl get_app_container "$sim" "$bundle" data)
  marker="$data/Documents/mms-login-ready"
  test ! -e "$marker"
  SIMCTL_CHILD_MMS_STARTUP_TEST=1 xcrun simctl launch "$sim" "$bundle" --mms-startup-test
  for attempt in {1..60}; do [[ ! -s "$marker" ]] || break; sleep 1; done
  if [[ ! -s "$marker" ]]; then
    if [[ -f "$data/Documents/mms-startup-trace" ]]; then cat "$data/Documents/mms-startup-trace"; else echo "No startup stages recorded"; fi
    echo "::error::iOS startup test failed: the sign-in form did not become visible or its JavaScript bridge did not start."
    exit 1
  fi
  echo "PASS: visible login form and native bridge in the iPhone simulator"
  xcrun simctl shutdown "$sim"
fi
dotnet build mobile/iPhone/MMS.iPhone.csproj -c Release -f net10.0-ios -r ios-arm64 \
  -p:EnableCodeSigning=false -p:CodesignRequireProvisioningProfile=false
app=$(find mobile/iPhone/bin/Release/net10.0-ios/ios-arm64 -maxdepth 1 -name '*.app' -type d -print -quit)
test -d "$app"
executable=$(/usr/libexec/PlistBuddy -c 'Print CFBundleExecutable' "$app/Info.plist")
test -x "$app/$executable"
xcrun lipo "$app/$executable" -verify_arch arm64
xcrun vtool -show-build "$app/$executable" | grep -Eq 'platform IOS$'
test -s "$app/Web/index.html"
test -s "$app/Web/app.js"
mkdir -p artifacts
staging=$(mktemp -d)
mkdir "$staging/Payload"
ditto "$app" "$staging/Payload/$(basename "$app")"
out="$PWD/artifacts/MMS-Supervisor-unsigned.ipa"
ditto -c -k --keepParent "$staging/Payload" "$out"
unzip -tq "$out"
shasum -a 256 "$out"
