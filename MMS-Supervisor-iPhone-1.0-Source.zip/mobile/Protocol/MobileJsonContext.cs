using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace MMS.Mobile;

[JsonSerializable(typeof(JsonObject))]
[JsonSerializable(typeof(JsonNode))]
[JsonSerializable(typeof(string))]
public partial class MobileJsonContext : JsonSerializerContext { }
