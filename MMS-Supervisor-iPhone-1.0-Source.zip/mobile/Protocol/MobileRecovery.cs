using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;

namespace MMS.Mobile;

public sealed partial class MobileSession
{
    private static string RecoveryLogin(string org,string user) => Convert.ToHexString(SHA256.HashData(
        Encoding.UTF8.GetBytes(org.Trim().ToLowerInvariant()+"\n"+user.Trim().ToLowerInvariant()))).ToLowerInvariant();

    public static async Task<string> RequestRecovery(string org,string user,CancellationToken ct) =>
        Text(await Success(Api,"api/mms/password/start",new(){["loginId"]=RecoveryLogin(org,user)},null,ct),"challenge");

    public static Task ResetPassword(string org,string user,string challenge,string code,string password,CancellationToken ct)
        => ResetPassword(Api,org,user,challenge,code,password,ct);

    internal static async Task ResetPassword(HttpClient http,string org,string user,string challenge,string code,string password,CancellationToken ct)
    {
        if(password.Length is <10 or >1024) throw new InvalidDataException("Password length");
        org=org.Trim().ToLowerInvariant(); user=user.Trim().ToLowerInvariant();
        var login=RecoveryLogin(org,user);
        var reply=await Success(http,"api/mms/password/verify",new(){["loginId"]=login,["challenge"]=challenge,["code"]=code.Trim()},null,ct);
        var secrets=new List<byte[]>();
        byte[] Keep(byte[] bytes) { secrets.Add(bytes); return bytes; }
        byte[] Context(string prefix)=>Encoding.UTF8.GetBytes(prefix+login);
        JsonObject Seal(byte[] plain,byte[] key,byte[] aad)
        {
            var nonce=RandomNumberGenerator.GetBytes(12); var tag=new byte[16]; var cipher=new byte[plain.Length];
            using var aes=new AesGcm(key,16); aes.Encrypt(nonce,plain,cipher,tag,aad);
            return new(){["Version"]=1,["Ciphertext"]=Convert.ToBase64String(cipher),["Nonce"]=Convert.ToBase64String(nonce),["Tag"]=Convert.ToBase64String(tag)};
        }
        try
        {
            var old=Keep(Bytes(reply,"verifier")); var privateKey=Keep(Bytes(reply,"privateKey"));
            var key=Keep(HMACSHA256.HashData(old,Context("MMS-ONLINE-ENVELOPE-1|")));
            var aad=Context("");
            var setup=JsonNode.Parse(Keep(Open(JsonNode.Parse(Text(reply,"payload"))!,key,aad)))!;
            var account=setup["Account"]!;
            var id=Guid.Parse(Text(account,"Id"));
            var epoch=reply["epoch"]!.GetValue<long>();
            if(Text(setup,"SourceName")!=org || !Text(account,"UserName").Equals(user,StringComparison.OrdinalIgnoreCase) ||
                id.ToString("N")!=Text(reply,"subjectId") || account["Role"]!.GetValue<int>()!=2 || account["IsSuspended"]!.GetValue<bool>() ||
                epoch<0 || !CryptographicOperations.FixedTimeEquals(old,Bytes(account,"PasswordHash"))) throw new InvalidDataException("Recovery identity");
            using var rsa=RSA.Create(); rsa.ImportPkcs8PrivateKey(privateKey,out var used);
            if(used!=privateKey.Length || !rsa.ExportSubjectPublicKeyInfo().AsSpan().SequenceEqual(Bytes(account,"AuthorizationPublicKey"))) throw new InvalidDataException("Recovery credential");
            var rootEnvelope=JsonNode.Parse(Bytes(account,"RecoveryEnvelope"))!;
            var wrapping=Keep(rsa.Decrypt(Bytes(rootEnvelope,"Key"),RSAEncryptionPadding.OaepSHA256));
            var rootBytes=Keep(Open(rootEnvelope,wrapping,Encoding.UTF8.GetBytes("MMS.AccountKey.v1|"+id.ToString("N")+"|organization-recovery")));
            using var recoveredRoot=RSA.Create(); recoveredRoot.ImportPkcs8PrivateKey(rootBytes,out _);
            using var expectedRoot=RSA.Create(); expectedRoot.ImportFromPem(Encoding.ASCII.GetString(Bytes(setup["Enrollment"]!,"SecurityRootPublic")));
            if(!recoveredRoot.ExportSubjectPublicKeyInfo().AsSpan().SequenceEqual(expectedRoot.ExportSubjectPublicKeyInfo())) throw new InvalidDataException("Recovery root");
            var salt=RandomNumberGenerator.GetBytes(32); var verifier=Keep(Derive(password,salt));
            var privateSalt=RandomNumberGenerator.GetBytes(32); var sealedKey=Seal(privateKey,Keep(Derive(password,privateSalt)),id.ToByteArray());
            account["Salt"]=Convert.ToBase64String(salt); account["PasswordHash"]=Convert.ToBase64String(verifier);
            account["AuthorizationKeySalt"]=Convert.ToBase64String(privateSalt);
            account["AuthorizationKeyNonce"]=Text(sealedKey,"Nonce"); account["AuthorizationKeyTag"]=Text(sealedKey,"Tag");
            account["EncryptedAuthorizationPrivateKey"]=Text(sealedKey,"Ciphertext"); account["PasswordResetEpoch"]=checked(epoch+1);
            account["RecoveryEmail"]=Text(reply,"email");
            var newKey=Keep(HMACSHA256.HashData(verifier,Context("MMS-ONLINE-ENVELOPE-1|")));
            var envelope=Seal(Keep(Encoding.UTF8.GetBytes(setup.ToJsonString())),newKey,aad);
            var stage="recovery";
            using var checkedAccount=new MobileSession(Api,JsonNode.Parse(Keep(Open(envelope,newKey,aad)))!,org,user,password,"",ref stage);
            await Success(http,"api/mms/password/commit",new(){["ticket"]=Text(reply,"ticket"),["salt"]=Convert.ToBase64String(salt),
                ["password"]=Convert.ToBase64String(HMACSHA256.HashData(verifier,Context("MMS-ONLINE-LOGIN-1|"))),
                ["verifier"]=Convert.ToBase64String(verifier),["payload"]=envelope.ToJsonString()},null,ct);
        }
        finally { foreach(var bytes in secrets) CryptographicOperations.ZeroMemory(bytes); }
    }
}
