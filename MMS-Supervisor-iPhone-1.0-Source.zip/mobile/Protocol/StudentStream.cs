using System.Net.Security;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using MMS.Core.LiveView;
using MMS.Core.Security;

namespace MMS.Mobile;

public sealed partial class MobileSession
{
    public bool CanInspect { get { lock(gate) return PowerShellProtocol.IsAllowed(ValidateAccount()); } }

    private async Task<SslStream> Authenticate(TcpClient tcp, Student student, bool inspection, CancellationToken ct)
    {
        bool Permitted() => inspection ? PowerShellProtocol.IsAllowed(ValidateAccount()) : ValidateAccount().Capabilities.HasFlag(SessionCapability.ViewLive);
        if(student.AgentId==Guid.Empty || string.IsNullOrWhiteSpace(student.Serial)) throw new InvalidDataException("Missing enrolled identity");
        lock(gate) if(!Permitted()) throw new UnauthorizedAccessException();
        byte[]? hash=null;
        bool compact=false;
        var tls=new SslStream(tcp.GetStream(),false,(_,cert,_,_)=>{
            if(cert==null) return false;
            hash=SHA256.HashData(cert.GetRawCertData());
            compact=cert.Subject.Split(',').Any(x=>x.Trim()=="OU="+CompactPolicyExchange.CertificateOrganizationalUnit);
            return true; // Identity and endpoint binding are proven below, before sending the account proof.
        });
        try {
        using(var deadline=CancellationTokenSource.CreateLinkedTokenSource(ct))
        {
            deadline.CancelAfter(TimeSpan.FromSeconds(15)); var t=deadline.Token;
            await tls.AuthenticateAsClientAsync(new SslClientAuthenticationOptions{TargetHost=student.Host,EnabledSslProtocols=SslProtocols.None},t);
            if(hash==null) throw new AuthenticationException();
            var nonce=RandomNumberGenerator.GetBytes(32);
            await LiveViewProtocol.WriteBlobAsync(tls,nonce,t);
            byte[] before;
            lock(gate) before=OrganizationPolicy.Encode(policy);
            await CompactPolicyExchange.ClientAsync(tls,compact,before,(data,_)=>{
                lock(gate) policy=OrganizationPolicy.SelectForProvisioning(OrganizationPolicy.Decode(data),policy,root,DateTimeOffset.UtcNow);
                return Task.CompletedTask;
            },t);
            var remoteNonce=await LiveViewProtocol.ReadBlobAsync(tls,t,32);
            var proof=await LiveViewProtocol.ReadBlobAsync(tls,t,DeviceSessionProof.MaximumBytes);
            lock(gate)
            {
                var valid=OrganizationPolicy.Validate(policy,root,DateTimeOffset.UtcNow);
                DeviceSessionProof.Validate(proof,root,valid,DateTimeOffset.UtcNow,student.AgentId,student.Serial,nonce,remoteNonce,hash);
            }
            var challenge=await LiveViewProtocol.ReadBlobAsync(tls,t,LiveViewProtocol.ChallengeBytes);
            if(challenge.Length!=LiveViewProtocol.ChallengeBytes) throw new AuthenticationException();
            byte[] answer;
            lock(gate)
            {
                if(!Permitted()) throw new UnauthorizedAccessException();
                var payload=SupervisorAuthorizationCodec.CreateSessionPayload(challenge,hash,certificate);
                answer=SupervisorAuthorizationCodec.EncodeProof(certificate,signer.SignData(payload,HashAlgorithmName.SHA256,RSASignaturePadding.Pss));
            }
            await LiveViewProtocol.WriteBlobAsync(tls,answer,t);
            var accepted=new byte[1]; await LiveViewProtocol.ReadExactlyAsync(tls,accepted,t);
            if(accepted[0]!=LiveViewProtocol.AuthenticationAccepted) throw new AuthenticationException("Student rejected session or is busy");
        }
        return tls;
        } catch { tls.Dispose(); throw; }
    }

    public async Task CheckPresence(Student student, CancellationToken ct)
    {
        using var tcp=await DeviceConnector.ConnectAsync(student.AgentId,student.Addresses,ThumbnailProtocol.Port,ct);
        using var channel=await Authenticate(tcp,student,false,ct);
    }

    public async Task<string> Inspect(Student student,string preset,CancellationToken ct)
    {
        var command=preset switch {
            "programs" => @"Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue | Where-Object DisplayName | Select-Object DisplayName,DisplayVersion | Sort-Object DisplayName,DisplayVersion -Unique | Format-Table -AutoSize",
            "edge" => @"Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Edge\BLBeacon','HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{56EB18F8-B008-4CBD-B6D2-8C97FE7E9062}' -ErrorAction SilentlyContinue | Select-Object version,pv | Format-List",
            "windows" => "Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,LastBootUpTime | Format-List",
            "service" => "Get-Service MMSStudentAgent | Select-Object Name,Status,StartType | Format-List",
            _ => throw new ArgumentException("Unknown diagnostic")
        };
        if(!CanInspect) throw new UnauthorizedAccessException();
        using var timeout=CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(45));
        using var tcp=await DeviceConnector.ConnectAsync(student.AgentId,student.Addresses,PowerShellProtocol.Port,timeout.Token);
        using var channel=await Authenticate(tcp,student,true,timeout.Token);
        var id=Guid.NewGuid();
        var request=new System.Text.Json.Nodes.JsonObject { ["Version"]=2, ["Id"]=id.ToString(), ["Context"]="SYSTEM", ["TimeoutSeconds"]=20, ["Script"]=command };
        await LiveViewProtocol.WriteBlobAsync(channel,System.Text.Encoding.UTF8.GetBytes(request.ToJsonString()),timeout.Token);
        for(int i=0;i<2;i++)
        {
            var reply=System.Text.Json.Nodes.JsonNode.Parse(await LiveViewProtocol.ReadBlobAsync(channel,timeout.Token,PowerShellProtocol.MaximumWireBytes));
            if(!Guid.TryParse(reply?["Id"]?.ToString(),out var received)||received!=id) throw new InvalidDataException("Unexpected diagnostic result");
            var status=reply!["Status"]?.ToString();
            if(status!="Accepted") return $"{status}\n{reply["Output"]}\n{reply["Error"]}".Trim();
        }
        throw new InvalidDataException("Missing diagnostic result");
    }

    public async IAsyncEnumerable<byte[]> Frames(Student student,bool live,[EnumeratorCancellation] CancellationToken ct)
    {
        using var tcp=await DeviceConnector.ConnectAsync(student.AgentId,student.Addresses,live?LiveViewProtocol.Port:ThumbnailProtocol.Port,ct);
        using var tls=await Authenticate(tcp,student,false,ct);
        while(!ct.IsCancellationRequested)
        {
            byte[] image;
            using(var deadline=CancellationTokenSource.CreateLinkedTokenSource(ct))
            {
                deadline.CancelAfter(TimeSpan.FromSeconds(15));
                if(!live) await LiveViewProtocol.WriteBlobAsync(tls,ThumbnailProtocol.EncodeRequest(new(0,320)),deadline.Token);
                var frame=await LiveViewProtocol.ReadBlobAsync(tls,deadline.Token);
                if(live) image=frame;
                else if(ThumbnailProtocol.TryDecodeResponse(frame,out var response)) image=response.JpegFrame;
                else throw new InvalidDataException("Invalid preview");
            }
            yield return image;
            if(!live) await Task.Delay(3500,ct);
        }
    }
}
