using System.Net.Security;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using MMS.Core.LiveView;
using MMS.Core.Security;

namespace MMS.Mobile;

public sealed partial class MobileSession
{
    public async IAsyncEnumerable<byte[]> Frames(Student student,bool live,[EnumeratorCancellation] CancellationToken ct)
    {
        if(student.AgentId==Guid.Empty || string.IsNullOrWhiteSpace(student.Serial)) throw new InvalidDataException("Missing enrolled identity");
        lock(gate) { if(!ValidateAccount().Capabilities.HasFlag(SessionCapability.ViewLive)) throw new UnauthorizedAccessException(); }
        using var tcp=await DeviceConnector.ConnectAsync(student.AgentId,student.Addresses,live?LiveViewProtocol.Port:ThumbnailProtocol.Port,ct);
        byte[]? hash=null;
        bool compact=false;
        using var tls=new SslStream(tcp.GetStream(),false,(_,cert,_,_)=>{
            if(cert==null) return false;
            hash=SHA256.HashData(cert.GetRawCertData());
            compact=cert.Subject.Split(',').Any(x=>x.Trim()=="OU="+CompactPolicyExchange.CertificateOrganizationalUnit);
            return true; // Identity and endpoint binding are proven below, before sending the account proof.
        });
        using(var deadline=CancellationTokenSource.CreateLinkedTokenSource(ct))
        {
            deadline.CancelAfter(TimeSpan.FromSeconds(15)); var t=deadline.Token;
            await tls.AuthenticateAsClientAsync(new SslClientAuthenticationOptions{TargetHost=student.Host,EnabledSslProtocols=SslProtocols.None},t);
            if(hash==null) throw new AuthenticationException();
            var nonce=RandomNumberGenerator.GetBytes(32);
            await LiveViewProtocol.WriteBlobAsync(tls,nonce,t);
            byte[] before;
            lock(gate) before=OrganizationPolicy.Encode(policy);
            await CompactPolicyExchange.ClientAsync(tls,compact,before,(data,_)=>{
                lock(gate) policy=OrganizationPolicy.SelectForProvisioning(OrganizationPolicy.Decode(data),policy,root,DateTimeOffset.UtcNow);
                return Task.CompletedTask;
            },t);
            var remoteNonce=await LiveViewProtocol.ReadBlobAsync(tls,t,32);
            var proof=await LiveViewProtocol.ReadBlobAsync(tls,t,DeviceSessionProof.MaximumBytes);
            lock(gate)
            {
                var valid=OrganizationPolicy.Validate(policy,root,DateTimeOffset.UtcNow);
                DeviceSessionProof.Validate(proof,root,valid,DateTimeOffset.UtcNow,student.AgentId,student.Serial,nonce,remoteNonce,hash);
            }
            var challenge=await LiveViewProtocol.ReadBlobAsync(tls,t,LiveViewProtocol.ChallengeBytes);
            if(challenge.Length!=LiveViewProtocol.ChallengeBytes) throw new AuthenticationException();
            byte[] answer;
            lock(gate)
            {
                if(!ValidateAccount().Capabilities.HasFlag(SessionCapability.ViewLive)) throw new UnauthorizedAccessException();
                var payload=SupervisorAuthorizationCodec.CreateSessionPayload(challenge,hash,certificate);
                answer=SupervisorAuthorizationCodec.EncodeProof(certificate,signer.SignData(payload,HashAlgorithmName.SHA256,RSASignaturePadding.Pss));
            }
            await LiveViewProtocol.WriteBlobAsync(tls,answer,t);
            var accepted=new byte[1]; await LiveViewProtocol.ReadExactlyAsync(tls,accepted,t);
            if(accepted[0]!=LiveViewProtocol.AuthenticationAccepted) throw new AuthenticationException("Student rejected session or is busy");
        }
        while(!ct.IsCancellationRequested)
        {
            byte[] image;
            using(var deadline=CancellationTokenSource.CreateLinkedTokenSource(ct))
            {
                deadline.CancelAfter(TimeSpan.FromSeconds(15));
                if(!live) await LiveViewProtocol.WriteBlobAsync(tls,ThumbnailProtocol.EncodeRequest(new(0,320)),deadline.Token);
                var frame=await LiveViewProtocol.ReadBlobAsync(tls,deadline.Token);
                if(live) image=frame;
                else if(ThumbnailProtocol.TryDecodeResponse(frame,out var response)) image=response.JpegFrame;
                else throw new InvalidDataException("Invalid preview");
            }
            yield return image;
            if(!live) await Task.Delay(3500,ct);
        }
    }
}
