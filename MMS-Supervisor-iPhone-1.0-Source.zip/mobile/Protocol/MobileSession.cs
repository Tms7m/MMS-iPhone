using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;
using MMS.Core.Security;

namespace MMS.Mobile;

public sealed class LoginDiagnosticException : Exception
{
    public LoginDiagnosticException(string stage, Exception cause) : base($"{stage} · {Reason(cause)}") { }

    private static string Reason(Exception cause) => cause switch
    {
        HttpRequestException { StatusCode: {} status } => $"HTTP {(int)status}",
        HttpRequestException => "NETWORK",
        OperationCanceledException or TimeoutException => "TIMEOUT",
        AuthenticationTagMismatchException => "AUTH-TAG",
        PlatformNotSupportedException => "PLATFORM",
        CryptographicException => "CRYPTO",
        UnauthorizedAccessException => "DENIED",
        System.Text.Json.JsonException => "JSON",
        FormatException => "FORMAT",
        InvalidDataException => "INVALID-DATA",
        _ => cause.GetType().Name
    };
}

public sealed record Student(Guid AgentId, string Name, string Host, string Serial, string[] Addresses) { public string GroupId { get; init; } = ""; public string Group { get; init; } = ""; }

public sealed partial class MobileSession : IDisposable
{
    private static readonly HttpClient Api = new(new HttpClientHandler { AllowAutoRedirect = false })
    {
        BaseAddress = new Uri("https://sync.hikaaya.com/"), Timeout = TimeSpan.FromSeconds(30),
        MaxResponseContentBufferSize = 32 * 1024 * 1024
    };
    private readonly HttpClient http;
    private readonly RSA root = RSA.Create(), signer = RSA.Create();
    private readonly object gate = new();
    private SecurityPolicyBundle policy;
    private readonly byte[] certificate;
    private readonly string token, reader, readerPassword, secret;
    private readonly Guid organization;
    private readonly string sessionId=Guid.NewGuid().ToString("N");
    private readonly Dictionary<string,string> displayNames=new(StringComparer.OrdinalIgnoreCase);
    private readonly Guid subjectId;
    public bool Developer { get; }
    public string User { get; }
    public string DisplayName { get; }
    public Dictionary<string,string> Groups { get; private set; } = new();
    private static string Text(JsonNode? obj, string field) => obj?[field]?.GetValue<string>() ?? throw new InvalidDataException(field);
    private static byte[] Bytes(JsonNode obj, string field) => Convert.FromBase64String(Text(obj, field));

    private static async Task<(HttpStatusCode Code, JsonNode Body, DateTimeOffset Now)> Request(
        HttpClient http, string path, JsonObject? body, string? auth, CancellationToken ct)
    {
        using var req = new HttpRequestMessage(body == null ? HttpMethod.Get : HttpMethod.Post, path);
        if (body != null) req.Content = JsonContent.Create(body, MobileJsonContext.Default.JsonObject);
        if (auth != null) req.Headers.Authorization = new AuthenticationHeaderValue(auth);
        using var reply = await http.SendAsync(req, ct);
        var result = JsonNode.Parse(await reply.Content.ReadAsByteArrayAsync(ct)) ?? throw new InvalidDataException();
        return (reply.StatusCode, result, reply.Headers.Date ?? DateTimeOffset.UtcNow);
    }

    private static async Task<JsonNode> Success(HttpClient http,string path, JsonObject? body, string? auth, CancellationToken ct)
    {
        var r = await Request(http,path, body, auth, ct);
        if ((int)r.Code / 100 != 2) throw new HttpRequestException($"MMS HTTP {(int)r.Code}", null, r.Code);
        return r.Body;
    }
    private static async Task<string> Authenticate(HttpClient http,string collection, string id, string pass, CancellationToken ct) =>
        Text(await Success(http,$"api/collections/{collection}/auth-with-password",new() { ["identity"]=id, ["password"]=pass },null,ct),"token");

    private static byte[] Open(JsonNode envelope, byte[] key, byte[] context)
    {
        if (envelope["Version"]?.GetValue<int>() != 1) throw new InvalidDataException("Unsupported envelope version");
        return Decrypt(Bytes(envelope,"Nonce"), Bytes(envelope,"Ciphertext"), Bytes(envelope,"Tag"), key, context);
    }
    private static byte[] Decrypt(ReadOnlySpan<byte> nonce,ReadOnlySpan<byte> cipher,ReadOnlySpan<byte> tag,byte[] key,byte[] aad)
    {
        byte[] plain = new byte[cipher.Length];
        using var aes = new AesGcm(key,16);
        aes.Decrypt(nonce,cipher,tag,plain,aad);
        return plain;
    }
    private static byte[] Derive(string pass, byte[] salt) =>
        Rfc2898DeriveBytes.Pbkdf2(pass,salt,310000,HashAlgorithmName.SHA256,32);

    public static Task<MobileSession> Login(string org,string user,string password,
        Func<CancellationToken,Task<string>> getCode,CancellationToken ct) => Login(Api,org,user,password,getCode,ct);

    internal static async Task<MobileSession> Login(HttpClient http,string org,string user,string password,
        Func<CancellationToken,Task<string>> getCode,CancellationToken ct)
    {
        user=user.Trim().ToLowerInvariant(); org=org.Trim().ToLowerInvariant();
        var login=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(org+"\n"+user))).ToLowerInvariant();
        var challenge=await Success(http,"api/mms/setup/challenge",new(){["loginId"]=login},null,ct);
        var verifier=Derive(password,Bytes(challenge,"salt"));
        var key=HMACSHA256.HashData(verifier,Encoding.UTF8.GetBytes("MMS-ONLINE-ENVELOPE-1|"+login));
        try
        {
            var proof=HMACSHA256.HashData(verifier,Encoding.UTF8.GetBytes("MMS-ONLINE-LOGIN-1|"+login));
            var token=await Authenticate(http,"mms_setup_accounts",login,Convert.ToBase64String(proof),ct);
            return await CompleteLogin(http,org,user,password,getCode,ct,login,key,token);
        }
        finally { CryptographicOperations.ZeroMemory(verifier); CryptographicOperations.ZeroMemory(key); }
    }

    private static async Task<MobileSession> CompleteLogin(HttpClient http,string org,string user,string password,
        Func<CancellationToken,Task<string>> getCode,CancellationToken ct,string login,byte[] key,string token)
    {
        var stage="MMS-L01 · Downloading account settings";
        try
        {
            var download=await Request(http,"api/mms/setup/download",null,token,ct);
            var body=download.Body;
            if ((int)download.Code / 100 != 2)
            {
                if (body["otpRequired"]?.GetValue<bool>() != true) throw new HttpRequestException("Account setup unavailable",null,download.Code);
                stage="MMS-L02 · Requesting email code";
                var start=await Success(http,"api/mms/setup/email/start",new(),token,ct);
                var challengeId=Text(start,"challenge");
                stage="MMS-L03 · Entering email code";
                var code=await getCode(ct);
                stage="MMS-L04 · Checking email code";
                body=await Success(http,"api/mms/setup/email/download",new(){["challenge"]=challengeId,["code"]=code},token,ct);
            }
            stage="MMS-L05 · Reading setup package";
            var envelope=JsonNode.Parse(Text(body,"payload")) ?? throw new InvalidDataException();
            stage="MMS-L06 · Opening encrypted setup";
            var plain=Open(envelope,key,Encoding.UTF8.GetBytes(login));
            try
            {
                stage="MMS-L07 · Reading organization settings";
                var setup=JsonNode.Parse(plain) ?? throw new InvalidDataException();
                stage="MMS-L08 · Initializing session keys";
                return new MobileSession(http,setup,org,user,password,token,ref stage);
            }
            finally { CryptographicOperations.ZeroMemory(plain); }
        }
        catch (Exception ex) when (!ct.IsCancellationRequested)
        {
            throw new LoginDiagnosticException(stage,ex);
        }
    }

    private MobileSession(HttpClient http,JsonNode setup,string source,string user,string password,string auth,ref string stage)
    {
        try
        {
            this.http=http; token=auth;
            stage="MMS-L09 · Checking organization and account";
            var e=setup["Enrollment"]!; var a=setup["Account"]!;
            if (Text(setup,"SourceName")!=source || !Text(a,"UserName").Equals(user,StringComparison.OrdinalIgnoreCase)
                || a["IsSuspended"]?.GetValue<bool>()==true || new Uri(Text(e,"PocketBaseUrl").TrimEnd('/')+"/")!=Api.BaseAddress)
                throw new UnauthorizedAccessException();
            stage="MMS-L10 · Importing organization key";
            root.ImportFromPem(Encoding.ASCII.GetString(Bytes(e,"SecurityRootPublic")));
            stage="MMS-L11 · Reading security policy";
            policy=OrganizationPolicy.Decode(Bytes(e,"SecurityPolicies"));
            stage="MMS-L12 · Reading supervisor certificate";
            certificate=Bytes(a,"AuthorizationCertificate");
            stage="MMS-L13 · Validating signed policy";
            var validated=OrganizationPolicy.Validate(policy,root,DateTimeOffset.UtcNow);
            stage="MMS-L14 · Validating certificate chain";
            var subject=TrustChainValidator.Validate(certificate,root,DateTimeOffset.UtcNow,validated.RevokedAuthorities,validated.RevokedIdentities).Subject;
            stage="MMS-L15 · Checking supervisor identity and role";
            Guid id=Guid.Parse(Text(a,"Id")); subjectId=id;
            if (subject.AccountId!=id || !subject.UserName.Equals(user,StringComparison.OrdinalIgnoreCase) ||
                subject.Role!=a["Role"]!.GetValue<byte>()) throw new UnauthorizedAccessException();
            Developer=subject.Role==2; User=subject.UserName; DisplayName=a["DisplayName"]?.ToString() ?? User;
            stage="MMS-L16 · Deriving account key";
            var key=Derive(password,Bytes(a,"AuthorizationKeySalt"));
            try
            {
                stage="MMS-L17 · Decrypting private key";
                var plain=Decrypt(Bytes(a,"AuthorizationKeyNonce"),Bytes(a,"EncryptedAuthorizationPrivateKey"),Bytes(a,"AuthorizationKeyTag"),key,id.ToByteArray());
                stage="MMS-L18 · Importing private key";
                try { signer.ImportPkcs8PrivateKey(plain,out _); }
                finally { CryptographicOperations.ZeroMemory(plain); }
            }
            finally { CryptographicOperations.ZeroMemory(key); }
            stage="MMS-L19 · Matching key and certificate";
            if (!subject.SubjectPublicKey.AsSpan().SequenceEqual(signer.ExportSubjectPublicKeyInfo())) throw new UnauthorizedAccessException();
            stage="MMS-L20 · Reading sync settings";
            organization=Guid.Parse(Text(e,"InternetOrganizationId")); secret=Text(e,"SyncSecret");
            reader=Text(e,"PocketBaseReaderIdentity"); readerPassword=Text(e,"PocketBaseReaderPassword");
        }
        catch { root.Dispose(); signer.Dispose(); throw; }
    }

    private SupervisorAuthorization ValidateAccount()
    {
        var p=OrganizationPolicy.Validate(policy,root,DateTimeOffset.UtcNow);
        return TrustChainValidator.Validate(certificate,root,DateTimeOffset.UtcNow,p.RevokedAuthorities,p.RevokedIdentities).Subject;
    }
    public void Dispose() { lock(gate) { signer.Dispose(); root.Dispose(); } }

    public async Task ReportPresence(string computer,bool closed,CancellationToken ct)
    {
        await Success(http,"api/mms/audit/presence",new(){["organizationId"]=organization.ToString("D"),
            ["subjectId"]=subjectId.ToString("N"),["userName"]=User.ToLowerInvariant(),["computer"]=computer,
            ["sessionId"]=sessionId,["closed"]=closed},token,ct);
    }

    public async Task ReportEvent(string computer,bool closed,Guid eventId,DateTimeOffset occurred,CancellationToken ct)
    {
        await Success(http,"api/mms/audit/session",new(){["organizationId"]=organization.ToString("D"),
            ["subjectId"]=subjectId.ToString("N"),["userName"]=User.ToLowerInvariant(),["computer"]=computer,
            ["eventId"]=eventId.ToString("N"),["occurred"]=occurred.UtcDateTime.ToString("O"),["action"]=closed?"SIGN_OUT":"SIGN_IN"},token,ct);
    }

    public async Task<List<Student>> Devices(CancellationToken ct)
    {
        var auth=await Authenticate(http,"mms_sync_clients",reader,readerPassword,ct);
        var filter=Uri.EscapeDataString($"organizationId='{organization:D}'");
        var result=new Dictionary<Guid,Student>();
        var groups=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
        void Add(JsonNode row, string? registrationGroup=null)
        {
            var host=Text(row,"Hostname");
            var item=new Student(Guid.Parse(Text(row,"AgentId")),row["UserName"]?.ToString()??"",host,row["SerialNumber"]?.ToString()??"",
                row["IpAddresses"]!.AsArray().Select(x=>x!.GetValue<string>()).Take(32).Append(host).ToArray());
            var id = Guid.TryParse(row["GroupId"]?.ToString(),out var group) && group != Guid.Empty ? group.ToString("D") : "";
            if(id.Length>0 && !string.IsNullOrWhiteSpace(registrationGroup)) groups.TryAdd(id,registrationGroup);
            result.TryAdd(item.AgentId,item with { GroupId=id, Group=groups.GetValueOrDefault(id,"") });
        }
        var snapshot=await Success(http,$"api/collections/mms_sync_snapshots/records?perPage=1&sort=-publishedUtc&filter={filter}",null,auth,ct);
        if(snapshot["items"]!.AsArray().FirstOrDefault() is {} latest)
        {
            var blob=Bytes(latest,"payload");
            if (!Convert.ToHexString(SHA256.HashData(blob)).Equals(Text(latest,"payloadHash"),StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Snapshot integrity");
            var envelope=JsonNode.Parse(blob)!;
            var key=Derive(secret,Bytes(envelope,"Salt"));
            try
            {
                var decoded=Open(envelope,key,"MMS-SYNC-1"u8.ToArray());
                try
                {
                    var payload=JsonNode.Parse(decoded)!;
                    if(payload["Catalog"]?["Groups"] is JsonArray savedGroups)
                        foreach(var g in savedGroups)
                            if(Guid.TryParse(g?["Id"]?.ToString(),out var gid) && g?["Name"]?.ToString() is {Length:>0} name)
                                groups[gid.ToString("D")]=name;
                    foreach(var d in payload["Catalog"]!["Devices"]!.AsArray()) Add(d!);
                    if(payload["Accounts"] is JsonArray accounts)
                        lock(gate) foreach(var item in accounts)
                            if(item?["DisplayName"]?.ToString() is { Length: >0 } name) displayNames[Text(item,"UserName")]=name;
                }
                finally { CryptographicOperations.ZeroMemory(decoded); }
            }
            finally { CryptographicOperations.ZeroMemory(key); }
        }
        byte[] Context(string id)=>Encoding.ASCII.GetBytes($"MMS.Catalog.v1/{organization:D}/{id}");
        var registryKey=HMACSHA256.HashData(Encoding.UTF8.GetBytes(secret),Context("registry"));
        try
        {
            for(int page=1;page<=101;page++)
            {
                var data=await Success(http,$"api/collections/mms_registered_devices/records?page={page}&perPage=100&sort=id&filter={filter}",null,auth,ct);
                foreach(var r in data["items"]!.AsArray())
                {
                    var blob=Bytes(r!,"payload");
                    if(blob.Length is <=28 or >12288) throw new InvalidDataException("Invalid catalog entry");
                    var decoded=Decrypt(blob.AsSpan(0,12),blob.AsSpan(28),blob.AsSpan(12,16),registryKey,Context(Text(r,"deviceKey")));
                    var entry=JsonNode.Parse(decoded)!; Add(entry["Device"]!,entry["GroupName"]?.ToString());
                }
                if(page>=data["totalPages"]!.GetValue<int>()) break;
            }
        }
        finally { CryptographicOperations.ZeroMemory(registryKey); }
        await ApplyGroupMoves(auth,filter,result,groups,ct);
        Groups=groups;
        return result.Values.OrderBy(x=>x.Host).ToList();
    }

    public async Task<JsonObject> Audit(CancellationToken ct)
    {
        lock(gate) { if (ValidateAccount().Role!=2) throw new UnauthorizedAccessException(); }
        var presence=new Dictionary<(string User,string Computer),(bool Online,DateTimeOffset Seen)>();
        for(int page=1;;page++)
        {
            var r=await Request(http,$"api/collections/mms_session_presence/records?perPage=200&page={page}&sort=id",null,token,ct);
            if(r.Code!=HttpStatusCode.OK) throw new HttpRequestException($"HTTP {(int)r.Code}");
            foreach(var row in r.Body["items"]!.AsArray())
            {
                var k=(Text(row,"userName"),Text(row,"computer"));
                var seen=DateTimeOffset.Parse(Text(row,"seen"),System.Globalization.CultureInfo.InvariantCulture,System.Globalization.DateTimeStyles.AssumeUniversal);
                var online=!row!["closed"]!.GetValue<bool>() && r.Now-seen<TimeSpan.FromSeconds(100);
                var old=presence.GetValueOrDefault(k);
                presence[k]=(online||old.Online,seen>old.Seen?seen:old.Seen);
            }
            if(page>=r.Body["totalPages"]!.GetValue<int>()) break;
        }
        string Display(string username)
        {
            lock(gate) return displayNames.TryGetValue(username,out var name) ? $"{name} [{username}]" : username;
        }
        var statuses=new JsonArray();
        foreach(var p in presence.OrderByDescending(x=>x.Value.Seen))
            statuses.Add(new JsonObject{["user"]=Display(p.Key.User),["computer"]=p.Key.Computer,["online"]=p.Value.Online,["seen"]=p.Value.Seen.ToString("O")});
        var events=await Success(http,"api/collections/mms_session_audit/records?perPage=200&sort=-occurred,-id",null,token,ct);
        foreach(var row in events["items"]!.AsArray()) row!["user"]=Display(Text(row,"userName"));
        return new(){["presence"]=statuses,["events"]=events["items"]!.DeepClone()};
    }
}
