using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using MMS.Core.Security;

namespace MMS.Mobile;

public sealed record CatalogMove(Guid Operation, Guid Organization, Guid Device, Guid Group, string Name);

public sealed partial class MobileSession
{
    private async Task ApplyGroupMoves(string auth,string filter,Dictionary<Guid,Student> devices,Dictionary<string,string> groups,CancellationToken ct)
    {
        for(int page=1;page<=100;page++)
        {
            JsonNode data;
            try { data=await Success(http,$"api/collections/mms_group_moves/records?perPage=500&page={page}&sort=created,id&filter={filter}",null,auth,ct); }
            catch(HttpRequestException ex) when(ex.StatusCode is System.Net.HttpStatusCode.NotFound or System.Net.HttpStatusCode.Forbidden) { return; }
            var items=data["items"]!.AsArray();
            foreach(var row in items)
            {
                try
                {
                    var entry=JsonNode.Parse(Text(row,"payload"))!;
                    var move=entry["Move"]?.Deserialize(MobileJsonContext.Default.CatalogMove);
                    if(move==null || move.Organization!=organization || move.Operation==Guid.Empty || move.Operation.ToString("N")!=Text(row,"operation") ||
                        move.Group==Guid.Empty || string.IsNullOrWhiteSpace(move.Name) || move.Name.Length>80 || !devices.TryGetValue(move.Device,out var student)) continue;
                    var proof=Bytes(entry,"Proof");
                    if(proof.Length>16384 || !SupervisorAuthorizationCodec.TryDecodeProof(proof,out var chain,out var signature) ||
                        TrustChainValidator.Hash(chain)!=Text(row,"authorizationHash")) continue;
                    lock(gate)
                    {
                        var now=DateTimeOffset.UtcNow;
                        var checkedPolicy=OrganizationPolicy.Validate(policy,root,now);
                        var actor=TrustChainValidator.Validate(chain,root,now,checkedPolicy.RevokedAuthorities,checkedPolicy.RevokedIdentities).Subject;
                        if(actor.Role!=2 && (actor.Role!=0 || (actor.ApplicationPermissions & (1L<<7))==0)) continue;
                        using var key=RSA.Create(); key.ImportSubjectPublicKeyInfo(actor.SubjectPublicKey,out _);
                        var signed=Encoding.UTF8.GetBytes("MMS.GroupMove.v1\n"+JsonSerializer.Serialize(move,MobileJsonContext.Default.CatalogMove));
                        if(!key.VerifyData(signed,signature,HashAlgorithmName.SHA256,RSASignaturePadding.Pss)) continue;
                    }
                    string id=move.Group.ToString("D"); groups.TryAdd(id,move.Name); devices[move.Device]=student with {GroupId=id,Group=groups[id]};
                }
                catch(Exception ex) when(ex is InvalidDataException or CryptographicException or JsonException or FormatException or InvalidOperationException or UnauthorizedAccessException) { }
            }
            if(items.Count<500) return;
        }
    }
}
