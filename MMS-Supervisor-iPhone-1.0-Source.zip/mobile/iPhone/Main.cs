using System.Runtime.InteropServices;
using Foundation;
using UIKit;
using WebKit;
using System.Text.Json;
using System.Text.Json.Nodes;
using MMS.Mobile;
using MMS.Core.Security;
using MMS.Core.LiveView;

namespace MMS.Phone;

public static class Program
{
    public static void Main(string[] args)
    {
        if (StartupProbe.Enabled) Console.Error.WriteLine("MMS startup: managed-main 1.0.16");
        RequireUIKitClass(typeof(AppDelegate), "MMSApplicationDelegate");
        RequireUIKitClass(typeof(SceneDelegate), "MMSSceneDelegate");
        RequireUIKitClass(typeof(Dashboard), "MMSDashboard");
        EnsureSceneProtocols();
        UIApplication.Main(args, null, typeof(AppDelegate));
    }

    // UIKit checks the Objective-C class itself when it reads the scene manifest.
    private static void EnsureSceneProtocols()
    {
        var sceneClass = ObjCRuntime.Class.GetHandle(typeof(SceneDelegate));
        foreach (var name in new[] { "UISceneDelegate", "UIWindowSceneDelegate" })
        {
            var protocol = ObjCRuntime.Protocol.GetHandle(name);
            if (protocol == IntPtr.Zero)
                throw new InvalidOperationException($"UIKit protocol unavailable: {name}");
            if (!ClassConformsToProtocol(sceneClass, protocol))
                ClassAddProtocol(sceneClass, protocol);
            if (!ClassConformsToProtocol(sceneClass, protocol))
                throw new InvalidOperationException($"MMSSceneDelegate does not conform to {name}.");
            if (StartupProbe.Enabled) Console.Error.WriteLine($"MMS startup: scene conforms to {name}");
        }
    }

    [DllImport("/usr/lib/libobjc.A.dylib", EntryPoint = "class_conformsToProtocol")]
    [return: MarshalAs(UnmanagedType.I1)]
    private static extern bool ClassConformsToProtocol(IntPtr cls, IntPtr protocol);

    [DllImport("/usr/lib/libobjc.A.dylib", EntryPoint = "class_addProtocol")]
    [return: MarshalAs(UnmanagedType.I1)]
    private static extern bool ClassAddProtocol(IntPtr cls, IntPtr protocol);

    private static void RequireUIKitClass(Type type, string nativeName)
    {
        var managed = ObjCRuntime.Class.GetHandle(type);
        var native = ObjCRuntime.Class.GetHandle(nativeName);
        if (native == IntPtr.Zero || managed != native)
            throw new InvalidOperationException($"UIKit class registration failed for {nativeName}.");
        if (StartupProbe.Enabled) Console.Error.WriteLine($"MMS startup: registered {nativeName}");
    }
}

internal static class StartupProbe
{
    public static bool Enabled =>
#if MMS_SIMULATOR_PROBE
        true;
#else
        false;
#endif
    public static void Stage(string stage)
    {
        if (!Enabled) return;
        Console.Error.WriteLine("MMS startup: " + stage);
        var documents = NSFileManager.DefaultManager.GetUrls(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomain.User)[0].Path!;
        Directory.CreateDirectory(documents);
        File.AppendAllText(Path.Combine(documents, "mms-startup-trace"), stage + "\n");
        if (stage == "ready") File.WriteAllText(Path.Combine(documents, "mms-login-ready"), "1");
    }
}

[Register("MMSApplicationDelegate")]
public sealed class AppDelegate : UIApplicationDelegate
{
    public AppDelegate() { }
    public AppDelegate(ObjCRuntime.NativeHandle handle) : base(handle) { }

    public override bool FinishedLaunching(UIApplication application, NSDictionary? options)
    {
        StartupProbe.Stage("application-launched");
        return true;
    }
}

[Preserve(AllMembers=true)]
[Register("MMSSceneDelegate")]
public sealed class SceneDelegate : UIResponder, IUIWindowSceneDelegate
{
    public SceneDelegate() { }
    public SceneDelegate(ObjCRuntime.NativeHandle handle) : base(handle) { }

    [Export("window")]
    public UIWindow? Window { get; set; }

    [Export("scene:willConnectToSession:options:")]
    public void WillConnect(UIScene scene, UISceneSession session, UISceneConnectionOptions options)
    {
        StartupProbe.Stage(Window?.RootViewController is Dashboard ? "scene-with-dashboard" : "scene-connected");
    }

    [Export("sceneDidBecomeActive:")]
    public void DidBecomeActive(UIScene scene)
    {
        if (Window?.RootViewController is Dashboard dashboard) dashboard.OnForeground();
    }

    [Export("sceneDidEnterBackground:")]
    public void DidEnterBackground(UIScene scene)
    {
        if (Window?.RootViewController is Dashboard dashboard) dashboard.OnBackground();
    }
}

public sealed class LocalNavigation : WKNavigationDelegate
{
    public override void DecidePolicy(WKWebView webView, WKNavigationAction action, Action<WKNavigationActionPolicy> handler)
    {
        handler(action.TargetFrame?.MainFrame == true && action.Request.Url?.AbsoluteString == "about:blank"
            ? WKNavigationActionPolicy.Allow : WKNavigationActionPolicy.Cancel);
    }
    public override void DidFinishNavigation(WKWebView webView, WKNavigation navigation) => StartupProbe.Stage("document-loaded");
    public override void DidFailProvisionalNavigation(WKWebView webView, WKNavigation navigation, NSError error) =>
        StartupProbe.Stage("document-load-error-" + error.Code);

}

[Register("MMSDashboard")]
[Preserve(AllMembers=true)]
public sealed class Dashboard : UIViewController, IWKScriptMessageHandler
{
    public Dashboard(ObjCRuntime.NativeHandle handle) : base(handle) { }

    private WKWebView web=null!;
    private readonly LocalNavigation navigation=new();
    private CancellationTokenSource lifetime=new(), streams=new();
    private JsonObject history=new();
    private static string HistoryKey(MobileSession owner)=>"mms.attendance."+owner.OrganizationId.ToString("N");
    private void ReadHistory(MobileSession owner)
    {
        try { history=JsonNode.Parse(NSUserDefaults.StandardUserDefaults.StringForKey(HistoryKey(owner))??"{}") as JsonObject ?? new(); }
        catch(JsonException) { history=new(); }
    }
    private Task SyncDays(MobileSession owner,CancellationToken ct)
    {
        var entries=catalog.Values.SelectMany(d=>(history[d.AgentId.ToString()] as JsonArray ?? new JsonArray())
            .Select(n=>(d,n!.GetValue<string>()))).ToArray();
        return owner.SyncDays(entries,ct);
    }
    private void Observe(MobileSession owner,Guid id)
    {
        if(!ReferenceEquals(owner,session))return;
        string key=id.ToString(), day=DateTimeOffset.UtcNow.ToOffset(TimeSpan.FromHours(4)).ToString("yyyy-MM-dd",System.Globalization.CultureInfo.InvariantCulture);
        var days=history[key] as JsonArray;
        if(days==null) history[key]=days=new JsonArray();
        if(days.Count>0 && days[days.Count-1]?.ToString()==day)return;
        if(!days.Any(x=>x?.ToString()==day)) days.Add((JsonNode?)JsonValue.Create(day));
        NSUserDefaults.StandardUserDefaults.SetString(history.ToJsonString(),HistoryKey(owner));
    }
    private readonly HashSet<Guid> recentlyOnline=new();
    private readonly Dictionary<Guid,Student> catalog=new();
    private readonly HashSet<Guid> active=new();
    private MobileSession? session;
    private TaskCompletionSource<string>? pendingOtp;
    private bool signingIn, loading;
    private CancellationTokenSource? scan;
    private string phone="";
    private string recoveryChallenge="";
    private string PhoneName()
    {
        var defaults=NSUserDefaults.StandardUserDefaults;
        var saved=defaults.StringForKey("MMSDeviceLabel");
        if(!string.IsNullOrEmpty(saved)) return saved;
        var label="iPhone-"+Guid.NewGuid().ToString("N")[..8];
        defaults.SetString(label,"MMSDeviceLabel");
        return label;
    }

    private async Task Pulse(MobileSession current,CancellationToken ct,bool announced)
    {
        var id=Guid.NewGuid(); var started=DateTimeOffset.UtcNow;
        while(!ct.IsCancellationRequested)
        {
            try
            {
                if(!announced)
                {
                    await current.ReportEvent(phone,false,id,started,ct); announced=true;
                }
                await current.ReportPresence(phone,false,ct);
            }
            catch(OperationCanceledException) when(ct.IsCancellationRequested) { return; }
            catch(HttpRequestException) { /* Retry when the connection returns. */ }
            catch(System.Text.Json.JsonException) { }
            try { await Task.Delay(30000,ct); }
            catch(OperationCanceledException) { return; }
        }
    }

    private async Task CloseSession(MobileSession current,bool signOut)
    {
        using var deadline=new CancellationTokenSource(TimeSpan.FromSeconds(5));
        try
        {
            await Task.WhenAll(current.ReportPresence(phone,true,deadline.Token),
                signOut ? current.ReportEvent(phone,true,Guid.NewGuid(),DateTimeOffset.UtcNow,deadline.Token) : Task.CompletedTask);
        }
        catch(HttpRequestException) { }
        catch(OperationCanceledException) { }
        catch(System.Text.Json.JsonException) { }
    }
    public override void ViewDidLoad()
    {
        base.ViewDidLoad();
        StartupProbe.Stage("view-loaded");
        var config=new WKWebViewConfiguration { WebsiteDataStore=WKWebsiteDataStore.NonPersistentDataStore };
        config.UserContentController.AddScriptMessageHandler(this,"mms");
        web=new WKWebView(CoreGraphics.CGRect.Empty,config){NavigationDelegate=navigation, TranslatesAutoresizingMaskIntoConstraints=false};
        if(web.ScrollView.PinchGestureRecognizer is {} pinch) pinch.Enabled=false;
        View!.BackgroundColor=UIColor.SystemBackground;
        View.AddSubview(web);
        var guide=View.SafeAreaLayoutGuide;
        NSLayoutConstraint.ActivateConstraints([web.TopAnchor.ConstraintEqualTo(guide.TopAnchor),web.BottomAnchor.ConstraintEqualTo(guide.BottomAnchor),
            web.LeadingAnchor.ConstraintEqualTo(guide.LeadingAnchor),web.TrailingAnchor.ConstraintEqualTo(guide.TrailingAnchor)]);
        startup.TextAlignment=UITextAlignment.Center;
        startup.Lines=0;
        startup.TextColor=UIColor.Label;
        startup.BackgroundColor=UIColor.SystemBackground;
        startup.TranslatesAutoresizingMaskIntoConstraints=false;
        View.AddSubview(startup);
        NSLayoutConstraint.ActivateConstraints([startup.TopAnchor.ConstraintEqualTo(guide.TopAnchor),startup.BottomAnchor.ConstraintEqualTo(guide.BottomAnchor),
            startup.LeadingAnchor.ConstraintEqualTo(guide.LeadingAnchor),startup.TrailingAnchor.ConstraintEqualTo(guide.TrailingAnchor)]);
        startup.Text="MMS Supervisor · 1.0.16\nOpening sign-in…";
        var assets = Path.Combine(NSBundle.MainBundle.BundlePath, "Web");
        try
        {
            var nonce = Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(24));
            var html = File.ReadAllText(Path.Combine(assets, "index.html"))
                .Replace("{{NONCE}}", nonce)
                .Replace("{{STYLE}}", File.ReadAllText(Path.Combine(assets, "style.css")))
                .Replace("{{LOGO}}", Convert.ToBase64String(File.ReadAllBytes(Path.Combine(assets, "MMS.png"))))
                .Replace("{{SCRIPT}}", File.ReadAllText(Path.Combine(assets, "app.js")));
            StartupProbe.Stage("document-submitted");
            web.LoadHtmlString(html, new NSUrl("about:blank"));
        }
        catch (IOException)
        {
            StartupProbe.Stage("missing-interface-resource");
            startup.Text = "MMS · Could not load the sign-in interface";
            return;
        }
        _=CheckStartupAsync();
    }

    private readonly UILabel startup=new();
    private async Task CheckStartupAsync()
    {
        await Task.Delay(TimeSpan.FromSeconds(15));
        if(!startup.Hidden) startup.Text="MMS 1.0.16 · Could not open sign-in (WEB-START)";
    }

    private Task Emit(string name,JsonNode? value=null) =>
        web.EvaluateJavaScriptAsync("window.receive("+System.Text.Json.JsonSerializer.Serialize(name, MobileJsonContext.Default.String)+","+(value is null ? "null" : System.Text.Json.JsonSerializer.Serialize(value, MobileJsonContext.Default.JsonNode))+")");

    private Stream? controlLease;
    private Guid controlled;
    private CancellationTokenSource? audioStop;

    private async Task Listen(Student student, MobileSession owner, CancellationToken ct)
    {
        using var source=CancellationTokenSource.CreateLinkedTokenSource(ct);
        audioStop=source;
        try {
            using var channel=await owner.OpenFeature(student,SessionCapability.ListenMicrophone,source.Token);
            while(!source.IsCancellationRequested) {
                var data=await LiveViewProtocol.ReadBlobAsync(channel,source.Token,AudioMonitorProtocol.MaximumAudioChunkBytes);
                await Emit("audio",new JsonObject { ["id"]=student.AgentId.ToString(), ["data"]=Convert.ToBase64String(data) });
            }
        } catch(OperationCanceledException) when(source.IsCancellationRequested) { }
        finally { if(ReferenceEquals(audioStop,source)) audioStop=null; }
    }
    private void StopStreams()
    {
        audioStop?.Cancel(); controlLease?.Dispose(); controlLease=null; controlled=Guid.Empty;
        streams.Cancel(); streams.Dispose();
        streams=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token);
        active.Clear();
    }
    private bool resumeWhenActive;
    public void OnBackground()
    {
        if (session != null) { resumeWhenActive=true; Lock(false); }
    }
    public void OnForeground()
    {
        if(resumeWhenActive) { resumeWhenActive=false; _=Emit("resume"); }
    }
    public void Lock(bool signOut=true)
    {
        lifetime.Cancel(); lifetime.Dispose(); lifetime=new();
        StopStreams(); pendingOtp?.TrySetCanceled(); pendingOtp=null;
        if(session is {} current) { _=CloseSession(current,signOut); current.Dispose(); } session=null; recentlyOnline.Clear(); catalog.Clear(); signingIn=false; loading=false;
        if(web!=null) _=Emit("locked");
    }

    [Export("userContentController:didReceiveScriptMessage:")]
    public async void DidReceiveScriptMessage(WKUserContentController controller,WKScriptMessage msg)
    {
        if(!msg.FrameInfo.MainFrame || msg.Body is not NSString raw || raw.Length>48*1024*1024) return;
        var ct=lifetime.Token;
        try
        {
            var args=JsonNode.Parse(raw.ToString())!;
            string Field(string key)=>args[key]?.GetValue<string>()??"";
            switch(Field("op"))
            {
                case "ready":
                    startup.Hidden=true;
                    StartupProbe.Stage("ready");
                    break;
                case "resume" when session==null && !signingIn:
                case "login" when session==null && !signingIn:
                    signingIn=true;
                    try
                    {
                        var restore=Field("op")=="resume";
                        var credentials=restore ? RememberedLogin.Read() : args;
                        if(credentials==null) break;
                        string Input(string key)=>credentials[key]?.ToString() ?? "";
                        if(restore) await Emit("restoring");
                        var savedEnvelope=restore ? credentials["envelope"]?.ToString() : null;
                        var logged=await MobileSession.Login(Input("source"),Input("user"),Input("password"),async token=>{
                            var prompt=new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
                            pendingOtp=prompt;
                            await Emit("otp");
                            return await prompt.Task.WaitAsync(token);
                        },ct,savedEnvelope);
                        if(ct.IsCancellationRequested) { logged.Dispose(); return; }
                        var stage="MMS-L21 · Initializing iPhone session";
                        try
                        {
                            phone=PhoneName();
                            session=logged;
                            stage="MMS-L22 · Opening dashboard";
                            bool remembered=restore && credentials["version"]?.GetValue<int>()==2 && savedEnvelope==logged.VerifiedEnvelope;
                            if(!remembered) remembered=RememberedLogin.Save(Input("source"),Input("user"),Input("password"),logged.VerifiedEnvelope);
                            ReadHistory(logged);
                            await Emit("signed",new JsonObject { ["user"]=logged.User, ["name"]=logged.DisplayName, ["daily"]=logged.CanViewDaily, ["features"]=(long)logged.Features, ["inspect"]=logged.CanInspect, ["developer"]=logged.Developer, ["remembered"]=remembered });
                            if(!ct.IsCancellationRequested) _=Pulse(logged,ct,restore && credentials["version"]?.GetValue<int>()==2);
                        }
                        catch (Exception ex) when (!ct.IsCancellationRequested)
                        {
                            session=null; logged.Dispose();
                            throw new LoginDiagnosticException(stage,ex);
                        }
                    }
                    finally { if(!ct.IsCancellationRequested) { signingIn=false; pendingOtp=null; } }
                    break;
                case "resetStart" when session==null && !signingIn:
                    recoveryChallenge=await MobileSession.RequestRecovery(Field("source"),Field("user"),ct);
                    await Emit("resetCode"); break;
                case "resetFinish" when session==null && !signingIn && recoveryChallenge.Length>0:
                    await MobileSession.ResetPassword(Field("source"),Field("user"),recoveryChallenge,Field("code"),Field("password"),ct);
                    recoveryChallenge=""; await Emit("resetDone"); break;
                case "otp": pendingOtp?.TrySetResult(Field("code")); break;
                case "logout": RememberedLogin.Clear(); resumeWhenActive=false; Lock(); break;
                case "devices" when session!=null && !loading:
                    loading=true;
                    try
                    {
                        var devices=await session.Devices(ct);
                        ct.ThrowIfCancellationRequested(); catalog.Clear();
                        foreach(var device in devices) catalog[device.AgentId]=device;
                        await Emit("groups",new JsonArray(session.Groups.Select(g=>(JsonNode)new JsonObject { ["id"]=g.Key, ["name"]=g.Value }).ToArray()));
                        await Emit("devices",new JsonArray(devices.Select(d=>(JsonNode)new JsonObject { ["id"]=d.AgentId.ToString(), ["serial"]=d.Serial, ["host"]=d.Host, ["group"]=d.GroupId, ["name"]=d.Name }).ToArray()));
                    }
                    finally { if(!ct.IsCancellationRequested) loading=false; }
                    break;
                case "daily" when session is { CanViewDaily:true } dailySession:
                    var selectedDay=Field("day");
                    try
                    {
                        await SyncDays(dailySession,ct);
                        var dailyRows=await dailySession.Daily(selectedDay,ct);
                        if(!ct.IsCancellationRequested) await Emit("daily",new JsonObject {["day"]=selectedDay,["rows"]=dailyRows});
                    }
                    catch(Exception) when(!ct.IsCancellationRequested)
                    {
                        await Emit("daily",new JsonObject {["day"]=selectedDay,["error"]=true});
                    }
                    break;
                case "audit" when session?.Developer==true:
                    var audit=await session.Audit(ct); ct.ThrowIfCancellationRequested(); await Emit("audit",audit); break;
                case "scan" when session!=null:
                    scan?.Cancel(); 
                    using (var currentScan=CancellationTokenSource.CreateLinkedTokenSource(ct))
                    {
                        scan=currentScan;
                        try
                        {
                            var currentSession=session;
                            var candidates=catalog.Values.OrderByDescending(d=>recentlyOnline.Contains(d.AgentId)).ThenByDescending(d=>(history[d.AgentId.ToString()] as JsonArray)?.LastOrDefault()?.ToString(), StringComparer.Ordinal).ThenByDescending(d=>d.LastSeen).ToArray();
                            await Parallel.ForEachAsync(candidates,new ParallelOptions { MaxDegreeOfParallelism=20,CancellationToken=currentScan.Token },
                                async (student, cancel)=>{
                                    using var attempt=CancellationTokenSource.CreateLinkedTokenSource(cancel);
                                    attempt.CancelAfter(TimeSpan.FromSeconds(6));
                                    bool connected=false;
                                    try { await currentSession.CheckPresence(student,attempt.Token); connected=true; }
                                    catch(Exception) when(!cancel.IsCancellationRequested) { }
                                    cancel.ThrowIfCancellationRequested();
                                    var reported=new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
                                    BeginInvokeOnMainThread(async ()=>{
                                        try { if(!cancel.IsCancellationRequested) { if(connected) { recentlyOnline.Add(student.AgentId); Observe(currentSession,student.AgentId); } else recentlyOnline.Remove(student.AgentId); await Emit("reach",new JsonObject { ["id"]=student.AgentId.ToString(), ["online"]=connected }); } reported.TrySetResult(true); }
                                        catch(Exception ex) { reported.TrySetException(ex); }
                                    });
                                    await reported.Task;
                                });
                            if(!currentScan.IsCancellationRequested)
                            {
                                await Emit("scanDone");
                                await SyncDays(currentSession,ct);
                            }
                        }
                        catch(OperationCanceledException) when(currentScan.IsCancellationRequested) { }
                        finally { if(ReferenceEquals(scan,currentScan)) scan=null; }
                    }
                    break;
                case "share" when session!=null && Guid.TryParse(Field("id"),out var shareId) && active.Contains(shareId):
                    bool video=Field("kind")=="video";
                    if(!session.Features.HasFlag(video?SessionCapability.RecordScreen:SessionCapability.CaptureScreenshot)) throw new UnauthorizedAccessException();
                    var suffix=video?".mp4":".jpg";
                    var path=Path.Combine(Path.GetTempPath(),"MMS-"+Guid.NewGuid().ToString("N")+suffix);
                    File.WriteAllBytes(path,Convert.FromBase64String(Field("data")));
                    var sheet=new UIActivityViewController(new NSObject[]{NSUrl.FromFilename(path)},null);
                    sheet.CompletionWithItemsHandler=(_,_,_,_)=>File.Delete(path);
                    if(sheet.PopoverPresentationController is {} popup) popup.SourceView=View;
                    PresentViewController(sheet,true,null);
                    break;
                case "listen" when session!=null && Guid.TryParse(Field("id"),out var audioId) && catalog.TryGetValue(audioId,out var speaker):
                    audioStop?.Cancel();
                    if(args["on"]?.GetValue<bool>()==true) await Listen(speaker,session,streams.Token);
                    break;
                case "control" when session!=null && Guid.TryParse(Field("id"),out var ctrlId) && catalog.TryGetValue(ctrlId,out var desktop):
                    var controlToken=streams.Token;
                    controlLease?.Dispose(); controlLease=null; controlled=Guid.Empty;
                    bool enabled=args["on"]?.GetValue<bool>()==true;
                    if(enabled) {
                        var lease=await session.OpenFeature(desktop,SessionCapability.RemoteControl,controlToken);
                        try { await session.Input(ctrlId,new(RemoteControlMessageType.Enable),controlToken); controlToken.ThrowIfCancellationRequested(); }
                        catch { lease.Dispose(); throw; }
                        controlLease=lease; controlled=ctrlId;
                    } else await session.Input(ctrlId,new(RemoteControlMessageType.Disable),controlToken);
                    await Emit("controlled",new JsonObject {["id"]=ctrlId.ToString(),["on"]=enabled});
                    break;
                case "tap" when session!=null && controlLease!=null && Guid.TryParse(Field("id"),out var clickId) && clickId==controlled:
                    var inputToken=streams.Token;
                    await session.Input(clickId,new(RemoteControlMessageType.MouseMove,(ushort)Math.Clamp(args["x"]!.GetValue<int>(),0,65535),(ushort)Math.Clamp(args["y"]!.GetValue<int>(),0,65535)),inputToken);
                    await session.Input(clickId,new(RemoteControlMessageType.MouseButtonDown,MouseButton:RemoteMouseButton.Left),inputToken);
                    await session.Input(clickId,new(RemoteControlMessageType.MouseButtonUp,MouseButton:RemoteMouseButton.Left),inputToken);
                    break;
                case "inspect" when session!=null && session.CanInspect:
                    if(Guid.TryParse(Field("id"),out var target) && catalog.TryGetValue(target,out var endpoint))
                    {
                        try { var result=await session.Inspect(endpoint,Field("preset"),streams.Token,Field("script"));
                        ct.ThrowIfCancellationRequested();
                        await Emit("inspection",new JsonObject { ["id"]=target.ToString(), ["text"]=result }); }
                        catch(Exception ex) when (!ct.IsCancellationRequested) { await Emit("inspection",new JsonObject { ["id"]=target.ToString(), ["text"]="PowerShell � "+ex.GetBaseException().Message }); }
                    }
                    break;
                case "endScan": scan?.Cancel(); break;
                case "stop": StopStreams(); break;
                case "view" when session!=null:
                    if(!Guid.TryParse(Field("id"),out var id) || !catalog.TryGetValue(id,out var deviceRow)) return;
                    bool live=args["live"]?.GetValue<bool>()==true;
                    if(active.Count>=6 || !active.Add(id)) return;
                    await Present(deviceRow,live,session,streams.Token); break;
            }
        }
        catch(OperationCanceledException) when(ct.IsCancellationRequested) { }
        catch(LoginDiagnosticException ex) when(!ct.IsCancellationRequested)
        {
            try { await Emit("error",ex.Message); }
            catch { if(!ct.IsCancellationRequested) { startup.Text=ex.Message; startup.Hidden=false; } }
        }
        catch(Exception ex)
        {
            if(!ct.IsCancellationRequested) await Emit("error",ex is HttpRequestException h && h.StatusCode!=null ?
                $"Request failed · HTTP {(int)h.StatusCode}" : "Request failed. Check your connection and account details, then try again.");
        }
    }

    private async Task Present(Student student,bool live,MobileSession current,CancellationToken ct)
    {
        try
        {
            while(!ct.IsCancellationRequested)
            {
                try
                {
                    long last=0;
                    await foreach(var bytes in current.Frames(student,live,ct))
                    {
                        ct.ThrowIfCancellationRequested();
                        if(live && Environment.TickCount64-last<100) continue;
                        last=Environment.TickCount64;
                        Observe(current,student.AgentId);
                        await Emit("frame",new JsonObject { ["id"]=student.AgentId.ToString(), ["data"]=Convert.ToBase64String(bytes) });
                    }
                }
                catch(OperationCanceledException) when(ct.IsCancellationRequested) { return; }
                catch(Exception)
                {
                    ct.ThrowIfCancellationRequested();
                    await Emit("unavailable",new JsonObject { ["id"]=student.AgentId.ToString() });
                    await Task.Delay(8000,ct);
                }
            }
        }
        catch(OperationCanceledException) when(ct.IsCancellationRequested) { }
        finally { if(!ct.IsCancellationRequested) active.Remove(student.AgentId); }
    }
}
