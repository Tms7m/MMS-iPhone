using System.Runtime.InteropServices;
using Foundation;
using UIKit;
using WebKit;
using System.Text.Json;
using System.Text.Json.Nodes;
using MMS.Mobile;

namespace MMS.Phone;

public static class Program
{
    public static void Main(string[] args)
    {
        if (StartupProbe.Enabled) Console.Error.WriteLine("MMS startup: managed-main 1.0.12");
        RequireUIKitClass(typeof(AppDelegate), "MMSApplicationDelegate");
        RequireUIKitClass(typeof(SceneDelegate), "MMSSceneDelegate");
        RequireUIKitClass(typeof(Dashboard), "MMSDashboard");
        EnsureSceneProtocols();
        UIApplication.Main(args, null, typeof(AppDelegate));
    }

    // UIKit checks the Objective-C class itself when it reads the scene manifest.
    private static void EnsureSceneProtocols()
    {
        var sceneClass = ObjCRuntime.Class.GetHandle(typeof(SceneDelegate));
        foreach (var name in new[] { "UISceneDelegate", "UIWindowSceneDelegate" })
        {
            var protocol = ObjCRuntime.Protocol.GetHandle(name);
            if (protocol == IntPtr.Zero)
                throw new InvalidOperationException($"UIKit protocol unavailable: {name}");
            if (!ClassConformsToProtocol(sceneClass, protocol))
                ClassAddProtocol(sceneClass, protocol);
            if (!ClassConformsToProtocol(sceneClass, protocol))
                throw new InvalidOperationException($"MMSSceneDelegate does not conform to {name}.");
            if (StartupProbe.Enabled) Console.Error.WriteLine($"MMS startup: scene conforms to {name}");
        }
    }

    [DllImport("/usr/lib/libobjc.A.dylib", EntryPoint = "class_conformsToProtocol")]
    [return: MarshalAs(UnmanagedType.I1)]
    private static extern bool ClassConformsToProtocol(IntPtr cls, IntPtr protocol);

    [DllImport("/usr/lib/libobjc.A.dylib", EntryPoint = "class_addProtocol")]
    [return: MarshalAs(UnmanagedType.I1)]
    private static extern bool ClassAddProtocol(IntPtr cls, IntPtr protocol);

    private static void RequireUIKitClass(Type type, string nativeName)
    {
        var managed = ObjCRuntime.Class.GetHandle(type);
        var native = ObjCRuntime.Class.GetHandle(nativeName);
        if (native == IntPtr.Zero || managed != native)
            throw new InvalidOperationException($"UIKit class registration failed for {nativeName}.");
        if (StartupProbe.Enabled) Console.Error.WriteLine($"MMS startup: registered {nativeName}");
    }
}

internal static class StartupProbe
{
    public static bool Enabled =>
#if MMS_SIMULATOR_PROBE
        true;
#else
        false;
#endif
    public static void Stage(string stage)
    {
        if (!Enabled) return;
        Console.Error.WriteLine("MMS startup: " + stage);
        var documents = NSFileManager.DefaultManager.GetUrls(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomain.User)[0].Path!;
        Directory.CreateDirectory(documents);
        File.AppendAllText(Path.Combine(documents, "mms-startup-trace"), stage + "\n");
        if (stage == "ready") File.WriteAllText(Path.Combine(documents, "mms-login-ready"), "1");
    }
}

[Register("MMSApplicationDelegate")]
public sealed class AppDelegate : UIApplicationDelegate
{
    public AppDelegate() { }
    public AppDelegate(ObjCRuntime.NativeHandle handle) : base(handle) { }

    public override bool FinishedLaunching(UIApplication application, NSDictionary? options)
    {
        StartupProbe.Stage("application-launched");
        return true;
    }
}

[Preserve(AllMembers=true)]
[Register("MMSSceneDelegate")]
public sealed class SceneDelegate : UIResponder, IUIWindowSceneDelegate
{
    public SceneDelegate() { }
    public SceneDelegate(ObjCRuntime.NativeHandle handle) : base(handle) { }

    [Export("window")]
    public UIWindow? Window { get; set; }

    [Export("scene:willConnectToSession:options:")]
    public void WillConnect(UIScene scene, UISceneSession session, UISceneConnectionOptions options)
    {
        StartupProbe.Stage(Window?.RootViewController is Dashboard ? "scene-with-dashboard" : "scene-connected");
    }

    [Export("sceneDidBecomeActive:")]
    public void DidBecomeActive(UIScene scene)
    {
        if (Window?.RootViewController is Dashboard dashboard) dashboard.OnForeground();
    }

    [Export("sceneDidEnterBackground:")]
    public void DidEnterBackground(UIScene scene)
    {
        if (Window?.RootViewController is Dashboard dashboard) dashboard.OnBackground();
    }
}

public sealed class LocalNavigation : WKNavigationDelegate
{
    public override void DecidePolicy(WKWebView webView, WKNavigationAction action, Action<WKNavigationActionPolicy> handler)
    {
        handler(action.TargetFrame?.MainFrame == true && action.Request.Url?.AbsoluteString == "about:blank"
            ? WKNavigationActionPolicy.Allow : WKNavigationActionPolicy.Cancel);
    }
    public override void DidFinishNavigation(WKWebView webView, WKNavigation navigation) => StartupProbe.Stage("document-loaded");
    public override void DidFailProvisionalNavigation(WKWebView webView, WKNavigation navigation, NSError error) =>
        StartupProbe.Stage("document-load-error-" + error.Code);

}

[Register("MMSDashboard")]
[Preserve(AllMembers=true)]
public sealed class Dashboard : UIViewController, IWKScriptMessageHandler
{
    public Dashboard(ObjCRuntime.NativeHandle handle) : base(handle) { }

    private WKWebView web=null!;
    private readonly LocalNavigation navigation=new();
    private CancellationTokenSource lifetime=new(), streams=new();
    private readonly Dictionary<Guid,Student> catalog=new();
    private readonly HashSet<Guid> active=new();
    private MobileSession? session;
    private TaskCompletionSource<string>? pendingOtp;
    private bool signingIn, loading;
    private CancellationTokenSource? scan;
    private string phone="";
    private string recoveryChallenge="";
    private string PhoneName()
    {
        var defaults=NSUserDefaults.StandardUserDefaults;
        var saved=defaults.StringForKey("MMSDeviceLabel");
        if(!string.IsNullOrEmpty(saved)) return saved;
        var label="iPhone-"+Guid.NewGuid().ToString("N")[..8];
        defaults.SetString(label,"MMSDeviceLabel");
        return label;
    }

    private async Task Pulse(MobileSession current,CancellationToken ct)
    {
        var id=Guid.NewGuid(); var started=DateTimeOffset.UtcNow; bool announced=false;
        while(!ct.IsCancellationRequested)
        {
            try
            {
                if(!announced)
                {
                    await current.ReportEvent(phone,false,id,started,ct); announced=true;
                }
                await current.ReportPresence(phone,false,ct);
            }
            catch(OperationCanceledException) when(ct.IsCancellationRequested) { return; }
            catch(HttpRequestException) { /* Retry when the connection returns. */ }
            catch(System.Text.Json.JsonException) { }
            try { await Task.Delay(30000,ct); }
            catch(OperationCanceledException) { return; }
        }
    }

    private async Task CloseSession(MobileSession current)
    {
        using var deadline=new CancellationTokenSource(TimeSpan.FromSeconds(5));
        try
        {
            await Task.WhenAll(current.ReportPresence(phone,true,deadline.Token),
                current.ReportEvent(phone,true,Guid.NewGuid(),DateTimeOffset.UtcNow,deadline.Token));
        }
        catch(HttpRequestException) { }
        catch(OperationCanceledException) { }
        catch(System.Text.Json.JsonException) { }
    }
    public override void ViewDidLoad()
    {
        base.ViewDidLoad();
        StartupProbe.Stage("view-loaded");
        var config=new WKWebViewConfiguration { WebsiteDataStore=WKWebsiteDataStore.NonPersistentDataStore };
        config.UserContentController.AddScriptMessageHandler(this,"mms");
        web=new WKWebView(CoreGraphics.CGRect.Empty,config){NavigationDelegate=navigation, TranslatesAutoresizingMaskIntoConstraints=false};
        if(web.ScrollView.PinchGestureRecognizer is {} pinch) pinch.Enabled=false;
        View!.BackgroundColor=UIColor.SystemBackground;
        View.AddSubview(web);
        var guide=View.SafeAreaLayoutGuide;
        NSLayoutConstraint.ActivateConstraints([web.TopAnchor.ConstraintEqualTo(guide.TopAnchor),web.BottomAnchor.ConstraintEqualTo(guide.BottomAnchor),
            web.LeadingAnchor.ConstraintEqualTo(guide.LeadingAnchor),web.TrailingAnchor.ConstraintEqualTo(guide.TrailingAnchor)]);
        startup.TextAlignment=UITextAlignment.Center;
        startup.Lines=0;
        startup.TextColor=UIColor.Label;
        startup.BackgroundColor=UIColor.SystemBackground;
        startup.TranslatesAutoresizingMaskIntoConstraints=false;
        View.AddSubview(startup);
        NSLayoutConstraint.ActivateConstraints([startup.TopAnchor.ConstraintEqualTo(guide.TopAnchor),startup.BottomAnchor.ConstraintEqualTo(guide.BottomAnchor),
            startup.LeadingAnchor.ConstraintEqualTo(guide.LeadingAnchor),startup.TrailingAnchor.ConstraintEqualTo(guide.TrailingAnchor)]);
        startup.Text="MMS Supervisor · 1.0.12\nOpening sign-in…";
        var assets = Path.Combine(NSBundle.MainBundle.BundlePath, "Web");
        try
        {
            var nonce = Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(24));
            var html = File.ReadAllText(Path.Combine(assets, "index.html"))
                .Replace("{{NONCE}}", nonce)
                .Replace("{{STYLE}}", File.ReadAllText(Path.Combine(assets, "style.css")))
                .Replace("{{LOGO}}", Convert.ToBase64String(File.ReadAllBytes(Path.Combine(assets, "MMS.png"))))
                .Replace("{{SCRIPT}}", File.ReadAllText(Path.Combine(assets, "app.js")));
            StartupProbe.Stage("document-submitted");
            web.LoadHtmlString(html, new NSUrl("about:blank"));
        }
        catch (IOException)
        {
            StartupProbe.Stage("missing-interface-resource");
            startup.Text = "MMS · Could not load the sign-in interface";
            return;
        }
        _=CheckStartupAsync();
    }

    private readonly UILabel startup=new();
    private async Task CheckStartupAsync()
    {
        await Task.Delay(TimeSpan.FromSeconds(15));
        if(!startup.Hidden) startup.Text="MMS 1.0.12 · Could not open sign-in (WEB-START)";
    }

    private Task Emit(string name,JsonNode? value=null) =>
        web.EvaluateJavaScriptAsync("window.receive("+System.Text.Json.JsonSerializer.Serialize(name, MobileJsonContext.Default.String)+","+(value is null ? "null" : System.Text.Json.JsonSerializer.Serialize(value, MobileJsonContext.Default.JsonNode))+")");

    private void StopStreams()
    {
        streams.Cancel(); streams.Dispose();
        streams=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token);
        active.Clear();
    }
    private bool resumeWhenActive;
    public void OnBackground()
    {
        if (session != null) { resumeWhenActive=true; Lock(); }
    }
    public void OnForeground()
    {
        if(resumeWhenActive) { resumeWhenActive=false; _=Emit("resume"); }
    }
    public void Lock()
    {
        lifetime.Cancel(); lifetime.Dispose(); lifetime=new();
        StopStreams(); pendingOtp?.TrySetCanceled(); pendingOtp=null;
        if(session is {} current) { _=CloseSession(current); current.Dispose(); } session=null; catalog.Clear(); signingIn=false; loading=false;
        if(web!=null) _=Emit("locked");
    }

    [Export("userContentController:didReceiveScriptMessage:")]
    public async void DidReceiveScriptMessage(WKUserContentController controller,WKScriptMessage msg)
    {
        if(!msg.FrameInfo.MainFrame || msg.Body is not NSString raw || raw.Length>8192) return;
        var ct=lifetime.Token;
        try
        {
            var args=JsonNode.Parse(raw.ToString())!;
            string Field(string key)=>args[key]?.GetValue<string>()??"";
            switch(Field("op"))
            {
                case "ready":
                    startup.Hidden=true;
                    StartupProbe.Stage("ready");
                    break;
                case "resume" when session==null && !signingIn:
                case "login" when session==null && !signingIn:
                    signingIn=true;
                    try
                    {
                        var restore=Field("op")=="resume";
                        var credentials=restore ? RememberedLogin.Read() : args;
                        if(credentials==null) break;
                        string Input(string key)=>credentials[key]?.ToString() ?? "";
                        var logged=await MobileSession.Login(Input("source"),Input("user"),Input("password"),async token=>{
                            var prompt=new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
                            pendingOtp=prompt;
                            await Emit("otp");
                            return await prompt.Task.WaitAsync(token);
                        },ct);
                        if(ct.IsCancellationRequested) { logged.Dispose(); return; }
                        var stage="MMS-L21 · Initializing iPhone session";
                        try
                        {
                            phone=PhoneName();
                            session=logged;
                            stage="MMS-L22 · Opening dashboard";
                            bool remembered=restore || RememberedLogin.Save(Input("source"),Input("user"),Input("password"));
                            await Emit("signed",new JsonObject { ["user"]=logged.User, ["name"]=logged.DisplayName, ["developer"]=logged.Developer, ["remembered"]=remembered });
                            if(!ct.IsCancellationRequested) _=Pulse(logged,ct);
                        }
                        catch (Exception ex) when (!ct.IsCancellationRequested)
                        {
                            session=null; logged.Dispose();
                            throw new LoginDiagnosticException(stage,ex);
                        }
                    }
                    finally { if(!ct.IsCancellationRequested) { signingIn=false; pendingOtp=null; } }
                    break;
                case "resetStart" when session==null && !signingIn:
                    recoveryChallenge=await MobileSession.RequestRecovery(Field("source"),Field("user"),ct);
                    await Emit("resetCode"); break;
                case "resetFinish" when session==null && !signingIn && recoveryChallenge.Length>0:
                    await MobileSession.ResetPassword(Field("source"),Field("user"),recoveryChallenge,Field("code"),Field("password"),ct);
                    recoveryChallenge=""; await Emit("resetDone"); break;
                case "otp": pendingOtp?.TrySetResult(Field("code")); break;
                case "logout": RememberedLogin.Clear(); resumeWhenActive=false; Lock(); break;
                case "devices" when session!=null && !loading:
                    loading=true;
                    try
                    {
                        var devices=await session.Devices(ct);
                        ct.ThrowIfCancellationRequested(); catalog.Clear();
                        foreach(var device in devices) catalog[device.AgentId]=device;
                        await Emit("groups",new JsonArray(session.Groups.Select(g=>(JsonNode)new JsonObject { ["id"]=g.Key, ["name"]=g.Value }).ToArray()));
                        await Emit("devices",new JsonArray(devices.Select(d=>(JsonNode)new JsonObject { ["id"]=d.AgentId.ToString(), ["host"]=d.Host, ["group"]=d.GroupId, ["name"]=d.Name }).ToArray()));
                    }
                    finally { if(!ct.IsCancellationRequested) loading=false; }
                    break;
                case "audit" when session?.Developer==true:
                    var audit=await session.Audit(ct); ct.ThrowIfCancellationRequested(); await Emit("audit",audit); break;
                case "scan" when session!=null:
                    scan?.Cancel(); 
                    using (var currentScan=CancellationTokenSource.CreateLinkedTokenSource(ct))
                    {
                        scan=currentScan;
                        try
                        {
                            var currentSession=session;
                            var candidates=catalog.Values.ToArray();
                            await Parallel.ForEachAsync(candidates,new ParallelOptions { MaxDegreeOfParallelism=3,CancellationToken=currentScan.Token },
                                async (student, cancel)=>{
                                    using var attempt=CancellationTokenSource.CreateLinkedTokenSource(cancel);
                                    attempt.CancelAfter(TimeSpan.FromSeconds(6));
                                    bool connected=false;
                                    try { await foreach(var frame in currentSession.Frames(student,false,attempt.Token)) { connected=true; break; } }
                                    catch(Exception) when(!cancel.IsCancellationRequested) { }
                                    cancel.ThrowIfCancellationRequested();
                                    var reported=new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
                                    BeginInvokeOnMainThread(async ()=>{
                                        try { if(!cancel.IsCancellationRequested) await Emit("reach",new JsonObject { ["id"]=student.AgentId.ToString(), ["online"]=connected }); reported.TrySetResult(true); }
                                        catch(Exception ex) { reported.TrySetException(ex); }
                                    });
                                    await reported.Task;
                                });
                            if(!currentScan.IsCancellationRequested) await Emit("scanDone");
                        }
                        catch(OperationCanceledException) when(currentScan.IsCancellationRequested) { }
                        finally { if(ReferenceEquals(scan,currentScan)) scan=null; }
                    }
                    break;
                case "endScan": scan?.Cancel(); break;
                case "stop": StopStreams(); break;
                case "view" when session!=null:
                    if(!Guid.TryParse(Field("id"),out var id) || !catalog.TryGetValue(id,out var deviceRow)) return;
                    bool live=args["live"]?.GetValue<bool>()==true;
                    if(active.Count>=6 || !active.Add(id)) return;
                    await Present(deviceRow,live,session,streams.Token); break;
            }
        }
        catch(OperationCanceledException) when(ct.IsCancellationRequested) { }
        catch(LoginDiagnosticException ex) when(!ct.IsCancellationRequested)
        {
            try { await Emit("error",ex.Message); }
            catch { if(!ct.IsCancellationRequested) { startup.Text=ex.Message; startup.Hidden=false; } }
        }
        catch(Exception ex)
        {
            if(!ct.IsCancellationRequested) await Emit("error",ex is HttpRequestException h && h.StatusCode!=null ?
                $"Request failed · HTTP {(int)h.StatusCode}" : "Request failed. Check your connection and account details, then try again.");
        }
    }

    private async Task Present(Student student,bool live,MobileSession current,CancellationToken ct)
    {
        try
        {
            while(!ct.IsCancellationRequested)
            {
                try
                {
                    long last=0;
                    await foreach(var bytes in current.Frames(student,live,ct))
                    {
                        ct.ThrowIfCancellationRequested();
                        if(live && Environment.TickCount64-last<100) continue;
                        last=Environment.TickCount64;
                        await Emit("frame",new JsonObject { ["id"]=student.AgentId.ToString(), ["data"]=Convert.ToBase64String(bytes) });
                    }
                }
                catch(OperationCanceledException) when(ct.IsCancellationRequested) { return; }
                catch(Exception)
                {
                    ct.ThrowIfCancellationRequested();
                    await Emit("unavailable",new JsonObject { ["id"]=student.AgentId.ToString() });
                    await Task.Delay(8000,ct);
                }
            }
        }
        catch(OperationCanceledException) when(ct.IsCancellationRequested) { }
        finally { if(!ct.IsCancellationRequested) active.Remove(student.AgentId); }
    }
}
