(()=>{
'use strict';
const $=id=>document.getElementById(id);
const send=(op,args={})=>window.webkit.messageHandlers.mms.postMessage(JSON.stringify({op,...args}));
const show=(id,on)=>$(id).hidden=!on;
const text=(id,value)=>$(id).textContent=value;
const make=(tag,value)=>{const n=document.createElement(tag);if(value!==undefined)n.textContent=value;return n};
let mode='login',devices=[],groups=[],group='*',page=0,cols=2,zoom=0,auditTimer,scanTimer;
let developer=false,waiting=false,scanning=false,checked=0,challenge=false;
let pageKey=null,liveId='';
const dubaiDay=()=>new Date(Date.now()+4*3600000).toISOString().slice(0,10);
function renderHistory(){
  $('historyDevices').replaceChildren();text('historyCount','Loading…');send('daily',{day:$('historyDate').value});
}
const online=new Set(), pictures=new Map();
function stop(){send('stop');pictures.clear();pageKey=null}
function endScan(){clearTimeout(scanTimer);send('endScan');scanning=false}
function screen(next){
  resetMedia();
  stop();endScan();clearInterval(auditTimer);mode=next;
  for(const id of ['login','list','live','audit','me','history'])show(id,id===next);
  show('nav',['list','audit','me'].includes(next));
  for(const [id,tab] of [['students','list'],['supervisors','audit'],['account','me']])$(id).classList.toggle('active',tab===next);
  text('status','');
}
function refresh(){if(mode==='list'){endScan();send('devices')}}
function startScan(){
  endScan();
  if(mode==='list'&&$('online').checked&&devices.length){checked=0;scanning=true;send('scan');draw()}
}
function tabs(){
  const tabs=$('groups');tabs.replaceChildren();
  const values=[['*','All devices'],...groups.map(g=>[g.id,g.name]),['','Ungrouped']];
  if(!values.some(([id])=>id===group))group='*';
  for(const [id,label] of values){
    const b=make('button',label);b.classList.toggle('active',id===group);
    b.onclick=()=>{group=id;page=0;tabsUpdate()};tabs.append(b);
  }
}
function tabsUpdate(){tabs();draw()}
function frame(id,target,live){
  const f=make('figure','Connecting…');target.append(f);pictures.set(id,f);send('view',{id,live});
}
function setZoom(n){
  zoom=Math.max(0,Math.min(3,n));$('player').className=['','z2','z3','z4'][zoom];
  text('scale',[100,150,200,300][zoom]+'%');$('zoomOut').disabled=zoom===0;$('zoomIn').disabled=zoom===3;
}
function draw(){
  if(mode!=='list')return;
  const q=$('search').value.trim().toLowerCase();
  const items=devices.filter(d=>(group==='*'||(d.group||'')===group)&&(!$('online').checked||online.has(d.id))&&(d.name+' '+d.host).toLowerCase().includes(q));
  const pages=Math.max(1,Math.ceil(items.length/6));page=Math.min(page,pages-1);
  text('page',(page+1)+' / '+pages);$('prev').disabled=page===0;$('next').disabled=page+1===pages;
  text('status',items.length+' devices'+(scanning?' · Checking '+checked+' / '+devices.length:''));
  const slice=items.slice(page*6,page*6+6);const key=JSON.stringify(slice.map(d=>[d.id,d.name,d.host]));
  if(key===pageKey)return;
  const grid=$('grid'), existing=Array.from(grid.children);
  const appendOnly=pageKey!==null&&existing.length<=slice.length&&existing.every((card,i)=>card.dataset.key===JSON.stringify([slice[i].id,slice[i].name,slice[i].host]));
  if(!appendOnly){stop();grid.replaceChildren()}
  pageKey=key;
  for(const d of slice.slice(appendOnly?existing.length:0)){
    const b=make('button');b.dataset.key=JSON.stringify([d.id,d.name,d.host]);$('grid').append(b);frame(d.id,b,false);
    b.append(make('b',d.name||d.host),make('small',d.host));
    b.onclick=()=>{screen('live');liveId=d.id;text('psResult','');$('psPanel').open=false;text('liveName',d.name||d.host);$('player').replaceChildren();setZoom(0);frame(d.id,$('player'),true)};
  }
}
function list(){screen('list');tabsUpdate();refresh()}
function audit(){
  if(!developer)return;screen('audit');waiting=false;
  const load=()=>{if(!waiting){waiting=true;send('audit')}};load();auditTimer=setInterval(load,30000);
}
function rows(id,items,details){
  const target=$(id);target.replaceChildren();
  for(const row of items){const tile=make('article');tile.append(make('strong',row.user||row.userName),make('small',details(row)));target.append(tile)}
  if(!items.length)target.textContent='No records';
}
function date(value){return new Date(value.replace(' ','T')).toLocaleString('en-GB')}
function resetMode(on){
  show('form',!on);show('recovery',on);show('verify',false);challenge=false;show('resetFields',false);
  $('resetOrg').readOnly=$('resetUser').readOnly=false;$('resetSubmit').disabled=false;
  $('resetPass').value=$('resetCode').value='';text('resetSubmit','Send code');
  $('resetOrg').value=$('source').value;$('resetUser').value=$('user').value;text('status','');
}
window.receive=(name,value)=>{
  if(name==='restoring'){show('saved',true);show('form',false);text('status','Resuming session…')}
  if(name==='signed'){show('captureMenu',!!(value.features&6));for(const [id,bit] of [['shot',2],['record',4],['audio',8],['control',16]])show(id,!!(value.features&bit));show('saved',false);
    show('daily',!!value.daily);show('psPanel',!!value.inspect);show('openShell',!!value.inspect);developer=value.developer;show('supervisors',developer);text('identity',value.user);
    text('profile',value.name||value.user);text('memory',value.remembered?'Sign-in saved on this iPhone':'Sign-in could not be saved to the iPhone Keychain');
    show('verify',false);$('password').value='';list();
  }
  if(name==='resume'&&mode==='login')send('resume');
  if(name==='otp'){show('form',false);show('verify',true);$('code').focus();text('status','Enter the code sent to your email.')}
  if(name==='groups'){groups=value;tabs()}
  if(name==='devices'){devices=value;draw();startScan()}
  if(name==='reach'&&scanning){checked++;if(value.online){online.add(value.id)}else online.delete(value.id);draw()}
  if(name==='scanDone'&&scanning){scanning=false;draw();scanTimer=setTimeout(startScan,45000)}
  if(name==='daily'&&mode==='history'&&value.day===$('historyDate').value){
    $('historyDevices').replaceChildren();
    if(value.error){text('historyCount','Unable to load organization report');return}
    for(const r of value.rows.sort((a,b)=>a.host.localeCompare(b.host))){
      const line=make('article');line.append(make('strong',r.host),make('small',r.student));$('historyDevices').append(line);
    }
    text('historyCount',value.rows.length+' devices');
  }
  if(name==='audit'&&mode==='audit'){
    waiting=false;rows('presence',value.presence,r=>r.computer+' · '+(r.online?'Online':'Offline')+' · '+date(r.seen));
    rows('events',value.events,r=>r.computer+' · '+(r.action==='SIGN_IN'?'Signed in':'Signed out')+' · '+date(r.occurred));
  }
  if(name==='keyboardReady'&&controlOn&&value.id===liveId){$('keyboard').disabled=false;text('keyboard','Keyboard')}
  if(name==='controlled'&&mode==='live'&&liveId===value.id){setControlMode(value.on)}
  if(name==='audio'&&mode==='live'&&liveId===value.id&&audioCtx){
    const ctx=audioCtx,bytes=Uint8Array.from(atob(value.data),c=>c.charCodeAt(0)),samples=new Int16Array(bytes.buffer,0,Math.floor(bytes.length/2));
    const buf=ctx.createBuffer(1,samples.length,48000),out=buf.getChannelData(0);
    for(let i=0;i<samples.length;i++)out[i]=samples[i]/32768;
    const node=ctx.createBufferSource();node.buffer=buf;node.connect(ctx.destination);
    if(nextSound<ctx.currentTime||nextSound>ctx.currentTime+0.5)nextSound=ctx.currentTime+0.03;
    node.start(nextSound);nextSound+=buf.duration;
  }
  if(name==='frame'&&pictures.has(value.id)){const box=pictures.get(value.id);let img=box.firstElementChild;
    if(!img){img=make('img');img.alt='Student screen';box.replaceChildren(img)}img.src='data:image/jpeg;base64,'+value.data}
  if(name==='unavailable'&&pictures.has(value.id))pictures.get(value.id).textContent='Unavailable · retrying';
  if(name==='inspection'&&mode==='live'&&liveId===value.id)text('psResult',value.text);
  if(name==='resetCode'){
    challenge=true;show('resetFields',true);$('resetOrg').readOnly=$('resetUser').readOnly=true;
    $('resetSubmit').disabled=false;text('resetSubmit','Reset password');text('status','Enter your email code and a new password.');
  }
  if(name==='resetDone'){resetMode(false);text('status','Password updated. Sign in with your new password.')}
  if(name==='error'){if(mode==='live'){text('status',value);return;}waiting=false;text('status',value);$('resetSubmit').disabled=false;
    if(mode==='login'&&$('recovery').hidden&&$('saved').hidden){$('enter').disabled=false;show('verify',false);show('form',true)}}
  if(name==='locked'){show('saved',false);screen('login');devices=[];groups=[];group='*';online.clear();page=0;developer=false;
    for(const id of ['grid','player','presence','events','profile','identity','groups'])$(id).replaceChildren();
    $('online').checked=false;$('form').reset();$('verify').reset();$('search').value='';resetMode(false);$('enter').disabled=false}
};
$('form').onsubmit=e=>{e.preventDefault();$('enter').disabled=true;text('status','Signing in…');
 send('login',{source:$('source').value,user:$('user').value,password:$('password').value});$('password').value=''};
$('verify').onsubmit=e=>{e.preventDefault();send('otp',{code:$('code').value.trim()});$('code').value=''};
$('forgot').onclick=()=>resetMode(true);$('resetBack').onclick=()=>resetMode(false);
$('recovery').onsubmit=e=>{e.preventDefault();if(challenge&&(!$('resetCode').value.trim()||$('resetPass').value.length<10)){text('status','Enter the email code and a password of at least 10 characters.');return}
 $('resetSubmit').disabled=true;send(challenge?'resetFinish':'resetStart',{source:$('resetOrg').value,user:$('resetUser').value,code:$('resetCode').value,password:$('resetPass').value})};
$('retrySaved').onclick=()=>send('resume');$('forgetSaved').onclick=()=>send('logout');
$('account').onclick=()=>screen('me');$('exit').onclick=()=>send('logout');$('students').onclick=list;$('supervisors').onclick=audit;
$('daily').onclick=()=>{screen('history');$('historyDate').value=dubaiDay();renderHistory()};
$('historyBack').onclick=list;$('historyDate').onchange=renderHistory;
let controlOn=false,audioCtx=null,nextSound=0,rec=null,videoBlob=null,stopTimer;
function resetMedia(){
  if(rec&&rec.state==='recording')rec.stop();rec=null;videoBlob=null;clearTimeout(stopTimer);
  if(audioCtx)audioCtx.close();audioCtx=null;setControlMode(false);text('audio','Listen');text('control','Control');text('record','Record video');show('saveVideo',false);
}
function share(blob,kind){
  if(!blob||blob.size>32*1024*1024){text('status','File exceeds the sharing limit.');return}
  const id=liveId,reader=new FileReader();reader.onload=()=>{if(mode==='live'&&id===liveId)send('share',{id,kind,data:reader.result.split(',')[1]})};reader.readAsDataURL(blob);
}
function currentImage(){const img=$('player').querySelector('img');if(img&&img.naturalWidth)return img;text('status','Waiting for a screen frame.');return null}
$('shot').onclick=()=>{const img=currentImage();if(img)send('share',{id:liveId,kind:'image',data:img.src.split(',')[1]})};
$('record').onclick=()=>{
  if(rec&&rec.state==='recording'){rec.stop();return}
  const img=currentImage();if(!img)return;
  try{
    const canvas=make('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;
    const ctx=canvas.getContext('2d');ctx.drawImage(img,0,0);
    const stream=canvas.captureStream(10),r=new MediaRecorder(stream,{mimeType:'video/mp4',videoBitsPerSecond:1500000}),chunks=[];
    const timer=setInterval(()=>{if(img.complete&&img.naturalWidth)ctx.drawImage(img,0,0,canvas.width,canvas.height)},100);
    rec=r;r.ondataavailable=e=>chunks.push(e.data);r.onstop=()=>{clearInterval(timer);stream.getTracks().forEach(t=>t.stop());if(rec!==r)return;clearTimeout(stopTimer);videoBlob=new Blob(chunks,{type:'video/mp4'});show('saveVideo',true);text('record','Record video');rec=null};
    r.start();stopTimer=setTimeout(()=>{if(r.state==='recording')r.stop()},60000);text('record','Stop recording');
  }catch(e){text('status',e.message)}
};
$('saveVideo').onclick=()=>share(videoBlob,'video');
$('audio').onclick=async()=>{if(audioCtx){await audioCtx.close();audioCtx=null}else{audioCtx=new AudioContext();await audioCtx.resume()}text('audio',audioCtx?'Stop listening':'Listen');send('listen',{id:liveId,on:!!audioCtx})};
$('control').onclick=()=>send('control',{id:liveId,on:!controlOn});
let gesture=null,lastPoint={x:32768,y:32768},moveFrame=0;
function setControlMode(on){
  endGesture(false);controlOn=on;$('keyboard').disabled=true;text('keyboard','Keyboard · Student 10.8.20+');document.body.classList.toggle('controlling',on);
  $('captureMenu').open=false;$('psPanel').open=false;$('typing').blur();
  show('pointerMark',on);text('control',on?'Exit control':'Control');
  if(on){setZoom(0);lastPoint={x:32768,y:32768};requestAnimationFrame(drawCursor)}
}
function geometry(){
  const img=$('player').querySelector('img');if(!img?.naturalWidth)return null;
  const scale=Math.min(img.clientWidth/img.naturalWidth,img.clientHeight/img.naturalHeight);
  const w=scale*img.naturalWidth,h=scale*img.naturalHeight;
  if(!w||!h)return null;
  return {r:img.getBoundingClientRect(),left:img.clientWidth-w,top:(img.clientHeight-h)/2,w,h,img};
}
function drawCursor(){
  const g=geometry();if(!g)return;
  $('pointerMark').style.left=($('player').offsetLeft+g.left+lastPoint.x*g.w/65535)+'px';
  $('pointerMark').style.top=($('player').offsetTop+g.top+lastPoint.y*g.h/65535)+'px';
}
const bound=n=>Math.max(0,Math.min(65535,n));
function absolutePoint(e,clamp){
  const g=geometry();if(!g)return null;
  const rotated=matchMedia('(orientation:portrait)').matches;
  const x=((rotated?e.clientY-g.r.top:e.clientX-g.r.left)-g.left)/g.w;
  const y=((rotated?g.r.right-e.clientX:e.clientY-g.r.top)-g.top)/g.h;
  if(!clamp&&(x<0||x>1||y<0||y>1))return null;
  return {x:bound(x*65535),y:bound(y*65535)};
}
function pointer(phase){send('pointer',{id:liveId,phase,x:Math.round(lastPoint.x),y:Math.round(lastPoint.y)})}
function endGesture(tap){
  const g=gesture;if(!g)return;gesture=null;clearTimeout(g.timer);cancelAnimationFrame(moveFrame);moveFrame=0;
  if(g.drag)pointer('up');else if(tap&&!g.moved&&!g.right){pointer('down');pointer('up')}
  else if(g.moved)pointer('move');
  if(g.surface.hasPointerCapture(g.id))g.surface.releasePointerCapture(g.id);
}
function startGesture(e,pad){
  if(!controlOn||gesture||e.target.closest('button,textarea'))return;
  if(!geometry())return;
  if(!pad){const point=absolutePoint(e,false);if(!point)return;lastPoint=point}
  e.preventDefault();drawCursor();
  const g={surface:e.currentTarget,id:e.pointerId,pad,x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,time:e.timeStamp};
  gesture=g;g.surface.setPointerCapture(g.id);
  g.timer=setTimeout(()=>{if(gesture===g&&!g.moved){g.right=true;pointer('right')}},550);
}
function moveGesture(e){
  const g=gesture;if(!g||e.pointerId!==g.id||g.right)return;
  if(!g.moved&&Math.hypot(e.clientX-g.startX,e.clientY-g.startY)<(g.pad?2:5))return;
  e.preventDefault();clearTimeout(g.timer);
  if(!g.moved&&!g.pad){g.drag=true;pointer('down')}
  g.moved=true;
  if(g.pad){
    const geom=geometry();if(!geom)return;
    const dx=e.clientX-g.x,dy=e.clientY-g.y,rotated=matchMedia('(orientation:portrait)').matches;
    const speed=Math.hypot(dx,dy)/Math.max(1,e.timeStamp-g.time);
    const gain=Math.min(12,0.7+speed*5);
    lastPoint={x:bound(lastPoint.x+(rotated?dy:dx)*gain*65535/geom.img.naturalWidth),
      y:bound(lastPoint.y+(rotated?-dx:dy)*gain*65535/geom.img.naturalHeight)};
  }else lastPoint=absolutePoint(e,true)||lastPoint;
  g.x=e.clientX;g.y=e.clientY;g.time=e.timeStamp;drawCursor();
  if(!moveFrame)moveFrame=requestAnimationFrame(()=>{moveFrame=0;pointer('move')});
}
for(const surface of [$('player'),$('pad')]){
  surface.onpointerdown=e=>startGesture(e,surface===$('pad'));
  surface.onpointermove=moveGesture;
  surface.onpointerup=e=>{if(e.pointerId===gesture?.id){if(gesture.drag)lastPoint=absolutePoint(e,true)||lastPoint;drawCursor();endGesture(true)}};
  surface.onpointercancel=surface.onlostpointercapture=e=>{if(e.pointerId===gesture?.id)endGesture(false)};
  surface.oncontextmenu=e=>{if(controlOn)e.preventDefault()};
}
new ResizeObserver(()=>{if(controlOn)drawCursor()}).observe($('player'));
window.addEventListener('resize',drawCursor);window.addEventListener('blur',()=>endGesture(false));
document.addEventListener('visibilitychange',()=>{if(document.hidden)endGesture(false)});
$('openShell').onclick=()=>{$('captureMenu').open=false;$('psPanel').open=!$('psPanel').open};
$('keyboard').onclick=()=>{text('keyboard','Keyboard');const box=$('typing');box.value=' ';box.focus();box.setSelectionRange(1,1)};
function flushText(field){
  const value=(field.value.startsWith(' ')?field.value.slice(1):field.value).replace(/\r\n?/g,'\n');
  let chunk='';
  for(const ch of value){
    if(chunk.length+ch.length>1024){send('typing',{id:liveId,text:chunk});chunk=''}
    chunk+=ch;
  }
  if(chunk)send('typing',{id:liveId,text:chunk});
  field.value=' ';field.setSelectionRange(1,1);
}
$('typing').oninput=e=>{
  if(!controlOn||e.isComposing||$('keyboard').disabled)return;
  if(e.inputType?.startsWith('delete'))send('typing',{id:liveId,edit:'backspace'});
  flushText(e.target);
};
$('typing').oncompositionend=e=>{
  const field=e.target;
  queueMicrotask(()=>{if(controlOn&&!$('keyboard').disabled&&field.value!==' ')flushText(field)});
};
$('runScript').onclick=()=>{const script=$('script').value;if(!script.trim())return;text('psResult','Running�');send('inspect',{id:liveId,preset:'custom',script})};
for(const [button,preset] of [['psPrograms','programs'],['psEdge','edge'],['psWindows','windows'],['psService','service']]){
  $(button).onclick=()=>{text('psResult','Checking…');send('inspect',{id:liveId,preset})};
}
$('refresh').onclick=refresh;$('back').onclick=list;$('prev').onclick=()=>{page--;draw()};$('next').onclick=()=>{page++;draw()};
$('search').oninput=()=>{page=0;draw()};$('online').onchange=()=>{page=0;startScan();draw()};
function density(n){cols=Math.max(1,Math.min(3,n));$('grid').className='cols'+cols;$('smaller').disabled=cols===3;$('larger').disabled=cols===1}
$('smaller').onclick=()=>density(cols+1);$('larger').onclick=()=>density(cols-1);
$('zoomIn').onclick=()=>setZoom(zoom+1);$('zoomOut').onclick=()=>setZoom(zoom-1);
for(const evt of ['gesturestart','gesturechange','dblclick'])document.addEventListener(evt,e=>e.preventDefault(),{passive:false});
function ready(){if($('form').getBoundingClientRect().height){send('ready');send('resume')}else setTimeout(ready,100)}ready();
})();
