(()=>{
'use strict';
const $=id=>document.getElementById(id);
const send=(op,args={})=>window.webkit.messageHandlers.mms.postMessage(JSON.stringify({op,...args}));
const show=(id,on)=>$(id).hidden=!on;
const text=(id,value)=>$(id).textContent=value;
const make=(tag,value)=>{const n=document.createElement(tag);if(value!==undefined)n.textContent=value;return n};
let mode='login',devices=[],groups=[],group='*',page=0,cols=2,zoom=0,auditTimer,scanTimer;
let developer=false,waiting=false,scanning=false,checked=0,challenge=false;
let pageKey=null,liveId='',history={};
const dubaiDay=()=>new Date(Date.now()+4*3600000).toISOString().slice(0,10);
function remember(id){
  const day=dubaiDay();
  if(history[id]?.includes(day))return;
  (history[id]??=[]).push(day);
  if(mode==='history')renderHistory();
}
function renderHistory(){
  const day=$('historyDate').value, target=$('historyDevices');target.replaceChildren();
  const seen=new Set();
  for(const d of devices){
    if(!(d.days||[]).includes(day)&&!history[d.id]?.includes(day))continue;
    const key=d.serial?.trim().toUpperCase();
    const identity=key&&!/^(?:UNKNOWN|NONE|N\/A|DEFAULT STRING|SYSTEM SERIAL NUMBER|TO BE FILLED BY O\.E\.M\.|[0-]+)$/.test(key)?key:d.id;
    if(seen.has(identity))continue;
    seen.add(identity);const row=make('article');row.append(make('strong',d.name||d.host),make('small',d.host));target.append(row);
  }
  text('historyCount',seen.size+' devices observed');
}
const online=new Set(), pictures=new Map();
function stop(){send('stop');pictures.clear();pageKey=null}
function endScan(){clearTimeout(scanTimer);send('endScan');scanning=false}
function screen(next){
  stop();endScan();clearInterval(auditTimer);mode=next;
  for(const id of ['login','list','live','audit','me','history'])show(id,id===next);
  show('nav',['list','audit','me'].includes(next));
  for(const [id,tab] of [['students','list'],['supervisors','audit'],['account','me']])$(id).classList.toggle('active',tab===next);
  text('status','');
}
function refresh(){if(mode==='list'){endScan();send('devices')}}
function startScan(){
  endScan();
  if(mode==='list'&&$('online').checked&&devices.length){checked=0;scanning=true;send('scan');draw()}
}
function tabs(){
  const tabs=$('groups');tabs.replaceChildren();
  const values=[['*','All devices'],...groups.map(g=>[g.id,g.name]),['','Ungrouped']];
  if(!values.some(([id])=>id===group))group='*';
  for(const [id,label] of values){
    const b=make('button',label);b.classList.toggle('active',id===group);
    b.onclick=()=>{group=id;page=0;tabsUpdate()};tabs.append(b);
  }
}
function tabsUpdate(){tabs();draw()}
function frame(id,target,live){
  const f=make('figure','Connecting…');target.append(f);pictures.set(id,f);send('view',{id,live});
}
function setZoom(n){
  zoom=Math.max(0,Math.min(3,n));$('player').className=['','z2','z3','z4'][zoom];
  text('scale',[100,150,200,300][zoom]+'%');$('zoomOut').disabled=zoom===0;$('zoomIn').disabled=zoom===3;
}
function draw(){
  if(mode!=='list')return;
  const q=$('search').value.trim().toLowerCase();
  const items=devices.filter(d=>(group==='*'||(d.group||'')===group)&&(!$('online').checked||online.has(d.id))&&(d.name+' '+d.host).toLowerCase().includes(q));
  const pages=Math.max(1,Math.ceil(items.length/6));page=Math.min(page,pages-1);
  text('page',(page+1)+' / '+pages);$('prev').disabled=page===0;$('next').disabled=page+1===pages;
  text('status',items.length+' devices'+(scanning?' · Checking '+checked+' / '+devices.length:''));
  const slice=items.slice(page*6,page*6+6);const key=JSON.stringify(slice.map(d=>[d.id,d.name,d.host]));
  if(key===pageKey)return;
  const grid=$('grid'), existing=Array.from(grid.children);
  const appendOnly=pageKey!==null&&existing.length<=slice.length&&existing.every((card,i)=>card.dataset.key===JSON.stringify([slice[i].id,slice[i].name,slice[i].host]));
  if(!appendOnly){stop();grid.replaceChildren()}
  pageKey=key;
  for(const d of slice.slice(appendOnly?existing.length:0)){
    const b=make('button');b.dataset.key=JSON.stringify([d.id,d.name,d.host]);$('grid').append(b);frame(d.id,b,false);
    b.append(make('b',d.name||d.host),make('small',d.host));
    b.onclick=()=>{screen('live');liveId=d.id;text('psResult','');$('psPanel').open=false;text('liveName',d.name||d.host);$('player').replaceChildren();setZoom(0);frame(d.id,$('player'),true)};
  }
}
function list(){screen('list');tabsUpdate();refresh()}
function audit(){
  if(!developer)return;screen('audit');waiting=false;
  const load=()=>{if(!waiting){waiting=true;send('audit')}};load();auditTimer=setInterval(load,30000);
}
function rows(id,items,details){
  const target=$(id);target.replaceChildren();
  for(const row of items){const tile=make('article');tile.append(make('strong',row.user||row.userName),make('small',details(row)));target.append(tile)}
  if(!items.length)target.textContent='No records';
}
function date(value){return new Date(value.replace(' ','T')).toLocaleString('en-GB')}
function resetMode(on){
  show('form',!on);show('recovery',on);show('verify',false);challenge=false;show('resetFields',false);
  $('resetOrg').readOnly=$('resetUser').readOnly=false;$('resetSubmit').disabled=false;
  $('resetPass').value=$('resetCode').value='';text('resetSubmit','Send code');
  $('resetOrg').value=$('source').value;$('resetUser').value=$('user').value;text('status','');
}
window.receive=(name,value)=>{
  if(name==='restoring'){show('saved',true);show('form',false);text('status','Resuming session…')}
  if(name==='signed'){show('saved',false);
    history=value.history||{};show('psPanel',!!value.inspect);developer=value.developer;show('supervisors',developer);text('identity',value.user);
    text('profile',value.name||value.user);text('memory',value.remembered?'Sign-in saved on this iPhone':'Sign-in could not be saved to the iPhone Keychain');
    show('verify',false);$('password').value='';list();
  }
  if(name==='resume'&&mode==='login')send('resume');
  if(name==='otp'){show('form',false);show('verify',true);$('code').focus();text('status','Enter the code sent to your email.')}
  if(name==='groups'){groups=value;tabs()}
  if(name==='devices'){devices=value;draw();startScan()}
  if(name==='reach'&&scanning){checked++;if(value.online){online.add(value.id);remember(value.id)}else online.delete(value.id);draw()}
  if(name==='scanDone'&&scanning){scanning=false;draw();scanTimer=setTimeout(startScan,45000)}
  if(name==='audit'&&mode==='audit'){
    waiting=false;rows('presence',value.presence,r=>r.computer+' · '+(r.online?'Online':'Offline')+' · '+date(r.seen));
    rows('events',value.events,r=>r.computer+' · '+(r.action==='SIGN_IN'?'Signed in':'Signed out')+' · '+date(r.occurred));
  }
  if(name==='frame'&&pictures.has(value.id)){remember(value.id);const box=pictures.get(value.id);let img=box.firstElementChild;
    if(!img){img=make('img');img.alt='Student screen';box.replaceChildren(img)}img.src='data:image/jpeg;base64,'+value.data}
  if(name==='unavailable'&&pictures.has(value.id))pictures.get(value.id).textContent='Unavailable · retrying';
  if(name==='inspection'&&mode==='live'&&liveId===value.id)text('psResult',value.text);
  if(name==='resetCode'){
    challenge=true;show('resetFields',true);$('resetOrg').readOnly=$('resetUser').readOnly=true;
    $('resetSubmit').disabled=false;text('resetSubmit','Reset password');text('status','Enter your email code and a new password.');
  }
  if(name==='resetDone'){resetMode(false);text('status','Password updated. Sign in with your new password.')}
  if(name==='error'){if(mode==='live')text('psResult',value);waiting=false;text('status',value);$('resetSubmit').disabled=false;
    if(mode==='login'&&$('recovery').hidden&&$('saved').hidden){$('enter').disabled=false;show('verify',false);show('form',true)}}
  if(name==='locked'){show('saved',false);screen('login');devices=[];groups=[];group='*';online.clear();page=0;developer=false;
    for(const id of ['grid','player','presence','events','profile','identity','groups'])$(id).replaceChildren();
    $('online').checked=false;$('form').reset();$('verify').reset();$('search').value='';resetMode(false);$('enter').disabled=false}
};
$('form').onsubmit=e=>{e.preventDefault();$('enter').disabled=true;text('status','Signing in…');
 send('login',{source:$('source').value,user:$('user').value,password:$('password').value});$('password').value=''};
$('verify').onsubmit=e=>{e.preventDefault();send('otp',{code:$('code').value.trim()});$('code').value=''};
$('forgot').onclick=()=>resetMode(true);$('resetBack').onclick=()=>resetMode(false);
$('recovery').onsubmit=e=>{e.preventDefault();if(challenge&&(!$('resetCode').value.trim()||$('resetPass').value.length<10)){text('status','Enter the email code and a password of at least 10 characters.');return}
 $('resetSubmit').disabled=true;send(challenge?'resetFinish':'resetStart',{source:$('resetOrg').value,user:$('resetUser').value,code:$('resetCode').value,password:$('resetPass').value})};
$('retrySaved').onclick=()=>send('resume');$('forgetSaved').onclick=()=>send('logout');
$('account').onclick=()=>screen('me');$('exit').onclick=()=>send('logout');$('students').onclick=list;$('supervisors').onclick=audit;
$('daily').onclick=()=>{screen('history');$('historyDate').value=dubaiDay();renderHistory()};
$('historyBack').onclick=list;$('historyDate').onchange=renderHistory;
for(const [button,preset] of [['psPrograms','programs'],['psEdge','edge'],['psWindows','windows'],['psService','service']]){
  $(button).onclick=()=>{text('psResult','Checking…');send('inspect',{id:liveId,preset})};
}
$('refresh').onclick=refresh;$('back').onclick=list;$('prev').onclick=()=>{page--;draw()};$('next').onclick=()=>{page++;draw()};
$('search').oninput=()=>{page=0;draw()};$('online').onchange=()=>{page=0;startScan();draw()};
function density(n){cols=Math.max(1,Math.min(3,n));$('grid').className='cols'+cols;$('smaller').disabled=cols===3;$('larger').disabled=cols===1}
$('smaller').onclick=()=>density(cols+1);$('larger').onclick=()=>density(cols-1);
$('zoomIn').onclick=()=>setZoom(zoom+1);$('zoomOut').onclick=()=>setZoom(zoom-1);
for(const evt of ['gesturestart','gesturechange','dblclick'])document.addEventListener(evt,e=>e.preventDefault(),{passive:false});
function ready(){if($('form').getBoundingClientRect().height){send('ready');send('resume')}else setTimeout(ready,100)}ready();
})();
