'use strict';
const $=id=>document.getElementById(id);
const send=(op,args={})=>window.webkit.messageHandlers.mms.postMessage(JSON.stringify({op,...args}));
const show=(id,on)=>$(id).hidden=!on;
const text=(id,value)=>$(id).textContent=value;
let mode='login',devices=[],index=0,developer=false,timer,waiting=false;
const pictures=new Map();
function stop(){send('stop');pictures.clear();clearInterval(timer)}
function screen(next){
  stop(); mode=next;
  for(const key of ['login','list','live','audit'])show(key,key===next);
  show('nav',next==='list'||next==='audit');show('exit',next!=='login');
  $('students').classList.toggle('active',next==='list');$('supervisors').classList.toggle('active',next==='audit');
  text('status','');
}
function element(tag,value){const node=document.createElement(tag);if(value!==undefined)node.textContent=value;return node}
function frame(id,parent,live){
  const box=element('figure','جارٍ الاتصال…');parent.append(box);pictures.set(id,box);send('view',{id,live});
}
function draw(){
  if(mode!=='list')return;
  stop();$('grid').replaceChildren();
  const q=$('search').value.toLowerCase().trim();
  const items=devices.filter(d=>(d.name+' '+d.host).toLowerCase().includes(q));
  const pages=Math.max(1,Math.ceil(items.length/6));index=Math.min(index,pages-1);
  text('page',(index+1)+' / '+pages);$('prev').disabled=index===0;$('next').disabled=index===pages-1;
  text('status',items.length+' جهاز');
  for(const d of items.slice(index*6,index*6+6)){
    const card=element('button');$('grid').append(card);frame(d.id,card,false);
    card.append(element('b',d.name||d.host),element('small',d.host));
    card.onclick=()=>{screen('live');text('liveName',d.name||d.host);$('player').replaceChildren();frame(d.id,$('player'),true)};
  }
}
function list(){screen('list');draw();send('devices')}
function audit(){if(!developer)return;screen('audit');waiting=false;loadAudit();timer=setInterval(loadAudit,30000)}
function loadAudit(){if(mode==='audit'&&!waiting){waiting=true;send('audit')}}
function rows(id,items,details){
  const target=$(id);target.replaceChildren();
  for(const row of items){const tile=element('article');tile.append(element('strong',row.user||row.userName),element('small',details(row)));target.append(tile)}
  if(!items.length)target.textContent='لا توجد سجلات';
}
function date(value){return new Date(value.replace(' ','T')).toLocaleString('ar-AE')}
window.receive=(name,value)=>{
  if(name==='signed'){developer=value.developer;text('identity',value.user);show('supervisors',developer);list()}
  if(name==='otp'){show('verify',true);$('code').focus();text('status','أدخل الرمز المرسل إلى بريدك')}
  if(name==='devices'){devices=value;draw()}
  if(name==='audit'){waiting=false;if(mode==='audit'){
    rows('presence',value.presence,r=>r.computer+' · '+(r.online?'متصل':'غير متصل')+' · '+date(r.seen));
    rows('events',value.events,r=>r.computer+' · '+(r.action==='SIGN_IN'?'دخول':'خروج')+' · '+date(r.occurred));text('status','آخر تحديث '+new Date().toLocaleTimeString('ar-AE'))}}
  if(name==='frame' && pictures.has(value.id)){const box=pictures.get(value.id);let img=box.firstElementChild;
    if(!img){img=element('img');img.alt='شاشة الطالب';box.replaceChildren(img)}img.src='data:image/jpeg;base64,'+value.data}
  if(name==='unavailable' && pictures.has(value.id))pictures.get(value.id).textContent='تعذّر الاتصال · إعادة المحاولة';
  if(name==='error'){waiting=false;text('status',value);if(mode==='login'){$('enter').disabled=false;show('verify',false)}
    if(mode==='audit'){$('presence').replaceChildren();$('events').replaceChildren()}}
  if(name==='locked'){screen('login');devices=[];developer=false;index=0;waiting=false;show('verify',false);text('identity','');
    for(const id of ['grid','player','presence','events'])$(id).replaceChildren();
    $('form').reset();$('verify').reset();$('enter').disabled=false}
};
$('form').onsubmit=e=>{e.preventDefault();$('enter').disabled=true;text('status','جارٍ تسجيل الدخول…');
  send('login',{source:$('source').value,user:$('user').value,password:$('password').value});$('password').value=''};
$('verify').onsubmit=e=>{e.preventDefault();send('otp',{code:$('code').value.trim()});$('code').value='';show('verify',false)};
$('exit').onclick=()=>send('logout');$('students').onclick=list;$('supervisors').onclick=audit;
$('refresh').onclick=()=>mode==='audit'?loadAudit():list();$('back').onclick=()=>{screen('list');draw()};
$('prev').onclick=()=>{index--;draw()};$('next').onclick=()=>{index++;draw()};
$('search').oninput=()=>{index=0;draw()};
