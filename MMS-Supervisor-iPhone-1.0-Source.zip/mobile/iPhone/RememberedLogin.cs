using Foundation;
using Security;
using System.Text.Json.Nodes;

namespace MMS.Phone;

internal static class RememberedLogin
{
    private static SecRecord Query() => new(SecKind.GenericPassword)
    {
        Service = "com.hikaaya.mms.supervisor.login",
        Account = "current"
    };

    public static JsonNode? Read()
    {
        using var query = Query();
        using var value = SecKeyChain.QueryAsData(query, false, out var status);
        return status == SecStatusCode.Success && value != null ? JsonNode.Parse(value.ToArray()) : null;
    }

    public static bool Save(string source, string user, string password)
    {
        using var query = Query();
        using var data = NSData.FromString(new JsonObject { ["source"]=source, ["user"]=user, ["password"]=password }.ToJsonString());
        using var item = Query();
        item.ValueData = data;
        item.Accessible = SecAccessible.WhenUnlockedThisDeviceOnly;
        var status = SecKeyChain.Add(item);
        if (status == SecStatusCode.DuplicateItem)
        {
            using var changes = new SecRecord { ValueData = data };
            status = SecKeyChain.Update(query, changes);
        }
        return status == SecStatusCode.Success;
    }

    public static void Clear()
    {
        using var query = Query();
        var result = SecKeyChain.Remove(query);
        if (result != SecStatusCode.Success && result != SecStatusCode.ItemNotFound)
            throw new InvalidOperationException("Keychain removal failed");
    }
}
