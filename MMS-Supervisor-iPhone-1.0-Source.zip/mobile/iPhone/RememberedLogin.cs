using Foundation;
using Security;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;

namespace MMS.Phone;

internal static class RememberedLogin
{
    private static SecRecord Query() => new(SecKind.GenericPassword)
    {
        Service = "com.hikaaya.mms.supervisor.login",
        Account = "current"
    };

    private static string CacheFile(string hash)
    {
        if(hash.Length!=64 || !hash.All(Uri.IsHexDigit)) throw new InvalidDataException("Invalid saved sign-in");
        var dir=NSFileManager.DefaultManager.GetUrls(NSSearchPathDirectory.ApplicationSupportDirectory,NSSearchPathDomain.User)[0].Path!;
        Directory.CreateDirectory(dir);
        return Path.Combine(dir,"mms-session-"+hash+".bin");
    }

    private static JsonNode? ReadRecord()
    {
        using var query = Query();
        using var value = SecKeyChain.QueryAsData(query, false, out var status);
        return status == SecStatusCode.Success && value != null ? JsonNode.Parse(value.ToArray()) : null;
    }

    public static JsonNode? Read()
    {
        var record=ReadRecord();
        if(record?["cache"]?.ToString() is { Length: >0 } hash)
        {
            var bytes=File.ReadAllBytes(CacheFile(hash));
            if(Convert.ToHexString(SHA256.HashData(bytes))!=hash) throw new InvalidDataException("Damaged saved sign-in");
            record["envelope"]=Encoding.UTF8.GetString(bytes);
        }
        return record;
    }

    private static void RemoveBlob(string? hash)
    {
        if(string.IsNullOrEmpty(hash)) return;
        try { File.Delete(CacheFile(hash)); } catch(IOException) { } catch(UnauthorizedAccessException) { }
    }

    public static bool Save(string source, string user, string password,string? envelope)
    {
        using var query = Query();
        var previous=ReadRecord()?["cache"]?.ToString();
        string? hash=null;
        if(envelope!=null)
        {
            var bytes=Encoding.UTF8.GetBytes(envelope);
            hash=Convert.ToHexString(SHA256.HashData(bytes));
            var path=CacheFile(hash);
            var temp=path+"."+Guid.NewGuid().ToString("N");
            try { File.WriteAllBytes(temp,bytes); File.Move(temp,path,true); }
            finally { File.Delete(temp); }
        }
        using var data = NSData.FromString(new JsonObject { ["source"]=source, ["user"]=user, ["password"]=password, ["cache"]=hash, ["version"]=2 }.ToJsonString());
        using var item = Query();
        item.ValueData = data;
        item.Accessible = SecAccessible.WhenUnlockedThisDeviceOnly;
        var status = SecKeyChain.Add(item);
        if (status == SecStatusCode.DuplicateItem)
        {
            using var changes = new SecRecord { ValueData = data };
            status = SecKeyChain.Update(query, changes);
        }
        if(previous!=hash) RemoveBlob(status==SecStatusCode.Success ? previous : hash);
        return status == SecStatusCode.Success;
    }

    public static void Clear()
    {
        using var query = Query();
        var hash=ReadRecord()?["cache"]?.ToString();
        var result = SecKeyChain.Remove(query);
        if (result != SecStatusCode.Success && result != SecStatusCode.ItemNotFound)
            throw new InvalidOperationException("Keychain removal failed");
        RemoveBlob(hash);
    }
}
